package com.lskhjfgd.jklsfdg;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends Activity {

    private static Context ctx;

    static {
        System.loadLibrary("fklghffws");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ctx = this;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, 123);
        }
        Native.setLogin(this);
    }

    public void loginSucesso(String mensagem) {
        try {
            JSONObject json = new JSONObject(mensagem);
            String cliente = json.optString("Cliente");
            String dias = json.optString("Dias");

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle("Injetor BR Mods");
            alertDialogBuilder.setMessage("Usuario: " + cliente + "\nDias: " + dias);
            alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
            
            // Set custom background after dialog is shown
            if (alertDialog.getWindow() != null) {
                GradientDrawable drawable = new GradientDrawable();
                drawable.setColor(Color.parseColor("#B32D2D2D")); // Dark gray with 70% alpha
                drawable.setStroke(2, Color.parseColor("#41dae8")); // 2px cyan stroke (1dp ≈ 2px on most devices)
                drawable.setCornerRadius(30f); // 30px corner radius
                
                alertDialog.getWindow().setBackgroundDrawable(drawable);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}