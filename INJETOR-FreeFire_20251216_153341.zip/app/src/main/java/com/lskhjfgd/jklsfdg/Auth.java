package com.lskhjfgd.jklsfdg;

import android.os.AsyncTask;
import java.lang.ref.WeakReference;

public class Auth extends AsyncTask<String, Void, String> {
    private final WeakReference<MainActivity> weakActivity;
    private final byte[] puk = {48, -127, -97, 48, 13, 6, 9, 42, -122, 72, -122, -9, 13, 1, 1, 1, 5, 0, 3, -127, -115, 0, 48, -127, -119, 2, -127, -127, 0, -41, 36, -11, -27, -61, 32, 124, 58, 39, -94, -13, 7, 48, -104, -109, 106, -75, -8, -128, -92, -89, -125, -49, -83, 75, 12, -26, 90, 56, 35, 52, -116, 30, 40, -69, -70, 86, 14, -80, -20, 55, -89, 104, -46, -17, -80, -119, 83, -14, 116, -66, 11, -108, 5, 76, 12, -43, -89, -49, 11, 38, -124, 71, 45, 65, -103, 10, 99, 33, 79, 21, -16, -38, -60, 24, -108, 101, -89, -18, 48, -37, -78, 59, 10, 89, 42, 51, -43, 9, -33, -68, 61, -45, 94, -49, 83, 52, 56, 105, -123, 18, 89, 3, 54, -48, -63, -61, -103, -9, 79, -36, 18, 119, 11, -35, 82, 73, -66, 12, 123, -38, 97, 121, -30, 31, -50, -106, 127, 2, 3, 1, 0, 1};

    Auth(MainActivity activity) {
        weakActivity = new WeakReference<>(activity);
    }

    @Override
    protected void onPreExecute() {
        Native.onPreExecute(weakActivity.get());
    }

    @Override
    protected String doInBackground(String... strings) {
        return Native.doInBackground(weakActivity.get());
    }
    public void onPostExecute(String s) {
        Native.onPostExecute(weakActivity.get(), s);
    }
}