#include "Imports.h"

extern "C"
JNIEXPORT void JNICALL
Java_com_lskhjfgd_jklsfdg_Native_setLogin(JNIEnv *env, jclass clazz, jobject ctx) {
    JNI.EnvGlobal = env;
    LoginCreate(env,ctx);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_lskhjfgd_jklsfdg_Native_setClick(JNIEnv *env, jclass clazz, jobject ctx, jint id) {
    LoginOnClick(env,ctx, id);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_lskhjfgd_jklsfdg_Native_onPreExecute(JNIEnv *env, jclass thiz, jobject ctx) {
    onPreExecute(env,ctx);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_lskhjfgd_jklsfdg_Native_Init(JNIEnv *env, jclass clazz, jobject context, jobject service) {
    Java.Invoke(env,context,service,Login.DecryptLoader);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_lskhjfgd_jklsfdg_Native_doInBackground(JNIEnv *env, jclass clazz, jobject ctx) {
    return doInBackground(env,ctx);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_lskhjfgd_jklsfdg_Native_onPostExecute(JNIEnv *env, jclass thiz, jobject activity, jstring s) {
    onPostExecute(env,activity,s);
}