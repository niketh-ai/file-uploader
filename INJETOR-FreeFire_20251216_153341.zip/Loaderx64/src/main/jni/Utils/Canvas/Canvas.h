#ifndef CANVAS_H
#define CANVAS_H

#include "Paint.h"

class Canvas
{
private:
    jobject m_CanvasObj;
    jmethodID widthid;
    jmethodID heightid;
    jmethodID drawRoundRectid;
    jmethodID drawTextId;
    jmethodID drawRectId;
    jmethodID drawLineId;
    jmethodID drawCircleId;

    bool low;

    class Paint *mTextPaint;
    class Paint *mStrokePaint;
    class Paint *mFilledPaint;
    class Paint *mCiclePaint;
    class Paint *mFilledGdtPaint;
public:
    JNIEnv *env;
    Canvas(JNIEnv *env);

    void UpdateCanvas(jobject canvas);

    bool isValid();
    int getWidth();
    int getHeight();
    jobject LinearGradient(float x0, float y0, float x1, float y1, int color0, int color1, jobject Shader);
    jobject MIRROR();

    void drawCircle(float x, float y, float radius, float thicc, bool fill = false, int color = 0xFFFFFFFF);

    void drawLine(Vector3 start, Vector3 end, float thicc, int color);
    void DrawBox(Rect rect, float stroke, int color);
    void drawRect(float X, float Y, float width, float height, int color);
    void drawRoundRect(float left, float top, float right, float bottom, float rx, float ry, int color,int stroke);
    void drawRectGradient(float X, float Y, float width, float height, int color);

    void DrawRoundHealthBar(Rect rect, float maxHealth, float currentHealth);
    void DrawCornerBox(int color, float stroke, Rect rect, int cx, int cy);
    void DrawRoundArmoBar(Rect rect, float maxArmor, float currentArmor, int color);
    void DrawFilledRect(int color, Rect rect);
    void DrawCircle(int color, float stroke, Vector3 pos, float radius, bool fill);
    void DrawRectGradient(int color, float stroke, Rect Rect);

    void DrawFilledCircle(int color, Vector2 pos, float radius);

    void drawText(int textColor, int outlineColor, const char *text, Vector2 pos, float size);
};


#endif
