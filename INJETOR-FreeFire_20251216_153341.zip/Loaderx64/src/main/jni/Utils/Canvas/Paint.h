#ifndef PAINT_H
#define PAINT_H

#include "Const.h"

class Paint {
public:
    JNIEnv *env;

    jobject paintObj;

    jmethodID setStyleId;
    jmethodID setTextSizeId;
    jmethodID setColorId;
    jmethodID setStrokeWidthId;
    jmethodID setTextAlignId;
    jmethodID setShadowLayerId;
    jmethodID setTypefaceId;
    jmethodID setAntiAliasId;
    jmethodID setShaderid;

    jobject Style_FILL, Style_STROKE, Style_FILL_AND_STROKE;
    jobject Align_LEFT, Align_RIGHT, Align_CENTER;

    Paint(JNIEnv *env) {
        this->env = env;

        jclass paintClass = env->FindClass("android/graphics/Paint");
        jmethodID init = env->GetMethodID(paintClass, "<init>", "()V");
        this->paintObj = env->NewGlobalRef(env->NewObject(paintClass, init));

        setShaderid = env->GetMethodID(paintClass, "setShader","(Landroid/graphics/Shader;)Landroid/graphics/Shader;");
        setStyleId = env->GetMethodID(paintClass, "setStyle", "(Landroid/graphics/Paint$Style;)V");
        setTextSizeId = env->GetMethodID(paintClass, "setTextSize", "(F)V");
        setColorId = env->GetMethodID(paintClass, "setColor", "(I)V");
        setStrokeWidthId = env->GetMethodID(paintClass, "setStrokeWidth", "(F)V");
        setTextAlignId = env->GetMethodID(paintClass, "setTextAlign", "(Landroid/graphics/Paint$Align;)V");
        setShadowLayerId = env->GetMethodID(paintClass, "setShadowLayer", "(FFFI)V");
        setTypefaceId = env->GetMethodID(paintClass, "setTypeface", "(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;");
        setAntiAliasId = env->GetMethodID(paintClass, "setAntiAlias", "(Z)V");
        env->DeleteLocalRef(paintClass);

        jclass styleClass = env->FindClass("android/graphics/Paint$Style");
        jfieldID id = env->GetStaticFieldID(styleClass, "FILL", "Landroid/graphics/Paint$Style;");
        Style_FILL = env->NewGlobalRef(env->GetStaticObjectField(styleClass, id));
        id = env->GetStaticFieldID(styleClass, "STROKE", "Landroid/graphics/Paint$Style;");
        Style_STROKE = env->NewGlobalRef(env->GetStaticObjectField(styleClass, id));
        id = env->GetStaticFieldID(styleClass, "FILL_AND_STROKE", "Landroid/graphics/Paint$Style;");
        Style_FILL_AND_STROKE = env->NewGlobalRef(env->GetStaticObjectField(styleClass, id));
        env->DeleteLocalRef(styleClass);

        jclass alignClass = env->FindClass("android/graphics/Paint$Align");
        id = env->GetStaticFieldID(alignClass, "LEFT", "Landroid/graphics/Paint$Align;");
        Align_LEFT = env->NewGlobalRef(env->GetStaticObjectField(alignClass, id));
        id = env->GetStaticFieldID(alignClass, "RIGHT", "Landroid/graphics/Paint$Align;");
        Align_RIGHT = env->NewGlobalRef(env->GetStaticObjectField(alignClass, id));
        id = env->GetStaticFieldID(alignClass, "CENTER", "Landroid/graphics/Paint$Align;");
        Align_CENTER = env->NewGlobalRef(env->GetStaticObjectField(alignClass, id));
        env->DeleteLocalRef(alignClass);
    }

    void setStyle(Style style);
    void setTextSize(float size);
    void setColor(int color);
    void setStrokeWidth(float size = 1.0f);
    void setShadowLayer(float radius, float dx, float dy, int shadowColor);
    void setTextAlign(Align align);
    void setTypeface(jobject typeface);
    void setAntiAlias(bool bUseAA);
    void setShader(jobject shader);
};


#endif //ML_PAINT_H
