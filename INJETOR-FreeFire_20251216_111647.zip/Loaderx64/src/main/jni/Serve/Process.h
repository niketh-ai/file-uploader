#ifndef PROCESS_H
#include <sys/uio.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include<math.h>
#include <stdlib.h>
#include <assert.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <stdio.h>
#include <sys/un.h>
#include <time.h>
#include <ctype.h>
#include <iostream>
#include <sstream>

int PidAtual = 0;
long int il2cpp;
long int unity;

pid_t FindPid(char *PackageName){
    char text[69];
    pid_t pid = 0;
    sprintf(text, OBFUSCATE("pidof %s"), PackageName);
    FILE *chkRun = popen(text, "r");
    if (chkRun){
        char output[10];
        fgets(output ,10,chkRun);
        pclose(chkRun);
        pid = atoi(output);
    }
    if (pid < 10) {
        DIR* dir = NULL;
        struct dirent* ptr = NULL;
        FILE* fp = NULL;
        char filepath[256];
        char filetext[128];
        dir = opendir("/proc");
        if (NULL != dir) {
            while ((ptr = readdir(dir)) != NULL) {
                if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
                    continue;
                if (ptr->d_type != DT_DIR)
                    continue;
                sprintf(filepath, OBFUSCATE("/proc/%s/cmdline"), ptr->d_name);
                fp = fopen(filepath, "r");
                if (NULL != fp) {
                    fgets(filetext, sizeof(filetext), fp);
                    if (strcmp(filetext, PackageName) == 0) {
                        fclose(fp);
                        break;
                    }
                    fclose(fp);
                }
            }
        }
        if (readdir(dir) == NULL) {
            closedir(dir);
            //LOGE("%s",PackageName);
            return 0;
        }
        closedir(dir);
        //LOGE("%s",PackageName);
        pid = atoi(ptr->d_name);
    }
    //LOGE("%s",PackageName);
    return pid;
}

long FindLibrary(char* name, int index)
{
    int i = 0;
    long start = 0, end = 0;
    char line[1024] = {0};
    char fname[128];
    char dname[128];
    sprintf(dname, "%s", name);
    sprintf(fname, "/proc/%d/maps", PidAtual);
    FILE* p = fopen(fname, "r");
    if (p)
    {
        while (fgets(line, sizeof(line), p))
        {
            if (strstr(line, dname) != NULL)
            {
                i++;
                if (i == index) {
                    sscanf(line, "%lx-%lx", &start, &end);
                    break;
                }
            }
        }
        fclose(p);
    }
    return start;
}

void Libil2cpp(){
    il2cpp = FindLibrary(OBFUSCATE("libil2cpp.so"),1);
    unity = FindLibrary(OBFUSCATE("libunity.so"),1);
}

uintptr_t string2Offset(const char *c) {
    int base = 16;
    static_assert(sizeof(uintptr_t) == sizeof(unsigned long) || sizeof(uintptr_t) == sizeof(unsigned long long), "Please add string to handle conversion for this architecture.");

    if (sizeof(uintptr_t) == sizeof(unsigned long)) {
        return strtoul(c, nullptr, base);
    }
    return strtoull(c, nullptr, base);
}

#endif