#include "Imports.h"
#include <fstream>
#include <string>

struct D3DMatrix matrix;

void WriteLog(const char* fmt, ...) {
    char buffer[512];

    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    const char* path = "/sdcard/meulog.txt";
    std::ofstream logFile;
    logFile.open(path, std::ios::app);
    if (logFile.is_open()) {
        logFile << buffer << "\n";
        logFile.close();
    }
}

bool isInsideFov(int x, int y) {
    int circle_x = request.ScreenWidth / 2;
    int circle_y = request.ScreenHeight / 2;
    int rad = (int)pAIM.AimFov * 7;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

void StartPlayerDataList(long int Player, long int BaseGame, long int m_Match, long int Camera, long int Matrix4x4) {
    WriteLog("=== Entrou StartPlayerDataList ===");
    WriteLog("Player=%lx  m_Match=%lx  Camera=%lx  Matrix4x4=%lx", Player, m_Match, Camera, Matrix4x4);

    long int Dictionary = getPointer(BaseGame + string2Offset(OBFUSCATE("0x68")));
    WriteLog("Dictionary = %lx", Dictionary);
    if (Dictionary == 0) return;

    int getNumValues = getDword(Dictionary + string2Offset(OBFUSCATE("0x18")));
    WriteLog("getNumValues = %d", getNumValues);
    if (getNumValues == 0) return;

    long int getValues = getPointer(Dictionary + string2Offset(OBFUSCATE("0x14"))) + string2Offset(OBFUSCATE("0x10"));
    WriteLog("getValues = %lx", getValues);
    if (getValues == 0) return;

    for (int x = 0; x < getNumValues; x++) {
        WriteLog("--- Inimigo %d ---", x);

        long int EnemyList = getPointer(getValues + string2Offset(OBFUSCATE("0x4")) * x);
        WriteLog("EnemyList = %lx", EnemyList);
        if (EnemyList == 0) continue;

        long int AvatarManager = getPointer(EnemyList + string2Offset(OBFUSCATE("0x420")));
        WriteLog("AvatarManager = %lx", AvatarManager);
        if (AvatarManager == 0) continue;

        long int UmaAvatarSimple = getPointer(AvatarManager + string2Offset(OBFUSCATE("0x94")));
        WriteLog("UmaAvatarSimple = %lx", UmaAvatarSimple);
        if (UmaAvatarSimple == 0) continue;

        bool IsVisible = getBool(UmaAvatarSimple + string2Offset(OBFUSCATE("0x7C")));
        WriteLog("IsVisible = %d", IsVisible);
        if (!IsVisible) continue;

        long int UMAData = getPointer(UmaAvatarSimple + string2Offset(OBFUSCATE("0x10")));
        WriteLog("UMAData = %lx", UMAData);
        if (UMAData == 0) continue;

        bool isTeam = getBool(UMAData + string2Offset(OBFUSCATE("0x4C")));
        WriteLog("isTeam = %d", isTeam);
        if (isTeam) continue;

        // --- Filtro equivalente ao daemon antigo ---
bool Blocked = getBool(UMAData + string2Offset(OBFUSCATE("0x51")));
WriteLog("BlockedFlag = %d", Blocked);
if (Blocked) continue;

// --- Agora obtém o SkinnedMeshRenderer de forma correta ---
long int SkinnedMeshRenderer = getPointer(UmaAvatarSimple + string2Offset(OBFUSCATE("0x10")));
WriteLog("SkinnedMeshRenderer = %lx", SkinnedMeshRenderer);
if (SkinnedMeshRenderer == 0) continue;

long int IntPtr = getPointer(Camera + string2Offset(OBFUSCATE("0x8")));
WriteLog("IntPtr = %lx", IntPtr);
if (IntPtr == 0) continue;


        long int IPRIDataPool = getPointer(EnemyList + string2Offset(OBFUSCATE("0x44")));
        WriteLog("IPRIDataPool = %lx", IPRIDataPool);
        if (IPRIDataPool == 0) continue;

        long int ReplicationDataPoolUnsafe = getPointer(IPRIDataPool + string2Offset(OBFUSCATE("0x8")));
        WriteLog("ReplicationDataPoolUnsafe = %lx", ReplicationDataPoolUnsafe);
        if (ReplicationDataPoolUnsafe == 0) continue;

        long int ReplicationDataUnsafe = getPointer(ReplicationDataPoolUnsafe + string2Offset(OBFUSCATE("0x10")));
        WriteLog("ReplicationDataUnsafe = %lx", ReplicationDataUnsafe);
        if (ReplicationDataUnsafe == 0) continue;

        long int PlayerNetwork = getPointer(EnemyList + string2Offset(OBFUSCATE("0x254")));
        WriteLog("PlayerNetwork = %lx", PlayerNetwork);
        if (PlayerNetwork != 0 && PlayerNetwork != 1) continue;

        short Health = getWord(getPointer(ReplicationDataUnsafe + string2Offset(OBFUSCATE("0x10"))));
        WriteLog("Health = %d", Health);

        Vector3 MyLocationToe = getVector3(getPointer(getPointer(getPointer(getPointer(getPointer(Player + 0x420) + 0x94) + 0x10) + 0x4) + 0x8) + 0x3B8);
        Vector3 EnemyPositionHead = getVector3(EnemyList + 0x3B8);
        Vector3 EnemyPositionToe = getVector3(EnemyList + 0x3D0);
        WriteLog("Positions OK");

        ProcessRead(Matrix4x4, &matrix, sizeof(matrix));

        PlayerData* data = &response.Players[response.PlayerCount];

        float Distance = Vector3::Distance(MyLocationToe, EnemyPositionToe);

        int PlayerState = getDword(PlayerNetwork + string2Offset(OBFUSCATE("0x149C")));
        bool isDieing = (PlayerState == string2Offset(OBFUSCATE("0x78")));

        WriteLog("Distance = %.2f", Distance);
        WriteLog("PlayerState = %d  isDieing = %d", PlayerState, isDieing);

        data->Life = Health;
        data->PlayerState = isDieing;
        data->Distance = Distance;
        data->LocationHead = World2Screen(matrix, EnemyPositionHead);
        data->LocationToeBox = World2Screen(matrix, EnemyPositionToe);

        WriteLog("World2Screen OK");

        response.PlayerCount++;
        WriteLog("PlayerCount = %d", response.PlayerCount);
    }

    WriteLog("=== Saiu StartPlayerDataList ===");
}

void mainUpdate() {
    WriteLog("Iniciou mainUpdate");

    response.PlayerCount = 0;

    long int P1 = getPointer(il2cpp + string2Offset(OBFUSCATE("0x997EAD0")));
    WriteLog("P1 = %lx", P1);
    if (P1 != 0) {

        long int P2 = getPointer(P1 + string2Offset(OBFUSCATE("0x5C")));
        WriteLog("P2 = %lx", P2);
        if (P2 != 0) {

            long int BaseGame = getPointer(P2 + string2Offset(OBFUSCATE("0x4")));
            WriteLog("BaseGame = %lx", BaseGame);

            if (BaseGame != 0) {

                long int m_Match = getPointer(BaseGame + string2Offset(OBFUSCATE("0x50")));
                WriteLog("m_Match = %lx", m_Match);

                if (m_Match != 0) {

                    int MatchIsRunning = getDword(m_Match + string2Offset(OBFUSCATE("0x3C")));
                    WriteLog("MatchIsRunning = %d", MatchIsRunning);

                    if (MatchIsRunning == string2Offset(OBFUSCATE("1"))) {

                        long int Player = getPointer(m_Match + string2Offset(OBFUSCATE("0x44")));
                        WriteLog("Player = %lx", Player);

                        if (Player != 0) {

                            long int FollowCamera = getPointer(Player + string2Offset(OBFUSCATE("0x3B0")));
                            WriteLog("FollowCamera = %lx", FollowCamera);

                            if (FollowCamera != 0) {

                                long int Camera = getPointer(FollowCamera + string2Offset(OBFUSCATE("0x14")));
                                WriteLog("Camera = %lx", Camera);

                                if (Camera != 0) {

                                    long int IntPtrCam = getPointer(Camera + string2Offset(OBFUSCATE("0x8")));
                                    WriteLog("IntPtrCam = %lx", IntPtrCam);

                                    if (IntPtrCam != 0) {

                                        long int Matrix4x4 = IntPtrCam + string2Offset(OBFUSCATE("0xBC"));
                                        WriteLog("Matrix4x4 = %lx", Matrix4x4);

                                        if (Matrix4x4 != 0) {
                                            WriteLog("Chamando StartPlayerDataList");
                                            StartPlayerDataList(Player, BaseGame, m_Match, Camera, Matrix4x4);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        WriteLog("P1 é nulo. Resetando PidAtual.");
        PidAtual = 0;
    }

    WriteLog("mainUpdate terminou");
}

int main(int argc, char* argv[]) {
    if (InitServer() == 0) {
        if (pSOCKEt.server.Accept()) {

            pSOCKEt.server.receive((void*)&request);
            pSOCKEt.server.send((void*)&response, sizeof(response));

            std::chrono::steady_clock::time_point last_update_time = std::chrono::steady_clock::now();

            while (pSOCKEt.server.receive((void*)&request) > 0) {

                if (PidAtual == 0) {
                    PidAtual = FindPid(argv[1]);
                    Libil2cpp();
                }

                auto current_time = std::chrono::steady_clock::now();
                auto elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(current_time - last_update_time).count();

                if (elapsed_time > 1000 / 45) {
                    mainUpdate();
                    last_update_time = current_time;
                }

                if (request.Mode == Mode::Thread) {
                    pAIM.AimbotShot = request.Opcoes.aimbotShot;
                    pAIM.AimbotAim = request.Opcoes.aimbotAim;
                    pAIM.AimFov = request.Opcoes.aimFov;
                    pAIM.Ghost = request.Opcoes.ghost;

                    response.Success = true;

                    pSOCKEt.server.send((void*)&response, sizeof(response));
                }
            }
        }
    }
}
