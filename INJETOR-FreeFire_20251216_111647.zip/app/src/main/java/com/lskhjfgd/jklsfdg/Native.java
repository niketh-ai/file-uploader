package com.lskhjfgd.jklsfdg;

import android.app.Service;
import android.content.Context;
import android.view.View;

import java.net.HttpURLConnection;
import java.net.URL;

public class Native {
    static native void onPreExecute(MainActivity ctx);
    static native String doInBackground(MainActivity ctx);
    static native void onPostExecute(MainActivity ctx, String s);

    static native void setLogin(Context ctx);
    static native void setClick(Context ctx, int id);

    static native void Init(Context context, Service service);

    private static View.OnClickListener onClickListener(final Context ctx, final int id) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setClick(ctx, id);
            }
        };
    }
}
