package com.lskhjfgd.jklsfdg;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Floater extends Service {

    @Override
    public void onCreate() {
        super.onCreate();
        Native.Init(this, this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
