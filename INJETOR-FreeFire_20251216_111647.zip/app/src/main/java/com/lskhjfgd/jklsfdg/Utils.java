package com.lskhjfgd.jklsfdg;

import android.annotation.TargetApi;
import android.os.Build;
import android.util.Base64;
import java.nio.charset.StandardCharsets;

public class Utils {
    public static String profileDecrypt(String data, String sign) {
        char[] key = sign.toCharArray();
        char[] out = fromBase64String(data).toCharArray();
        for(int i = 0; i < out.length;i++){
            out[i] = (char)(key[i % key.length] ^ out[i]);
        }
        return new String(out);
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static String fromBase64String(String s) {
        return new String(Base64.decode(s, Base64.NO_WRAP), StandardCharsets.UTF_8);
    }
}
