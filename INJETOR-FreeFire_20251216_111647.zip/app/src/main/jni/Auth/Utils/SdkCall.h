struct {
    JNIEnv *EnvGlobal = NULL;
}JNI;

struct {
    const char *DrawESP = AY_OBFUSCATE("com/lskhjfgd/jklsfdg/DrawESP");
    const char *Floater = AY_OBFUSCATE("com/lskhjfgd/jklsfdg/Floater");
    const char *Native  = AY_OBFUSCATE("com/lskhjfgd/jklsfdg/Native");
}ClassJNI;

namespace ToastLength {
    inline const int LENGTH_LONG = 1;
    inline const int LENGTH_SHORT = 0;
}

struct {
    int FILL_PARENT = -1;
    int MATCH_PARENT = -1;
    int WRAP_CONTENT = -2;
}LayoutParams;

struct {
    int HORIZONTAL = 0;
    int VERTICAL = 1;
}Orientation;

struct {
    int CENTER = 17;
    int START = 8388611;
    int END = 8388613;
    int LEFT = 3;
    int RIGHT = 5;
    int TOP = 48;
    int BOTTOM = 80;
}Gravity;

struct {
    int SCREEN_ORIENTATION_LANDSCAPE = 0;
    int FEATURE_NO_TITLE = 1;
}ActivityInfo;

struct {
    int FLAG_FULLSCREEN = 1024;
}Flags;

struct {
    int LINE = 2;
    int OVAL = 1;
    int RECTANGLE = 0;
}Shape;

struct {
    int BOLD = 1;
    int BOLD_ITALIC = 3;
    int ITALIC = 2;
    int NORMAL = 0;
}TypeFace;

struct {
    jobject AsyncTaskRunner(jobject ctx) {
        jclass Floater$FreeFireTask = JNI.EnvGlobal->FindClass("com/lskhjfgd/jklsfdg/Auth");
        jmethodID AuthID = JNI.EnvGlobal->GetMethodID(Floater$FreeFireTask, "<init>",
                                                      "(Lcom/lskhjfgd/jklsfdg/MainActivity;)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(Floater$FreeFireTask, AuthID,ctx));
    }
}JavaJNI;

struct {
    const char *WINDOW_SERVICE = "window";
    const char *CONNECTIVITY_SERVICE = "connectivity";

    jobject getSystemService(jobject ctx, const char * Context) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass("android/content/Context");
        jmethodID getSystemServiceID = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getSystemServiceID, JNI.EnvGlobal->NewStringUTF(Context)));
    }
    jobject getCacheDir(JNIEnv *env, jobject ctx) {
        jclass ContextClass = env->FindClass("android/content/Context");
        jmethodID getCacheDirID = env->GetMethodID(ContextClass,"getCacheDir", "()Ljava/io/File;");
        return env->NewGlobalRef(env->CallObjectMethod(ctx,getCacheDirID));
    }
    jobject getClassLoader(JNIEnv *env, jobject ctx) {
        jclass ContextClass = env->FindClass("android/content/Context");
        jmethodID getCacheDirID = env->GetMethodID(ContextClass,"getClassLoader","()Ljava/lang/ClassLoader;");
        return env->NewGlobalRef(env->CallObjectMethod(ctx,getCacheDirID));
    }
}Context;

struct {
    int COMPLEX_UNIT_DIP = 1;
    int COMPLEX_UNIT_SP = 2;

    jfloat applyDimension(JNIEnv *env, int unit, float value, jobject metrics) {
        jclass TypedValueClass = env->FindClass(AY_OBFUSCATE("android/util/TypedValue"));
        jmethodID applyDimensionID = env->GetStaticMethodID(TypedValueClass, AY_OBFUSCATE("applyDimension"), AY_OBFUSCATE("(IFLandroid/util/DisplayMetrics;)F"));
        return env->CallStaticFloatMethod(TypedValueClass, applyDimensionID, unit, value, metrics);
    }
}TypedValue;

struct {
    jobject FrameLayout(jobject ctx) {
        jclass FrameLayoutClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/FrameLayout"));
        jmethodID FrameLayoutID = JNI.EnvGlobal->GetMethodID(FrameLayoutClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(FrameLayoutClass, FrameLayoutID, ctx));
    }
}FrameLayout;

struct {
    jobject LinearLayout(JNIEnv *env, jobject ctx) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID linearLayoutID = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(env->NewObject(linearLayoutClass, linearLayoutID, ctx));
    }
    jobject LayoutParams(JNIEnv *env, jint width, int height) {
        jclass LayoutPramsClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout$LayoutParams"));
        jmethodID LayoutPramsID = env->GetMethodID(LayoutPramsClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(II)V"));
        return env->NewGlobalRef(env->NewObject(LayoutPramsClass, LayoutPramsID, width,height));
    }
    void setLayoutParams(JNIEnv *env, jobject LinearLayout, jobject MainParams) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID setLayoutParams = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setLayoutParams"), AY_OBFUSCATE("(Landroid/view/ViewGroup$LayoutParams;)V"));
        env->CallVoidMethod(LinearLayout, setLayoutParams, MainParams);
        env->DeleteLocalRef(linearLayoutClass);
    }
    void setOrientation(JNIEnv *env, jobject LinearLayout, int orientation) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID setOrientation = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setOrientation"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(LinearLayout, setOrientation, orientation);
        env->DeleteLocalRef(linearLayoutClass);
    }
    void setGravity(JNIEnv *env, jobject thiz, int Gravity) {
        jclass LinearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID setGravity = env->GetMethodID(LinearLayoutClass, AY_OBFUSCATE("setGravity"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(thiz,setGravity,Gravity);
        env->DeleteLocalRef(LinearLayoutClass);
    }
    void setBackground(JNIEnv *env, jobject LinearLayout, jobject GradientDrawable) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID setBackground = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setBackground"), AY_OBFUSCATE("(Landroid/graphics/drawable/Drawable;)V"));
        env->CallVoidMethod(LinearLayout, setBackground, GradientDrawable);
        env->DeleteLocalRef(linearLayoutClass);
    }
    void topMargin(JNIEnv *env, jobject params, int value) {
        jclass WindowManager$LayoutParams = env->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID topMargin = env->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("topMargin"), AY_OBFUSCATE("I"));
        env->SetIntField(params,topMargin,value);
        env->DeleteLocalRef(WindowManager$LayoutParams);
    }
}LinearLayout;

struct {
    jobject RelativeLayout(jobject ctx) {
        jclass RelativeLayoutClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/RelativeLayout"));
        jmethodID RelativeLayoutID = JNI.EnvGlobal->GetMethodID(RelativeLayoutClass, AY_OBFUSCATE("<init>"),  AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(RelativeLayoutClass, RelativeLayoutID, ctx));
    }
    void setGravity(jobject thiz, int Gravity) {
        jclass RelativeLayoutClass = JNI.EnvGlobal->FindClass( AY_OBFUSCATE("android/widget/RelativeLayout"));
        jmethodID setGravity = JNI.EnvGlobal->GetMethodID(RelativeLayoutClass,  AY_OBFUSCATE("setGravity"),  AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz,setGravity,Gravity);
        JNI.EnvGlobal->DeleteLocalRef(RelativeLayoutClass);
    }
}RelativeLayout;

struct {
    int VISIBLE = 0;
    int GONE = 8;
    int INVISIBLE = 4;
    int SYSTEM_UI_FLAG_LAYOUT_STABLE = 256;
    int SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION = 512;
    int SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN = 1024;
    int SYSTEM_UI_FLAG_HIDE_NAVIGATION = 2;
    int SYSTEM_UI_FLAG_FULLSCREEN = 4;
    int SYSTEM_UI_FLAG_IMMERSIVE_STICKY = 4096;

    jobject View(JNIEnv *env, jobject ctx) {
        jclass TextViewClass = env->FindClass( AY_OBFUSCATE("android/view/View"));
        jmethodID TextViewID = env->GetMethodID(TextViewClass,  AY_OBFUSCATE("<init>"),  AY_OBFUSCATE("(Landroid/content/Context;)V"));
        jobject ViewObj = env->NewGlobalRef(env->NewObject(TextViewClass, TextViewID, ctx));
        return ViewObj;
    }
    void setVisibility(JNIEnv *env, jobject view, int visibility) {
        jclass ViewClass = env->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setAlphaID = env->GetMethodID(ViewClass,AY_OBFUSCATE("setVisibility"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(view,setAlphaID,visibility);
        env->DeleteLocalRef(ViewClass);
    }
    void setBackgroundColor(JNIEnv *env, jobject TexttView, int Color) {
        jclass ViewClass = env->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setBackgroundColor = env->GetMethodID(ViewClass, AY_OBFUSCATE("setBackgroundColor"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(TexttView, setBackgroundColor, Color);
        env->DeleteLocalRef(ViewClass);
    }
    void setLayoutParams(JNIEnv *env, jobject View, jobject MainParams) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setLayoutParams = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setLayoutParams"), AY_OBFUSCATE("(Landroid/view/ViewGroup$LayoutParams;)V"));
        env->CallVoidMethod(View, setLayoutParams, MainParams);
        env->DeleteLocalRef(linearLayoutClass);
    }
    void setBackground(JNIEnv *env, jobject thiz, jobject Drawable) {
        jclass ViewClass = env->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setBackground = env->GetMethodID(ViewClass, AY_OBFUSCATE("setBackground"), AY_OBFUSCATE("(Landroid/graphics/drawable/Drawable;)V"));
        env->CallVoidMethod(thiz, setBackground,Drawable);
        env->DeleteLocalRef(ViewClass);
    }
    void setElevation(JNIEnv *env, jobject thiz, float elevation) {
        jclass ViewClass = env->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setElevation = env->GetMethodID(ViewClass, AY_OBFUSCATE("setElevation"), AY_OBFUSCATE("(F)V"));
        env->CallVoidMethod(thiz, setElevation, elevation);
        env->DeleteLocalRef(ViewClass);
    }
    void setPadding(JNIEnv *env, jobject thiz, int left, int top, int right, int bottom) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setPadding = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setPadding"), AY_OBFUSCATE("(IIII)V"));
        env->CallVoidMethod(thiz,setPadding,left,top,right,bottom);
        env->DeleteLocalRef(TextViewClass);
    }
    void setAlpha(jobject webview, float alpha) {
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setAlphaID = JNI.EnvGlobal->GetMethodID(ViewClass,AY_OBFUSCATE("setAlpha"), AY_OBFUSCATE("(F)V"));
        JNI.EnvGlobal->CallVoidMethod(webview,setAlphaID,alpha);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
}View;

struct {
    jobject WebView(JNIEnv *env, jobject ctx) {
        jclass WebViewClass = env->FindClass("android/webkit/WebView");
        jmethodID WebViewID = env->GetMethodID(WebViewClass,"<init>","(Landroid/content/Context;)V");
        return env->NewGlobalRef(env->NewObject(WebViewClass, WebViewID, ctx));
    }
    void loadData(JNIEnv *env,jobject webview, const char *data,const char *mimeType, const char *encoding) {
        jclass ViewClass = env->FindClass("android/webkit/WebView");
        jmethodID loaddataID = env->GetMethodID(ViewClass,"loadData","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
        env->CallVoidMethod(webview,loaddataID,env->NewStringUTF(data),env->NewStringUTF(mimeType),env->NewStringUTF(encoding));
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
}WebView;

struct {
    jobject GradientDrawable(jobject ctx) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID GradientDrawableID = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("()V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(GradientDrawableClass, GradientDrawableID));
    }
    void setShape(jobject thiz, int shape) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setShape = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setShape"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setShape,shape);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    void setColor(jobject GradientDrawable, int Color) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setColor = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setColor"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(GradientDrawable, setColor, Color);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    void setCornerRadii(jobject gradientDrawable, float f1, float f2, float f3, float f4) {
        jfloat radii[] = {f1, f1, f2, f2, f3, f3, f4, f4};
        jfloatArray teste = JNI.EnvGlobal->NewFloatArray(8);
        JNI.EnvGlobal->SetFloatArrayRegion(teste, 0, 8, radii);
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setCornerRadii = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setCornerRadii"),AY_OBFUSCATE("([F)V"));
        JNI.EnvGlobal->CallVoidMethod(gradientDrawable,setCornerRadii,teste);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    void setCornerRadius(jobject GradientDrawable, float radius){
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setCornerRadius = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setCornerRadius"),AY_OBFUSCATE("(F)V"));
        JNI.EnvGlobal->CallVoidMethod(GradientDrawable, setCornerRadius, radius);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    void setStroke(jobject GradientDrawable, int X_Pos, int Y_Pos) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setStroke = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setStroke"), AY_OBFUSCATE("(II)V"));
        JNI.EnvGlobal->CallVoidMethod(GradientDrawable, setStroke, X_Pos, Y_Pos);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    jobject Gradient(jobject orientation, jintArray colors) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID GradientDrawableID = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(GradientDrawableClass, GradientDrawableID, orientation,colors));
    }
    void setSize(jobject GradientDrawable, int width, int height){
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass("android/graphics/drawable/GradientDrawable");
        jmethodID setSizeID = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, "setSize", "(II)V");
        JNI.EnvGlobal->CallVoidMethod(GradientDrawable, setSizeID, width,height);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    struct {
        jobject LEFT_RIGHT() {
            jclass OrientationClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable$Orientation"));
            jfieldID LEFT_RIGHT = JNI.EnvGlobal->GetStaticFieldID(OrientationClass, AY_OBFUSCATE("LEFT_RIGHT"),AY_OBFUSCATE("Landroid/graphics/drawable/GradientDrawable$Orientation;"));
            return JNI.EnvGlobal->GetStaticObjectField(OrientationClass, LEFT_RIGHT);
        }
    }Orientation;
}GradientDrawable;

struct{

}Math;

struct {
    struct {
        void topMargin(jobject params, int value) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
            jfieldID topMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams,AY_OBFUSCATE("topMargin"), AY_OBFUSCATE("I"));
            JNI.EnvGlobal->SetIntField(params,topMargin,value);
            JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
        }
    }MarginLayoutParams;

    jmethodID addView() {
        jclass ViewGroupClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup"));
        return JNI.EnvGlobal->GetMethodID(ViewGroupClass, AY_OBFUSCATE("addView"), AY_OBFUSCATE("(Landroid/view/View;)V"));
    }
    void topMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID topMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("topMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,topMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
    void leftMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID leftMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("leftMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,leftMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
    void rightMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID rightMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("rightMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,rightMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
    void bottomMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID bottomMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("bottomMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,bottomMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
    void addView2(JNIEnv *env, jobject linear, jobject child){
        jclass ViewGroupClass = env->FindClass(AY_OBFUSCATE("android/view/ViewGroup"));
        jmethodID addView = env->GetMethodID(ViewGroupClass, AY_OBFUSCATE("addView"), AY_OBFUSCATE("(Landroid/view/View;)V"));
        env->CallVoidMethod(linear,addView,child);
        JNI.EnvGlobal->DeleteLocalRef(ViewGroupClass);
    }
    void setMargins(JNIEnv *env, jobject params, jint left, jint top, jint right, jint bottom) {
        jclass ViewGroup$MarginLayoutParams = env->FindClass("android/view/ViewGroup$MarginLayoutParams");
        jmethodID setMarginsID = env->GetMethodID(ViewGroup$MarginLayoutParams,"setMargins", "(IIII)V");
        env->CallVoidMethod(params,setMarginsID,left,top,right,bottom);
        env->DeleteLocalRef(ViewGroup$MarginLayoutParams);
    }
}ViewGroup;

struct {
    struct {
        jobject WindowParams(int w, int h, int _type, int _flags, int _format) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jmethodID WindowManagerParamsID = JNI.EnvGlobal->GetMethodID(WindowManager$LayoutParams, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(IIIII)V"));
            return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(WindowManager$LayoutParams,WindowManagerParamsID,w,h,_type,_flags,_format));
        }
        jint FLAG_NOT_FOCUSABLE() {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID FLAG_NOT_FOCUSABLEID = JNI.EnvGlobal->GetStaticFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("FLAG_NOT_FOCUSABLE"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetStaticIntField(WindowManager$LayoutParams,FLAG_NOT_FOCUSABLEID);
        }
        jint TYPE_PHONE() {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID SDK_INTID = JNI.EnvGlobal->GetStaticFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("TYPE_PHONE"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetStaticIntField(WindowManager$LayoutParams,SDK_INTID);
        }
        void gravity(jobject params, int value) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID GravityID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("gravity"), AY_OBFUSCATE("I"));
            JNI.EnvGlobal->SetIntField(params,GravityID,value);
            JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
        }
        void x(jobject params, int value) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID xID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("x"), AY_OBFUSCATE("I"));
            JNI.EnvGlobal->SetIntField(params,xID,value);
            JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
        }

        void y(jobject params, int value) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID yID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("y"), AY_OBFUSCATE("I"));
            JNI.EnvGlobal->SetIntField(params,yID,value);
            JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
        }
        jint GetX(jobject params) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID xID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("x"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetIntField(params,xID);
        }
        jint GetY(jobject params) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID yID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("y"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetIntField(params,yID);
        }
    }LayoutParams;
}WindowManager;

struct {
    jint TRANSLUCENT() {
        jclass PixelFormat = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/PixelFormat"));
        jfieldID TRANSLUCENTID = JNI.EnvGlobal->GetStaticFieldID(PixelFormat, AY_OBFUSCATE("TRANSLUCENT"), AY_OBFUSCATE("I"));
        return JNI.EnvGlobal->GetStaticIntField(PixelFormat,TRANSLUCENTID);
    }
}PixelFormat;

struct {
    jobject getSystemService(jobject ctx, const char * Context) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jmethodID getSystemServiceID = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, AY_OBFUSCATE("getSystemService"), AY_OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getSystemServiceID, JNI.EnvGlobal->NewStringUTF(Context)));
    }
    const char *getPackageName(jobject ctx) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jmethodID getPackageNameID = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, AY_OBFUSCATE("getPackageName"), AY_OBFUSCATE("()Ljava/lang/String;"));
        jstring getPackageName = (jstring)(JNI.EnvGlobal->CallObjectMethod(ctx, getPackageNameID));
        return JNI.EnvGlobal->GetStringUTFChars(getPackageName, 0);
    }
    jobject startService(JNIEnv *env, jobject ctx, jobject service) {
        jclass ContextWrapperClass = env->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jmethodID startActivityMethodId = env->GetMethodID(ContextWrapperClass, AY_OBFUSCATE("startService"), AY_OBFUSCATE("(Landroid/content/Intent;)Landroid/content/ComponentName;"));
        return env->NewGlobalRef(env->CallObjectMethod(ctx, startActivityMethodId,service));
    }
    jobject getResources(JNIEnv *env, jobject ctx) {
        jclass ContextWrapperClass = env->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jmethodID getResourcesID = env->GetMethodID(ContextWrapperClass, AY_OBFUSCATE("getResources"), AY_OBFUSCATE("()Landroid/content/res/Resources;"));
        return env->CallObjectMethod(ctx, getResourcesID);
    }
}ContextWrapper;

struct {
    jobject getDisplayMetrics(JNIEnv *env, jobject Resources) {
        jclass ResourcesClass = env->FindClass(AY_OBFUSCATE("android/content/res/Resources"));
        jmethodID getDisplayMetricsID = env->GetMethodID(ResourcesClass, AY_OBFUSCATE("getDisplayMetrics"), AY_OBFUSCATE("()Landroid/util/DisplayMetrics;"));
        return env->NewGlobalRef(env->CallObjectMethod(Resources,getDisplayMetricsID));
    }
}Resources;

jfloat ConvertDP(JNIEnv *env, jobject ctx, jfloat value) {
    return TypedValue.applyDimension(env,TypedValue.COMPLEX_UNIT_DIP,value,Resources.getDisplayMetrics(env,ContextWrapper.getResources(env,ctx)));
}

struct {
    int BLACK = -16777216;
    int BLUE = -16776961;
    int CYAN = -16711681;
    int DKGRAY = -12303292;
    int GRAY = -7829368;
    int GREEN = -16711936;
    int LTGRAY = -3355444;
    int MAGENTA = -65281;
    int RED = -65536;
    int TRANSPARENT = 0;
    int WHITE = -1;
    int YELLOW = -256;
    int ORANGE = -256;

    jint parseColor(const char *colorString) {
        jclass ColorClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/Color"));
        jmethodID startActivity = JNI.EnvGlobal->GetStaticMethodID(ColorClass, AY_OBFUSCATE("parseColor"), AY_OBFUSCATE("(Ljava/lang/String;)I"));
        return JNI.EnvGlobal->CallStaticIntMethod(ColorClass,startActivity, JNI.EnvGlobal->NewStringUTF(colorString));
    }

    jint rgb(int red, int green, int blue) {
        jclass ColorClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/Color"));
        jmethodID startActivity = JNI.EnvGlobal->GetStaticMethodID(ColorClass, AY_OBFUSCATE("rgb"), AY_OBFUSCATE("(III)I"));
        return JNI.EnvGlobal->CallStaticIntMethod(ColorClass,startActivity,red,green,blue);
    }
} Color;

struct {
    struct {
        jint SDK_INT() {
            jclass VERSION = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/os/Build$VERSION"));
            jfieldID SDK_INTID = JNI.EnvGlobal->GetStaticFieldID(VERSION, AY_OBFUSCATE("SDK_INT"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetStaticIntField(VERSION,SDK_INTID);
        }
    }VERSION;
    struct {
        int M = 23;
        int LOLLIPOP = 21;
    }VERSION_CODES;
    jstring MANUFACTURER() {
        jclass BuildClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/os/Build"));
        jfieldID MANUFACTURERID = JNI.EnvGlobal->GetStaticFieldID(BuildClass, AY_OBFUSCATE("MANUFACTURER"), AY_OBFUSCATE("Ljava/lang/String;"));
        return (jstring)JNI.EnvGlobal->GetStaticObjectField(BuildClass, MANUFACTURERID);
    }
    jstring MODEL() {
        jclass BuildClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/os/Build"));
        jfieldID MODELID = JNI.EnvGlobal->GetStaticFieldID(BuildClass, AY_OBFUSCATE("MODEL"), AY_OBFUSCATE("Ljava/lang/String;"));
        return (jstring)JNI.EnvGlobal->GetStaticObjectField(BuildClass, MODELID);
    }
}Build;

struct {
    void addView(jobject Manager, jobject var1, jobject var2) {
        jclass ViewManagerClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewManager"));
        jmethodID addViewID = JNI.EnvGlobal->GetMethodID(ViewManagerClass, AY_OBFUSCATE("addView"), AY_OBFUSCATE("(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V"));
        JNI.EnvGlobal->CallVoidMethod(Manager,addViewID,var1,var2);
        JNI.EnvGlobal->DeleteLocalRef(ViewManagerClass);
    }
    void updateViewLayout(jobject Params, jobject var1, jobject var2){
        jclass ViewManagerClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewManager"));
        jmethodID updateViewLayoutID = JNI.EnvGlobal->GetMethodID(ViewManagerClass, AY_OBFUSCATE("updateViewLayout"), AY_OBFUSCATE("(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V"));
        JNI.EnvGlobal->CallVoidMethod(Params, updateViewLayoutID,var1, var2);
        JNI.EnvGlobal->DeleteLocalRef(ViewManagerClass);
    }
}ViewManager;

struct {
    int CRLF = 4;
    int DEFAULT = 0;
    int NO_CLOSE = 16;
    int NO_PADDING = 1;
    int NO_WRAP = 2;
    int URL_SAFE = 8;
    jbyteArray Decode(JNIEnv *env, const char *str) {
        jclass base64class = env->FindClass(AY_OBFUSCATE("android/util/Base64"));
        jmethodID base64constr = env->GetStaticMethodID(base64class, AY_OBFUSCATE("decode"), AY_OBFUSCATE("(Ljava/lang/String;I)[B"));
        jstring string = env->NewStringUTF(str);
        return (jbyteArray)(env->NewGlobalRef(env->CallStaticObjectMethod(base64class, base64constr,string, 0)));
    }
    jstring toBase64(JNIEnv *env, jbyteArray puk) {
        jclass Base64Class = env->FindClass(AY_OBFUSCATE("android/util/Base64"));
        jmethodID encodeToStringID = env->GetStaticMethodID(Base64Class, AY_OBFUSCATE("encodeToString"),AY_OBFUSCATE("([BI)Ljava/lang/String;"));
        return (jstring)env->CallStaticObjectMethod(Base64Class,encodeToStringID,puk,2);
    }
    jstring fromBase64String(JNIEnv *env, jstring str) {
        jclass base64class = env->FindClass(OBFUSCATE("android/util/Base64"));
        jmethodID base64constr = env->GetStaticMethodID(base64class, OBFUSCATE("decode"), OBFUSCATE("(Ljava/lang/String;I)[B"));
        jclass stringclass = env->FindClass(OBFUSCATE("java/lang/String"));
        jmethodID stringconstr = env->GetMethodID(stringclass, OBFUSCATE("<init>"), OBFUSCATE("([BLjava/lang/String;)V"));
        jstring mainstring = (jstring) env->NewObject(stringclass, stringconstr, env->CallStaticObjectMethod(base64class, base64constr, str, NO_WRAP), env->NewStringUTF(OBFUSCATE("UTF-8")));
        return mainstring;
    }
}Base64;

struct {
    jobject decodeByteArray(jbyteArray decode) {
        jclass BitmapFactoryClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/BitmapFactory"));
        jmethodID decodeByteArrayID = JNI.EnvGlobal->GetStaticMethodID(BitmapFactoryClass, AY_OBFUSCATE("decodeByteArray"), AY_OBFUSCATE("([BII)Landroid/graphics/Bitmap;"));
        int lengthImagem = JNI.EnvGlobal->GetArrayLength(decode);
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallStaticObjectMethod(BitmapFactoryClass, decodeByteArrayID,decode, 0, lengthImagem));
    }
}BitmapFactory;

struct {
    jobject ImageView(jobject ctx) {
        jclass ImageViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/ImageView"));
        jmethodID ImageViewID = JNI.EnvGlobal->GetMethodID(ImageViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ImageViewClass, ImageViewID, ctx));
    }
    void setImageBitmap(jobject thiz, jobject bm) {
        jclass ImageViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/ImageView"));
        jmethodID setImageBitmap = JNI.EnvGlobal->GetMethodID(ImageViewClass, AY_OBFUSCATE("setImageBitmap"), AY_OBFUSCATE("(Landroid/graphics/Bitmap;)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz,setImageBitmap,bm);
        JNI.EnvGlobal->DeleteLocalRef(ImageViewClass);
    }
    void setBackground(jobject imagemView, jobject GradientDrawable) {
        jclass ImageViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/ImageView"));
        jmethodID setBackground = JNI.EnvGlobal->GetMethodID(ImageViewClass, AY_OBFUSCATE("setBackground"),AY_OBFUSCATE("(Landroid/graphics/drawable/Drawable;)V"));
        JNI.EnvGlobal->CallVoidMethod(imagemView, setBackground, GradientDrawable);
        JNI.EnvGlobal->DeleteLocalRef(ImageViewClass);
    }
}ImageView;

struct {
    jobject ScrollView(jobject ctx) {
        jclass ScrollViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/ScrollView"));
        jmethodID ScrollViewClassID = JNI.EnvGlobal->GetMethodID(ScrollViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ScrollViewClass, ScrollViewClassID, ctx));
    }
}ScrollView;

struct {
    jobject TextView(JNIEnv *env, jobject ctx) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID TextViewID = env->GetMethodID(TextViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return env->NewGlobalRef(env->NewObject(TextViewClass, TextViewID, ctx));
    }
    void setText(JNIEnv *env, jobject TexttView, const char* Text) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setText = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setText"), AY_OBFUSCATE("(Ljava/lang/CharSequence;)V"));
        env->CallVoidMethod(TexttView, setText, env->NewStringUTF(Text));
        env->DeleteLocalRef(TextViewClass);
    }
    void setText(JNIEnv *env, jobject TexttView, jstring Text) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setText = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setText"), AY_OBFUSCATE("(Ljava/lang/CharSequence;)V"));
        env->CallVoidMethod(TexttView, setText, Text);
    }
    void setTextColor(JNIEnv *env, jobject TexttView, int Color) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setTextColor = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setTextColor"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(TexttView, setTextColor, Color);
        env->DeleteLocalRef(TextViewClass);
    }
    void setGravity(JNIEnv *env, jobject TexttView, int Gravidade) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setGravity = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setGravity"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(TexttView, setGravity, Gravidade);
        env->DeleteLocalRef(TextViewClass);
    }
    void setTextSize(JNIEnv *env, jobject TexttView, int TypedValue, float size) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setTextSize = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setTextSize"), AY_OBFUSCATE("(IF)V"));
        env->CallVoidMethod(TexttView,setTextSize, TypedValue, size);
        env->DeleteLocalRef(TextViewClass);
    }
    void setAllCaps(JNIEnv *env, jobject thiz, bool allCaps) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setAllCaps = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setAllCaps"), AY_OBFUSCATE("(Z)V"));
        env->CallVoidMethod(thiz, setAllCaps,allCaps);
        env->DeleteLocalRef(TextViewClass);
    }
    void setPadding(JNIEnv *env, jobject thiz, int left, int top, int right, int bottom) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setPadding = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setPadding"), AY_OBFUSCATE("(IIII)V"));
        env->CallVoidMethod(thiz, setPadding,left,top,right,bottom);
        env->DeleteLocalRef(TextViewClass);
    }
    void setLayoutParams(JNIEnv *env, jobject TextView, jobject MainParams) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setLayoutParams = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setLayoutParams"), AY_OBFUSCATE("(Landroid/view/ViewGroup$LayoutParams;)V"));
        env->CallVoidMethod(TextView, setLayoutParams, MainParams);
        env->DeleteLocalRef(linearLayoutClass);
    }
    void fromHtml(JNIEnv *env, jobject thiz, const char* text) {
        jclass html2 = env->FindClass(AY_OBFUSCATE("android/text/Html"));
        jmethodID fromHtml2 = env->GetStaticMethodID(html2, AY_OBFUSCATE("fromHtml"), AY_OBFUSCATE("(Ljava/lang/String;)Landroid/text/Spanned;"));
        jclass textView2 = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setText2 = env->GetMethodID(textView2, AY_OBFUSCATE("setText"), AY_OBFUSCATE("(Ljava/lang/CharSequence;)V"));
        jstring jstr2 = env->NewStringUTF(text);
        env->CallVoidMethod(thiz, setText2, env->CallStaticObjectMethod(html2, fromHtml2, jstr2));
        env->DeleteLocalRef(html2);
        env->DeleteLocalRef(textView2);
    }
    void setTypeface(JNIEnv *env, jobject thiz, int Typeface) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setTypeface = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setTypeface"), AY_OBFUSCATE("(Landroid/graphics/Typeface;I)V"));
        env->CallVoidMethod(thiz, setTypeface, static_cast<jobject>(NULL),Typeface);
        env->DeleteLocalRef(TextViewClass);
    }
    void setHintColor(JNIEnv *env, jobject TexttView, int Color) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setTextColor = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setHintTextColor"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView, setTextColor, Color);
    }
    void setShadowLayer(JNIEnv *env, jobject thiz, float radius, float dx, float dy, int color) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setShadowLayer = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setShadowLayer"), AY_OBFUSCATE("(FFFI)V"));
        env->CallVoidMethod(thiz,setShadowLayer,radius,dx,dy,color);
        env->DeleteLocalRef(TextViewClass);
    }
}TextView;

struct {
    jobject Button(jobject ctx) {
        jclass ButtonClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/Button"));
        jmethodID ButtonID = JNI.EnvGlobal->GetMethodID(ButtonClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ButtonClass, ButtonID, ctx));
    }

    void setTypeface(jobject thiz, int Typeface) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/Button"));
        jmethodID setTypeface = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setTypeface"), AY_OBFUSCATE("(Landroid/graphics/Typeface;I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setTypeface, static_cast<jobject>(NULL),Typeface);
    }
}Button;

struct {
    enum {
        ACTION_DOWN = 0,
        ACTION_UP = 1,
        ACTION_MOVE = 2
    };

    jint getAction(jobject motionEvent) {
        jclass motionEventClass= JNI.EnvGlobal->GetObjectClass(motionEvent);
        jmethodID getActionID = JNI.EnvGlobal->GetMethodID(motionEventClass, AY_OBFUSCATE("getAction"), AY_OBFUSCATE("()I"));
        return JNI.EnvGlobal->CallIntMethod(motionEvent, getActionID,motionEvent);
    }

    jmethodID getRawX(jobject motionEvent) {
        jclass motionEventClass= JNI.EnvGlobal->GetObjectClass(motionEvent);
        return JNI.EnvGlobal->GetMethodID(motionEventClass, AY_OBFUSCATE("getRawX"), AY_OBFUSCATE("()F"));
    }
    jmethodID getRawY(jobject motionEvent) {
        jclass motionEventClass= JNI.EnvGlobal->GetObjectClass(motionEvent);
        return JNI.EnvGlobal->GetMethodID(motionEventClass, AY_OBFUSCATE("getRawY"), AY_OBFUSCATE("()F"));
    }
} MotionEvent;

struct {
    void setOnTouchListener(jobject rootFrame) {
        jclass cls = JNI.EnvGlobal->FindClass(ClassJNI.Native);
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID onTouchListenerID = JNI.EnvGlobal->GetStaticMethodID(cls, AY_OBFUSCATE("onTouchListener"),AY_OBFUSCATE("()Landroid/view/View$OnTouchListener;"));
        jmethodID setOnTouchListenerID = JNI.EnvGlobal->GetMethodID(ViewClass, AY_OBFUSCATE("setOnTouchListener"), AY_OBFUSCATE("(Landroid/view/View$OnTouchListener;)V"));
        jobject onTouchListener = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallStaticObjectMethod(cls, onTouchListenerID));
        JNI.EnvGlobal->CallVoidMethod(rootFrame, setOnTouchListenerID, onTouchListener);
        JNI.EnvGlobal->DeleteLocalRef(cls);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
}OnTouchListener;

struct {
    jobject Handler() {
        jclass Handler = JNI.EnvGlobal->FindClass("android/os/Handler");
        jmethodID HandlerID = JNI.EnvGlobal->GetMethodID(Handler, "<init>", "()V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(Handler, HandlerID));
    }
    void StartHandler(jobject Handler) {
        jclass ClassNative = JNI.EnvGlobal->FindClass("com/lskhjfgd/patcher/Native");
        jmethodID onHandlerID = JNI.EnvGlobal->GetStaticMethodID(ClassNative, "onHandler","(Landroid/os/Handler;)V");
        JNI.EnvGlobal->CallStaticVoidMethod(ClassNative,onHandlerID,Handler);
        //JNI.EnvGlobal->DeleteLocalRef(ClassNative);
    }
    jboolean postDelayed(jobject handler, jobject ctx, jlong delayMillis) {
        jlong teste = 1;
        jclass HandlerClass = JNI.EnvGlobal->FindClass("android/os/Handler");
        jmethodID postDelayedID = JNI.EnvGlobal->GetMethodID(HandlerClass, "postDelayed", "(Ljava/lang/Runnable;J)Z");
        return JNI.EnvGlobal->CallBooleanMethod(handler,postDelayedID,ctx,delayMillis);
        //  JNI.EnvGlobal->CallVoidMethod(thiz, setTypeface, static_cast<jobject>(NULL),Typeface);
    }
}Handler;

struct {
    jobject SeekBar(jobject ctx) {
        jclass SeekBarClass = JNI.EnvGlobal->FindClass("android/widget/SeekBar");
        jmethodID SeekbarID = JNI.EnvGlobal->GetMethodID(SeekBarClass, "<init>", "(Landroid/content/Context;)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(SeekBarClass, SeekbarID, ctx));
    }
    void setMax(jobject Seekbar, int max)
    {
        jclass AbsSeekBarClass = JNI.EnvGlobal->FindClass("android/widget/AbsSeekBar");
        jmethodID setMax = JNI.EnvGlobal->GetMethodID(AbsSeekBarClass, "setMax", "(I)V");
        JNI.EnvGlobal->CallVoidMethod(Seekbar, setMax, max);
        JNI.EnvGlobal->DeleteLocalRef(AbsSeekBarClass);
    }
    void setThumb(jobject seekbar, jobject Drawable) {
        jclass AbsSeekBarClass = JNI.EnvGlobal->FindClass("android/widget/AbsSeekBar");
        jmethodID setThumbID = JNI.EnvGlobal->GetMethodID(AbsSeekBarClass, "setThumb","(Landroid/graphics/drawable/Drawable;)V");
        JNI.EnvGlobal->CallVoidMethod(seekbar, setThumbID,Drawable);
        JNI.EnvGlobal->DeleteLocalRef(AbsSeekBarClass);
    }
    void setColorFilter(jobject ctx, jobject seekbar, int color, jobject mode) {
        jclass ProgressBarClass = JNI.EnvGlobal->FindClass("android/widget/ProgressBar");
        jclass DrawableClass = JNI.EnvGlobal->FindClass("android/graphics/drawable/Drawable");
        jmethodID getProgressDrawableID = JNI.EnvGlobal->GetMethodID(ProgressBarClass, "getProgressDrawable","()Landroid/graphics/drawable/Drawable;");
        jmethodID setColorFilterID = JNI.EnvGlobal->GetMethodID(DrawableClass, "setColorFilter", "(ILandroid/graphics/PorterDuff$Mode;)V");
        jobject teste1 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(seekbar, getProgressDrawableID));
        JNI.EnvGlobal->CallVoidMethod(teste1,setColorFilterID, color,mode);
        JNI.EnvGlobal->DeleteLocalRef(ProgressBarClass);
        JNI.EnvGlobal->DeleteLocalRef(DrawableClass);
    }
    jint getProgress(jobject seek)
    {
        jclass ProgressBarClass = JNI.EnvGlobal->FindClass("android/widget/ProgressBar");
        jmethodID getProgressID = JNI.EnvGlobal->GetMethodID(ProgressBarClass, "getProgress", "()I");
        return JNI.EnvGlobal->CallIntMethod(seek,getProgressID);
    }
    void setProgress(jobject seekbar, int progress) {
        jclass ProgressBarClass = JNI.EnvGlobal->FindClass("android/widget/ProgressBar");
        jmethodID setProgress = JNI.EnvGlobal->GetMethodID(ProgressBarClass, "setProgress","(I)V");
        JNI.EnvGlobal->CallVoidMethod(seekbar, setProgress,progress);
        JNI.EnvGlobal->DeleteLocalRef(ProgressBarClass);
    }
}SeekBar;

struct {
    void setOnSeekBarChangeListener(jobject ctx, jobject seekbar, jobject textView, const char *TextSeekbar, int id) {
        jclass SeekBarlass = JNI.EnvGlobal->FindClass("android/widget/SeekBar");
        jclass FloaterMenuclazz = JNI.EnvGlobal->FindClass("com/lskhjfgd/jklsfdg/Native");
        jmethodID new_listener = JNI.EnvGlobal->GetStaticMethodID(FloaterMenuclazz, "OnSeekBarChangeListener","(Landroid/content/Context;Landroid/widget/SeekBar;Landroid/widget/TextView;Ljava/lang/String;I)Landroid/widget/SeekBar$OnSeekBarChangeListener;");
        jstring str = JNI.EnvGlobal->NewStringUTF(TextSeekbar);
        jobject listener = JNI.EnvGlobal->CallStaticObjectMethod(FloaterMenuclazz, new_listener,ctx, seekbar, textView,str,id);
        JNI.EnvGlobal->DeleteLocalRef(str);
        jmethodID setOnSeekBarChangeListener = JNI.EnvGlobal->GetMethodID(SeekBarlass, "setOnSeekBarChangeListener","(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V");
        JNI.EnvGlobal->CallVoidMethod(seekbar, setOnSeekBarChangeListener, listener);
        JNI.EnvGlobal->DeleteLocalRef(SeekBarlass);
        JNI.EnvGlobal->DeleteLocalRef(FloaterMenuclazz);
    }
}setOnSeekBarChangeListener;


struct {
    void setOnClickListener(jobject ctx, jobject obj, int id) {
        jclass Viewclass = JNI.EnvGlobal->FindClass("android/view/View");
        jclass listener_clazz = JNI.EnvGlobal->FindClass("com/lskhjfgd/jklsfdg/Native");
        jmethodID new_listener = JNI.EnvGlobal->GetStaticMethodID(listener_clazz, "onClickListener","(Landroid/content/Context;I)Landroid/view/View$OnClickListener;");
        jobject listener = JNI.EnvGlobal->CallStaticObjectMethod(listener_clazz, new_listener, ctx, id);
        jmethodID set_onclicklistener = JNI.EnvGlobal->GetMethodID(Viewclass, "setOnClickListener", "(Landroid/view/View$OnClickListener;)V");
        JNI.EnvGlobal->CallVoidMethod(obj, set_onclicklistener, listener);
        JNI.EnvGlobal->DeleteLocalRef(Viewclass);
        JNI.EnvGlobal->DeleteLocalRef(listener_clazz);
    }
}OnClickListener;

struct {
    void OnCheckedChangeListener(jobject ctx, jobject obj, int id) {
        jclass CompoundButtonClass = JNI.EnvGlobal->FindClass("android/widget/CompoundButton");
        jclass listener_clazz = JNI.EnvGlobal->FindClass("com/lskhjfgd/jklsfdg/Native");
        jmethodID new_listener = JNI.EnvGlobal->GetStaticMethodID(listener_clazz, "OnCheckedChangeListener",
                                                                  "(Landroid/content/Context;Landroid/widget/CheckBox;I)Landroid/widget/CompoundButton$OnCheckedChangeListener;");
        jobject listener = JNI.EnvGlobal->CallStaticObjectMethod(listener_clazz, new_listener,ctx,obj, id);
        jmethodID set_onclicklistener = JNI.EnvGlobal->GetMethodID(CompoundButtonClass, "setOnCheckedChangeListener","(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V");
        JNI.EnvGlobal->CallVoidMethod(obj, set_onclicklistener, listener);
        JNI.EnvGlobal->DeleteLocalRef(CompoundButtonClass);
        JNI.EnvGlobal->DeleteLocalRef(listener_clazz);
    }
}OnCheckedChangeListener;

struct {
    struct {
        jobject SRC_ATOP() {
            jclass PorterDuffClass = JNI.EnvGlobal->FindClass("android/graphics/PorterDuff$Mode");
            jfieldID SRC_ATOPID = JNI.EnvGlobal->GetStaticFieldID(PorterDuffClass, "SRC_ATOP","Landroid/graphics/PorterDuff$Mode;");
            return JNI.EnvGlobal->GetStaticObjectField(PorterDuffClass,SRC_ATOPID);
        }
        jobject MULTIPLY(){
            jclass PorterDuffClass = JNI.EnvGlobal->FindClass("android/graphics/PorterDuff$Mode");
            jfieldID MULTIPLYID = JNI.EnvGlobal->GetStaticFieldID(PorterDuffClass, "MULTIPLY","Landroid/graphics/PorterDuff$Mode;");
            return JNI.EnvGlobal->GetStaticObjectField(PorterDuffClass,MULTIPLYID);
        }
    }Mode;
}PorterDuff;

struct {
    jobject getButtonDrawable(jobject obj) {
        jclass CompoundButtonClass = JNI.EnvGlobal->FindClass("android/widget/CompoundButton");
        jmethodID getButtonDrawableID = JNI.EnvGlobal->GetMethodID(CompoundButtonClass, "getButtonDrawable","()Landroid/graphics/drawable/Drawable;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(obj, getButtonDrawableID));
    }
    void setButtonTintList(jobject Radio, jobject tint) {
        jclass CompoundButtonClass = JNI.EnvGlobal->FindClass("android/widget/CompoundButton");
        jmethodID setColorFilterID = JNI.EnvGlobal->GetMethodID(CompoundButtonClass, "setButtonTintList","(Landroid/content/res/ColorStateList;)V");
        JNI.EnvGlobal->CallVoidMethod(Radio,setColorFilterID,tint);
        JNI.EnvGlobal->DeleteLocalRef(CompoundButtonClass);
    }
    void setChecked(JNIEnv *env, jobject Radio, jboolean check) {
        jclass CompoundButtonClass = env->FindClass("android/widget/CompoundButton");
        jmethodID setCheckedID = env->GetMethodID(CompoundButtonClass, "setChecked","(Z)V");
        env->CallVoidMethod(Radio,setCheckedID,check);
        env->DeleteLocalRef(CompoundButtonClass);
    }
}CompoundButton;

struct {
    jobject valueOf(int color) {
        jclass CompoundButtonClass = JNI.EnvGlobal->FindClass("android/content/res/ColorStateList");
        jmethodID valueOfID = JNI.EnvGlobal->GetStaticMethodID(CompoundButtonClass, "valueOf","(I)Landroid/content/res/ColorStateList;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallStaticObjectMethod(CompoundButtonClass,valueOfID, color));
    }
}ColorStateList;

struct {
    void setColorFilter(jobject Drawable, int color, jobject mode) {
        jclass DrawableClass = JNI.EnvGlobal->FindClass("android/graphics/drawable/Drawable");
        jmethodID setColorFilterID = JNI.EnvGlobal->GetMethodID(DrawableClass, "setColorFilter","(ILandroid/graphics/PorterDuff$Mode;)V");
        JNI.EnvGlobal->CallVoidMethod(Drawable,setColorFilterID,color,mode);
        JNI.EnvGlobal->DeleteLocalRef(DrawableClass);
    }
}Drawable;

struct {
    jobject CheckBox(jobject ctx) {
        jclass CheckBoxClass = JNI.EnvGlobal->FindClass("android/widget/CheckBox");
        jmethodID TextViewID = JNI.EnvGlobal->GetMethodID(CheckBoxClass, "<init>", "(Landroid/content/Context;)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(CheckBoxClass, TextViewID, ctx));
    }
}CheckBox;

struct {
    jboolean canDrawOverlays(jobject ctx) {
        jclass Settigs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/provider/Settings"));
        jmethodID canDrawOverlaysID = JNI.EnvGlobal->GetStaticMethodID(Settigs, AY_OBFUSCATE("canDrawOverlays"), AY_OBFUSCATE("(Landroid/content/Context;)Z"));
        return JNI.EnvGlobal->CallStaticBooleanMethod(Settigs, canDrawOverlaysID, ctx);
    }
}Settings;

struct {
    void startActivityForResult(jobject ctx, jobject intent, jint requestCode) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jmethodID startActivityForResultID = JNI.EnvGlobal->GetMethodID(ActivityClass,AY_OBFUSCATE("startActivityForResult"),AY_OBFUSCATE("(Landroid/content/Intent;I)V"));
        JNI.EnvGlobal->CallVoidMethod(ctx,startActivityForResultID,intent,requestCode);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
    void finish(JNIEnv *env, jobject ctx) {
        jclass ActivityClass = env->FindClass("android/app/Activity");
        jmethodID finishID = env->GetMethodID(ActivityClass, "finish", "()V");
        env->CallVoidMethod(ctx, finishID);
        env->DeleteLocalRef(ActivityClass);
    }
    void startActivity(jobject ctx, jobject intent) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jmethodID startActivity = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("startActivity"), AY_OBFUSCATE("(Landroid/content/Intent;)V"));
        JNI.EnvGlobal->CallVoidMethod(ctx, startActivity, intent);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
    void setRequestedOrientation(jobject thiz, int view) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jmethodID setContentView = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("setRequestedOrientation"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setContentView, view);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
    void setActivityFlags(jobject ctx, int flags, int mask) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jclass WindowClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/Window"));
        jmethodID getWindow = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("getWindow"), AY_OBFUSCATE("()Landroid/view/Window;"));
        jmethodID setFlags = JNI.EnvGlobal->GetMethodID(WindowClass, AY_OBFUSCATE("setFlags"), AY_OBFUSCATE("(II)V"));
        jobject teste2 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getWindow));
        JNI.EnvGlobal->CallVoidMethod(teste2, setFlags, flags, mask);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
        JNI.EnvGlobal->DeleteLocalRef(WindowClass);
    }
    void setContentView(jobject thiz, jobject view) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jmethodID setContentView = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("setContentView"), AY_OBFUSCATE("(Landroid/view/View;)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setContentView, view);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
    void setSystemUiVisibility(jobject ctx, int flags) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jclass WindowClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/Window"));
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID getWindow = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("getWindow"), AY_OBFUSCATE("()Landroid/view/Window;"));
        jmethodID getDecorView = JNI.EnvGlobal->GetMethodID(WindowClass, AY_OBFUSCATE("getDecorView"), AY_OBFUSCATE("()Landroid/view/View;"));
        jmethodID setSystemUiVisibility = JNI.EnvGlobal->GetMethodID(ViewClass, AY_OBFUSCATE("setSystemUiVisibility"), AY_OBFUSCATE("(I)V"));
        jobject teste1 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getWindow));
        jobject teste2 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(teste1, getDecorView));
        JNI.EnvGlobal->CallVoidMethod(teste2,setSystemUiVisibility, flags);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
        JNI.EnvGlobal->DeleteLocalRef(WindowClass);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
    void requestWindowFeature(jobject ctx, jint id) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass("android/app/Activity");
        jmethodID requestWindowFeatureID = JNI.EnvGlobal->GetMethodID(ActivityClass, "requestWindowFeature","(I)Z");
        JNI.EnvGlobal->CallBooleanMethod(ctx, requestWindowFeatureID, id);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
}Activity;

struct {
    jobject Intent(const char *action, jobject uri) {
        jclass intentclass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/Intent"));
        jmethodID newIntent = JNI.EnvGlobal->GetMethodID(intentclass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Ljava/lang/String;Landroid/net/Uri;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(intentclass, newIntent, JNI.EnvGlobal->NewStringUTF(action),uri));
    }
    jobject Intent(JNIEnv *env, jobject packageContext, jclass StartClass) {
        jclass intentclass = env->FindClass(AY_OBFUSCATE("android/content/Intent"));
        jmethodID newIntent = env->GetMethodID(intentclass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;Ljava/lang/Class;)V"));
        return env->NewGlobalRef(env->NewObject(intentclass, newIntent,packageContext,StartClass));
    }
}Intent;

struct {
    jobject parse(const char *uriString) {
        jclass UriClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/net/Uri"));
        jmethodID Parce = JNI.EnvGlobal->GetStaticMethodID(UriClass, AY_OBFUSCATE("parse"), AY_OBFUSCATE("(Ljava/lang/String;)Landroid/net/Uri;"));
        return JNI.EnvGlobal->CallStaticObjectMethod(UriClass, Parce, JNI.EnvGlobal->NewStringUTF(uriString));
    }
}Uri;

struct {
    jobject EditText(jobject ctx) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID EditTextID = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(EditTextClass, EditTextID, ctx));
    }

    void setLayoutParams(jobject LinearLayout, jobject MainParams) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID setLayoutParams = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("setLayoutParams") ,AY_OBFUSCATE("(Landroid/view/ViewGroup$LayoutParams;)V"));
        JNI.EnvGlobal->CallVoidMethod(LinearLayout, setLayoutParams, MainParams);
        JNI.EnvGlobal->DeleteLocalRef(EditTextClass);
    }

    void setHint(jobject EditText, const char* Text) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID setHint = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("setHint"), AY_OBFUSCATE("(Ljava/lang/CharSequence;)V"));
        JNI.EnvGlobal->CallVoidMethod(EditText, setHint, JNI.EnvGlobal->NewStringUTF(Text));
        JNI.EnvGlobal->DeleteLocalRef(EditTextClass);
    }

    void setTextColor(jobject TexttView, int Color) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID setTextColor = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("setTextColor"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView, setTextColor, Color);
        JNI.EnvGlobal->DeleteLocalRef(EditTextClass);
    }

    void setTextSize(jobject TexttView, int TypedValue, float size) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID setTextSize = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("setTextSize"), AY_OBFUSCATE("(IF)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView,setTextSize, TypedValue, size);
        JNI.EnvGlobal->DeleteLocalRef(EditTextClass);
    }
    jobject toString(jobject text) {
        jclass Object = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/Object"));
        jmethodID toString = JNI.EnvGlobal->GetMethodID(Object,AY_OBFUSCATE("toString"), AY_OBFUSCATE("()Ljava/lang/String;"));
        return JNI.EnvGlobal->CallObjectMethod(text, toString);

    }
    jstring getText(jobject ctx) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID getTextID = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("getText"), AY_OBFUSCATE("()Landroid/text/Editable;"));
        jobject teste1 = JNI.EnvGlobal->CallObjectMethod(ctx, getTextID);
        return (jstring)toString(teste1);
    }
    jstring getText2(jobject editText){
        // Obtém a classe EditText
        jclass editTextClass = JNI.EnvGlobal->FindClass(OBFUSCATE("android/widget/EditText")); //Jni::env->GetObjectClass(editText);
        // Obtém o método getText da classe EditText
        jmethodID getTextMethod = JNI.EnvGlobal->GetMethodID(editTextClass, "getText", "()Ljava/lang/CharSequence;");
        // Chama o método getText e armazena o resultado em uma variável
        jobject text = JNI.EnvGlobal->CallObjectMethod(editText, getTextMethod);
        // Converte o resultado para uma string e retorna o resultado
        return (jstring) JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(text, JNI.EnvGlobal->GetMethodID(JNI.EnvGlobal->GetObjectClass(text), "toString", "()Ljava/lang/String;")));
    }

    jstring getText3(jobject Textview)
    {
        jclass TextViewClass = JNI.EnvGlobal->FindClass("android/widget/TextView");
        jmethodID getTextMethod = JNI.EnvGlobal->GetMethodID(TextViewClass, "getText", "()Ljava/lang/CharSequence;");
        jobject text = JNI.EnvGlobal->CallObjectMethod(Textview, getTextMethod);
        return (jstring) JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(text, JNI.EnvGlobal->GetMethodID(JNI.EnvGlobal->GetObjectClass(text), "toString", "()Ljava/lang/String;")));
    }
    std::string getTextstd(jobject ctx) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID getTextID = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("getText"), AY_OBFUSCATE("()Landroid/text/Editable;"));
        jclass Object = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/Object"));
        jmethodID toString = JNI.EnvGlobal->GetMethodID(Object,AY_OBFUSCATE("toString"), AY_OBFUSCATE("()Ljava/lang/String;"));
        jobject teste1 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod((jobject)ctx, getTextID));
        jstring teste2 = (jstring)JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(teste1, toString));
        return JNI.EnvGlobal->GetStringUTFChars(teste2,0);
    }
}EditText;

jobjectArray teste2(jstring user, jstring pass) {
    jobjectArray result;

    const char *suCmd[] = {JNI.EnvGlobal->GetStringUTFChars(user,0),JNI.EnvGlobal->GetStringUTFChars(pass,0)};

    size_t LenghtArray = sizeof(suCmd) / sizeof(suCmd[0]);
    result = (jobjectArray) JNI.EnvGlobal->NewObjectArray(LenghtArray, JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/String")),JNI.EnvGlobal->NewStringUTF(""));

    for (int i = 0; i < LenghtArray; i++) {
        JNI.EnvGlobal->SetObjectArrayElement(result, i, JNI.EnvGlobal->NewStringUTF(suCmd[i]));
    }
    return (result);
}

struct {
    jobject execute(jobject TaskRunner, jstring user, jstring pass) {
        jclass AsyncTaskClass = JNI.EnvGlobal->FindClass("android/os/AsyncTask");
        jmethodID executeID = JNI.EnvGlobal->GetMethodID(AsyncTaskClass, "execute", "([Ljava/lang/Object;)Landroid/os/AsyncTask;");
        return JNI.EnvGlobal->CallObjectMethod(TaskRunner,executeID,teste2(user,pass));
    }
}AsyncTask;

struct {
    jstring getText(JNIEnv *env, jobject editText){
        jclass editTextClass = env->FindClass(OBFUSCATE("android/widget/EditText"));
        jmethodID getTextMethod = env->GetMethodID(editTextClass, "getText", "()Ljava/lang/CharSequence;");
        jobject text = env->CallObjectMethod(editText, getTextMethod);
        return (jstring) env->NewGlobalRef(env->CallObjectMethod(text, env->GetMethodID(env->GetObjectClass(text), "toString", "()Ljava/lang/String;")));
    }
    jobject JSONObject(JNIEnv *env) {
        jclass dataobjs = env->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID datacons = env->GetMethodID(dataobjs, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("()V"));
        return env->NewGlobalRef(env->NewObject(dataobjs,datacons));
    }
    jobject JSONObject(JNIEnv *env, jstring str) {
        jclass dataobjs = env->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID datacons = env->GetMethodID(dataobjs, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Ljava/lang/String;)V"));
        return env->NewGlobalRef(env->NewObject(dataobjs,datacons,str));
    }
    jobject put(JNIEnv *env, jobject data, const char *name, jstring value) {
        jclass dataobjs = env->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID put1data = env->GetMethodID(dataobjs, AY_OBFUSCATE("put"),AY_OBFUSCATE("(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;"));
        return env->NewGlobalRef(env->CallObjectMethod(data,put1data,env->NewStringUTF(name), value));
    }
    jstring toString(JNIEnv *env, jobject json) {
        jclass dataobjs = env->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID tostringdata = env->GetMethodID(dataobjs, AY_OBFUSCATE("toString"), AY_OBFUSCATE("()Ljava/lang/String;"));
        return (jstring)env->NewGlobalRef(env->CallObjectMethod(json,tostringdata));
    }
    jobject get(JNIEnv *env, jobject data, const char *name) {
        jclass dataobjs = env->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID getID = env->GetMethodID(dataobjs, AY_OBFUSCATE("get"),AY_OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
        return env->NewGlobalRef(env->CallObjectMethod(data,getID,env->NewStringUTF(name)));
    }
}JSONObject;

struct {
    jstring toString(JNIEnv *env, jobject obj) {
        jclass Object = env->FindClass(AY_OBFUSCATE("java/lang/Object"));
        jmethodID toString = env->GetMethodID(Object,AY_OBFUSCATE("toString"), AY_OBFUSCATE("()Ljava/lang/String;"));
        return (jstring)env->NewGlobalRef(env->CallObjectMethod(obj,toString));
    }
}Object;

struct {
    std::string valueOf(JNIEnv *env, jobject obj) {
        jclass stringclass = env->FindClass("java/lang/String");
        jmethodID valueOfID = env->GetStaticMethodID(stringclass,"valueOf", "(Ljava/lang/Object;)Ljava/lang/String;");
        jstring final = (jstring)env->NewGlobalRef(env->CallStaticObjectMethod(stringclass,valueOfID,obj));
        return std::string(JNI.EnvGlobal->GetStringUTFChars(final,0));
    }
    jint length(JNIEnv *env, jstring str) {
        jclass stringclass = env->FindClass("java/lang/String");
        jmethodID bytestoken = env->GetMethodID(stringclass, "length", "()I");
        return env->CallIntMethod(str, bytestoken);
    }
    jboolean startsWith(JNIEnv *env, jstring obj, jstring prefix) {
        jclass StringClass = env->FindClass(AY_OBFUSCATE("java/lang/String"));
        jmethodID startsWithID = env->GetMethodID(StringClass, AY_OBFUSCATE("startsWith"),AY_OBFUSCATE("(Ljava/lang/String;)Z"));
        return env->CallBooleanMethod(obj,startsWithID,prefix);
    }
    jbyteArray getBytes(JNIEnv *env, jstring plainText, jobject charset) {
        jclass AuthClass = env->FindClass(AY_OBFUSCATE("java/lang/String"));
        jmethodID getBytesID = env->GetMethodID(AuthClass, AY_OBFUSCATE("getBytes"),AY_OBFUSCATE("(Ljava/nio/charset/Charset;)[B"));
        return (jbyteArray)env->NewGlobalRef(env->CallObjectMethod(plainText,getBytesID,charset));
    }
    jboolean isEmpty(JNIEnv *env, jobject obj) {
        jclass StringClass = env->FindClass(AY_OBFUSCATE("java/lang/String"));
        jmethodID isEmpty = env->GetMethodID(StringClass,AY_OBFUSCATE("isEmpty"), AY_OBFUSCATE("()Z"));
        return env->CallBooleanMethod(obj, isEmpty);
    }
    jboolean equals(JNIEnv *env, jobject obj, const char *str) {
        jclass StringClass = env->FindClass(AY_OBFUSCATE("java/lang/String"));
        jmethodID equals = env->GetMethodID(StringClass,AY_OBFUSCATE("equals"), AY_OBFUSCATE("(Ljava/lang/Object;)Z"));
        return env->CallBooleanMethod(obj, equals, JNI.EnvGlobal->NewStringUTF(str));
    }
}String;

struct {
    jobject getInstance(JNIEnv *env, const char *transformation) {
        jclass Cipher = env->FindClass(AY_OBFUSCATE("javax/crypto/Cipher"));
        jmethodID getInstanceID = env->GetStaticMethodID(Cipher, AY_OBFUSCATE("getInstance"), AY_OBFUSCATE("(Ljava/lang/String;)Ljavax/crypto/Cipher;"));
        return env->NewGlobalRef(env->CallStaticObjectMethod(Cipher,getInstanceID,env->NewStringUTF(transformation)));
    }
    void init(JNIEnv *env, jobject cipher, jint opmode, jobject key) {
        jclass Cipher = env->FindClass(AY_OBFUSCATE("javax/crypto/Cipher"));
        jmethodID initID = env->GetMethodID(Cipher, AY_OBFUSCATE("init"), AY_OBFUSCATE("(ILjava/security/Key;)V"));
        env->CallVoidMethod(cipher,initID,opmode,key);
        env->DeleteLocalRef(Cipher);
    }
    jbyteArray doFinal(JNIEnv *env, jobject encryptCipher, jbyteArray byte) {
        jclass Cipher = env->FindClass(AY_OBFUSCATE("javax/crypto/Cipher"));
        jmethodID doFinalID = env->GetMethodID(Cipher, AY_OBFUSCATE("doFinal"),AY_OBFUSCATE("([B)[B"));
        return (jbyteArray)env->NewGlobalRef(env->CallObjectMethod(encryptCipher,doFinalID,byte));
    }
}Cipher;

struct {
    jobject UTF_8(JNIEnv *env) {
        jclass StandardCharsets = env->FindClass(AY_OBFUSCATE("java/nio/charset/StandardCharsets"));
        jfieldID UTF_8 = env->GetStaticFieldID(StandardCharsets, AY_OBFUSCATE("UTF_8"), AY_OBFUSCATE("Ljava/nio/charset/Charset;"));
        return env->NewGlobalRef(env->GetStaticObjectField(StandardCharsets,UTF_8));
    }
}StandardCharsets;

struct {
    jobject X509EncodedKeySpec(JNIEnv *env, jbyteArray keyBytes) {
        jclass EncodedKeySpecClass = env->FindClass(AY_OBFUSCATE("java/security/spec/X509EncodedKeySpec"));
        jmethodID newX509EncodedKeySpec = env->GetMethodID(EncodedKeySpecClass, AY_OBFUSCATE("<init>"),AY_OBFUSCATE("([B)V"));
        return env->NewGlobalRef(env->NewObject(EncodedKeySpecClass,newX509EncodedKeySpec,keyBytes));
    }
}X509EncodedKeySpec;

struct {
    jobject getInstance(JNIEnv *env, const char *algorithm) {
        jclass KeyFactoryClass = env->FindClass(AY_OBFUSCATE("java/security/KeyFactory"));
        jmethodID getInstanceID = env->GetStaticMethodID(KeyFactoryClass, AY_OBFUSCATE("getInstance"),AY_OBFUSCATE("(Ljava/lang/String;)Ljava/security/KeyFactory;"));
        return env->NewGlobalRef(env->CallStaticObjectMethod(KeyFactoryClass,getInstanceID,env->NewStringUTF(algorithm)));
    }
    jobject generatePublic(JNIEnv *env, jobject KeyFactory, jobject keySpec) {
        jclass KeyFactoryClass = env->FindClass(AY_OBFUSCATE("java/security/KeyFactory"));
        jmethodID generatePublicID = env->GetMethodID(KeyFactoryClass, AY_OBFUSCATE("generatePublic"),AY_OBFUSCATE("(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;"));
        return env->NewGlobalRef(env->CallObjectMethod(KeyFactory,generatePublicID,keySpec));
    }
}KeyFactory;

struct {
    jobject getInstance(JNIEnv *env, const char *algorithm) {
        jclass MessageDigest = env->FindClass(AY_OBFUSCATE("java/security/MessageDigest"));
        jmethodID getInstance = env->GetStaticMethodID(MessageDigest, AY_OBFUSCATE("getInstance"), AY_OBFUSCATE("(Ljava/lang/String;)Ljava/security/MessageDigest;"));
        return env->NewGlobalRef(env->CallStaticObjectMethod(MessageDigest,getInstance,env->NewStringUTF(algorithm)));
    }
    void reset(JNIEnv *env, jobject md) {
        jclass MessageDigest = env->FindClass(AY_OBFUSCATE("java/security/MessageDigest"));
        jmethodID reset = env->GetMethodID(MessageDigest, AY_OBFUSCATE("reset"), AY_OBFUSCATE("()V"));
        env->CallVoidMethod(md,reset);
        env->DeleteLocalRef(MessageDigest);
    }
    void update(JNIEnv *env, jobject md, jbyteArray input) {
        jclass MessageDigest = env->FindClass(AY_OBFUSCATE("java/security/MessageDigest"));
        jmethodID update = env->GetMethodID(MessageDigest, AY_OBFUSCATE("update"), AY_OBFUSCATE("([B)V"));
        env->CallVoidMethod(md,update,input);
        env->DeleteLocalRef(MessageDigest);
    }
    jbyteArray digest(JNIEnv *env, jobject data) {
        jclass MessageDigest = env->FindClass(AY_OBFUSCATE("java/security/MessageDigest"));
        jmethodID getBytes = env->GetMethodID(MessageDigest, AY_OBFUSCATE("digest"), AY_OBFUSCATE("()[B"));
        return (jbyteArray)env->NewGlobalRef(env->CallObjectMethod(data,getBytes));
    }
}MessageDigest;

struct {
    jobject GetSharedPreferences(jobject ctx) {
        jclass cls_ContextWrapper = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jclass cls_Context = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/Context"));
        jmethodID mid_getSharedPreferences = JNI.EnvGlobal->GetMethodID(cls_ContextWrapper,AY_OBFUSCATE("getSharedPreferences"), AY_OBFUSCATE("(Ljava/lang/String;I)Landroid/content/SharedPreferences;"));
        jfieldID fid_MODE_PRIVATE = JNI.EnvGlobal->GetStaticFieldID(cls_Context, AY_OBFUSCATE("MODE_PRIVATE"), AY_OBFUSCATE("I"));
        jint int_MODE_PRIVATE = JNI.EnvGlobal->GetStaticIntField(cls_Context, fid_MODE_PRIVATE);
        jobject obj_sharedPreferences = JNI.EnvGlobal->CallObjectMethod(ctx,mid_getSharedPreferences, JNI.EnvGlobal->NewStringUTF(AY_OBFUSCATE("com.lskhjfgd.jklsfdg_preferences")), int_MODE_PRIVATE);
        return obj_sharedPreferences;
    }

    jstring read(JNIEnv *env, jobject ctx, const char *what, const char *defaultString) {
        jclass SharedPrefs = env->FindClass(AY_OBFUSCATE("android/content/SharedPreferences"));
        jmethodID getStringID = env->GetMethodID(SharedPrefs,AY_OBFUSCATE("getString"), AY_OBFUSCATE("(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;"));
        return (jstring)env->NewGlobalRef(env->CallObjectMethod(GetSharedPreferences(ctx),getStringID,env->NewStringUTF(what),env->NewStringUTF(defaultString)));
    }

    void write(jobject ctx,const char *where, jstring what) {
        jclass SharedPrefs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/SharedPreferences"));
        jclass Editor = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/SharedPreferences$Editor"));
        jmethodID editID = JNI.EnvGlobal->GetMethodID(SharedPrefs,AY_OBFUSCATE("edit"),AY_OBFUSCATE("()Landroid/content/SharedPreferences$Editor;"));
        jmethodID apply = JNI.EnvGlobal->GetMethodID(Editor,AY_OBFUSCATE("apply"), AY_OBFUSCATE("()V"));
        jobject edit = JNI.EnvGlobal->CallObjectMethod(GetSharedPreferences(ctx),editID);
        jmethodID putStringID = JNI.EnvGlobal->GetMethodID(Editor,AY_OBFUSCATE("putString"),AY_OBFUSCATE("(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;"));
        jobject putString = JNI.EnvGlobal->CallObjectMethod(edit,putStringID,JNI.EnvGlobal->NewStringUTF(where),what);
        JNI.EnvGlobal->CallVoidMethod(putString,apply);
        JNI.EnvGlobal->DeleteLocalRef(SharedPrefs);
        JNI.EnvGlobal->DeleteLocalRef(Editor);
    }
}Prefs;

struct {
    jobject getPublicKey(JNIEnv *env, jbyteArray keyBytes) {
        jobject spec = X509EncodedKeySpec.X509EncodedKeySpec(env,keyBytes);
        jobject kf = KeyFactory.getInstance(env,AY_OBFUSCATE("RSA"));
        return KeyFactory.generatePublic(env,kf,spec);
    }

    jstring encrypt(JNIEnv *env, jstring plainText, jbyteArray keyBytes) {
        jobject encryptCipher = Cipher.getInstance(env,AY_OBFUSCATE("RSA/ECB/PKCS1Padding"));
        Cipher.init(env,encryptCipher,1,getPublicKey(env,keyBytes));
        return Base64.toBase64(env,Cipher.doFinal(env,encryptCipher, String.getBytes(env,plainText, StandardCharsets.UTF_8(env))));
    }
    jobject getInstance(JNIEnv *env, const char *algorithm) {
        jclass SignatureClass = env->FindClass(AY_OBFUSCATE("java/security/Signature"));
        jmethodID AuthID = env->GetStaticMethodID(SignatureClass, AY_OBFUSCATE("getInstance"), AY_OBFUSCATE("(Ljava/lang/String;)Ljava/security/Signature;"));
        return env->NewGlobalRef(env->CallStaticObjectMethod(SignatureClass,AuthID,env->NewStringUTF(algorithm)));
    }

    void update(JNIEnv *env, jobject sign, jobject bytes) {
        jclass SignatureClass = env->FindClass(AY_OBFUSCATE("java/security/Signature"));
        jmethodID updateID = env->GetMethodID(SignatureClass, AY_OBFUSCATE("update"), AY_OBFUSCATE("([B)V"));
        env->CallVoidMethod(sign,updateID,bytes);
        env->DeleteLocalRef(SignatureClass);
    }

    void initVerify(JNIEnv *env, jobject sign, jobject publickey) {
        jclass SignatureClass = env->FindClass(AY_OBFUSCATE("java/security/Signature"));
        jmethodID initVerifyID = env->GetMethodID(SignatureClass, AY_OBFUSCATE("initVerify"), AY_OBFUSCATE("(Ljava/security/PublicKey;)V"));
        env->CallVoidMethod(sign,initVerifyID,publickey);
        env->DeleteLocalRef(SignatureClass);
    }

    jbyteArray decode(JNIEnv *env, jstring str, int frags) {
        jclass Base64class = env->FindClass(AY_OBFUSCATE("android/util/Base64"));
        jmethodID decodeID = env->GetStaticMethodID(Base64class,AY_OBFUSCATE("decode"), AY_OBFUSCATE("(Ljava/lang/String;I)[B"));
        return (jbyteArray)env->NewGlobalRef(env->CallStaticObjectMethod(Base64class,decodeID,str,frags));
    }

    jbyteArray fromBase64(JNIEnv *env, jstring s) {
        return decode(env,s,2);
    }

    jboolean verify(JNIEnv *env, jobject sign, jbyteArray signature) {
        jclass SignatureClass = env->FindClass(AY_OBFUSCATE("java/security/Signature"));
        jmethodID verifyID = env->GetMethodID(SignatureClass, AY_OBFUSCATE("verify"), AY_OBFUSCATE("([B)Z"));
        return env->CallBooleanMethod(sign,verifyID,signature);
    }

    jboolean verifysignature(JNIEnv *env, jstring plainText, jstring signature, jbyteArray keyBytes) {
        jobject publicSignature = getInstance(env,"SHA256withRSA");
        jobject PublicKey = getPublicKey(env,keyBytes);
        initVerify(env,publicSignature,PublicKey);
        jbyteArray GetBytes = String.getBytes(env,plainText,StandardCharsets.UTF_8(env));
        update(env,publicSignature,GetBytes);
        return verify(env,publicSignature,fromBase64(env,signature));
    }

    /*jobject getSystemService(JNIEnv *env, jobject ctx, const char * Context) {
        jclass ContextClass = env->FindClass(AY_OBFUSCATE("android/content/Context"));
        jmethodID getSystemServiceID = env->GetMethodID(ContextClass, AY_OBFUSCATE("getSystemService"), AY_OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
        return env->CallObjectMethod(ctx,getSystemServiceID,env->NewStringUTF(Context));
    }
    jmethodID getActiveNetworkInfo(JNIEnv *env) {
        jclass ConnectivityManagerClass = env->FindClass(AY_OBFUSCATE("android/net/ConnectivityManager"));
        return env->GetMethodID(ConnectivityManagerClass, AY_OBFUSCATE("getActiveNetworkInfo"),AY_OBFUSCATE("()Landroid/net/NetworkInfo;"));
    }

    jboolean isConnected(JNIEnv *env, jobject obj) {
        jclass NetworkInfoClass = env->FindClass(AY_OBFUSCATE("android/net/NetworkInfo"));
        jmethodID isConnectedID = env->GetMethodID(NetworkInfoClass, AY_OBFUSCATE("isConnected"), AY_OBFUSCATE("()Z"));
        return env->CallBooleanMethod(obj,isConnectedID);
    }
    jboolean isInternetAvailable(JNIEnv *env, jobject ctx) {
        jobject activeNetworkInfoID = getSystemService(env,ctx,AY_OBFUSCATE("connectivity"));
        jobject activeNetworkInfo = env->CallObjectMethod(activeNetworkInfoID,getActiveNetworkInfo(env));
        return activeNetworkInfo != nullptr && isConnected(env,activeNetworkInfo);
    }*/
    jstring bytesToHex(JNIEnv *env, jbyteArray bytes) {
        jsize length = env->GetArrayLength(bytes); // Get the length of the array
        jchar *hexChars = new jchar[length * 2]; // Create a char array to hold the hex string
        // Convert the bytes to hex
        for (int i = 0; i < length; i++) {
            // Get the byte and convert it to an int
            jbyte *b = env->GetByteArrayElements(bytes, NULL);
            int v = b[0] & 0xFF;
            // Convert the int to hex and store it in the char array
            hexChars[i * 2] = OBFUSCATE("0123456789abcdef")[v >> 4];
            hexChars[i * 2 + 1] = OBFUSCATE("0123456789abcdef")[v & 0x0F];
        }
        jstring result = env->NewString(hexChars, length * 2); // Create a String from the char array
        delete[] hexChars; // Release the memory associated with the char array
        return result;
    }

    jstring SHA256(JNIEnv *env, jstring data) {
        jobject md = MessageDigest.getInstance(env,"SHA-256");
        MessageDigest.reset(env,md);
        MessageDigest.update(env,md, String.getBytes(env,data, StandardCharsets.UTF_8(env)));
        return bytesToHex(env,MessageDigest.digest(env,md));
    }
    jobject StringBuilder(JNIEnv *env) {
        jclass StringBuilderClass = env->FindClass("java/lang/StringBuilder");
        jmethodID StringBuilderID = env->GetMethodID(StringBuilderClass, "<init>", "()V");
        return env->NewGlobalRef(env->NewObject(StringBuilderClass, StringBuilderID));
    }
    jobject InputStreamReader(JNIEnv *env, jobject in) {
        jclass InputStreamReaderClass = env->FindClass("java/io/InputStreamReader");
        jmethodID InputStreamReaderID = env->GetMethodID(InputStreamReaderClass, "<init>", "(Ljava/io/InputStream;)V");
        return env->NewGlobalRef(env->NewObject(InputStreamReaderClass, InputStreamReaderID,in));
    }
    jobject BufferedReader(JNIEnv *env, jobject in) {
        jclass BufferedReaderClass = env->FindClass("java/io/BufferedReader");
        jmethodID BufferedReaderID = env->GetMethodID(BufferedReaderClass, "<init>", "(Ljava/io/Reader;)V");
        return env->NewGlobalRef(env->NewObject(BufferedReaderClass, BufferedReaderID,in));
    }
    jstring readLine(JNIEnv *env, jobject in) {
        jclass BufferedReaderClass = env->FindClass("java/io/BufferedReader");
        jmethodID readLineID = env->GetMethodID(BufferedReaderClass, "readLine", "()Ljava/lang/String;");
        return (jstring)env->NewGlobalRef(env->CallObjectMethod(in,readLineID));
    }
    jobject append(JNIEnv *env, jobject obj, jstring str) {
        jclass StringBuilderClass = env->FindClass("java/lang/StringBuilder");
        jmethodID appendID = env->GetMethodID(StringBuilderClass,"append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
        return env->NewGlobalRef(env->CallObjectMethod(obj,appendID,str));
    }

    jstring toString(JNIEnv *env, jobject obj) {
        jclass Object = env->FindClass("java/lang/StringBuilder");
        jmethodID toString = env->GetMethodID(Object,"toString", "()Ljava/lang/String;");
        return (jstring)env->NewGlobalRef(env->CallObjectMethod(obj, toString));
    }
    jstring readStream(JNIEnv *env, jobject in) {
        jobject response = StringBuilder(env);
        jobject teste = InputStreamReader(env,in);
        jobject reader = BufferedReader(env,teste);

        if(BufferedReader(env,teste)) {
            jstring line;
            while((line = readLine(env,reader))) {
                append(env,response,line);
            }
        }
        return toString(env,response);
    }
    jstring profileDecrypt(JNIEnv *env, jstring data, jstring sign) {
        jclass UtilsDark = env->FindClass("com/lskhjfgd/jklsfdg/Utils");
        jmethodID readstringm = env->GetStaticMethodID(UtilsDark, "profileDecrypt","(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
        return (jstring)env->NewGlobalRef(env->CallStaticObjectMethod(UtilsDark, readstringm, data,sign));
    }
}Utils;

struct {
    jstring toString(JNIEnv *env, jbyteArray a) {
        jclass UtilsDark = env->FindClass("java/util/Arrays");
        jmethodID toStringID = env->GetStaticMethodID(UtilsDark, "toString","([B)Ljava/lang/String;");
        return (jstring)env->NewGlobalRef(env->CallStaticObjectMethod(UtilsDark,toStringID,a));
    }
}Arrays;

struct {
    void setCancelable(JNIEnv *env, jobject dialog, jboolean flag) {
        jclass DialogClass = env->FindClass("android/app/Dialog");
        jmethodID setCancelableID = env->GetMethodID(DialogClass,"setCancelable", "(Z)V");
        env->CallVoidMethod(dialog,setCancelableID,flag);
        env->DeleteLocalRef(DialogClass);
    }
    void show(JNIEnv *env, jobject dialog) {
        jclass DialogClass = env->FindClass("android/app/Dialog");
        jmethodID showID = env->GetMethodID(DialogClass,"show", "()V");
        env->CallVoidMethod(dialog,showID);
        env->DeleteLocalRef(DialogClass);
    }
    void dismiss(JNIEnv *env, jobject dialog) {
        jclass DialogClass = env->FindClass("android/app/Dialog");
        jmethodID dismissID = env->GetMethodID(DialogClass,"dismiss", "()V");
        env->CallVoidMethod(dialog,dismissID);
        env->DeleteLocalRef(DialogClass);
    }
}Dialog;

struct {
    int THEME_DEVICE_DEFAULT_DARK = 4;
    int THEME_DEVICE_DEFAULT_LIGHT = 5;
    int THEME_HOLO_DARK = 2;
    int THEME_HOLO_LIGHT = 3;
    int THEME_TRADITIONAL = 1;

    jobject AlertDialog(JNIEnv *env, jobject ctx) {
        jclass AlertDialog$Builder = env->FindClass("android/app/AlertDialog$Builder");
        jmethodID AlertDialogID = env->GetMethodID(AlertDialog$Builder,"<init>","(Landroid/content/Context;)V");
        return env->NewGlobalRef(env->NewObject(AlertDialog$Builder,AlertDialogID,ctx));
    }
    void setView(JNIEnv *env, jobject dialog, jobject linearView) {
        jclass AlertDialog$Builder = env->FindClass("android/app/AlertDialog");
        jmethodID setViewID = env->GetMethodID(AlertDialog$Builder,"setView","(Landroid/view/View;)V");
        env->CallVoidMethod(dialog,setViewID,linearView);
        env->DeleteLocalRef(AlertDialog$Builder);
    }
    jobject create(JNIEnv *env, jobject dialog) {
        jclass AlertDialog$Builder = env->FindClass("android/app/AlertDialog$Builder");
        jmethodID createID = env->GetMethodID(AlertDialog$Builder,"create","()Landroid/app/AlertDialog;");
        return env->NewGlobalRef(env->CallObjectMethod(dialog,createID));
    }
}AlertDialog;


struct {
    jobject ProgressDialog(JNIEnv *env, jobject ctx, jint theme) {
        jclass ProgressDialogClass = env->FindClass("android/app/ProgressDialog");
        jmethodID ProgressDialogID = env->GetMethodID(ProgressDialogClass,"<init>","(Landroid/content/Context;I)V");
        return env->NewGlobalRef(env->NewObject(ProgressDialogClass,ProgressDialogID,ctx,theme));
    }
    void setMessage(JNIEnv *env, jobject dialog, const char *message) {
        jclass ProgressDialogClass = env->FindClass("android/app/ProgressDialog");
        jmethodID setMessageID = env->GetMethodID(ProgressDialogClass,"setMessage","(Ljava/lang/CharSequence;)V");
        env->CallVoidMethod(dialog,setMessageID, env->NewStringUTF(message));
        env->DeleteLocalRef(ProgressDialogClass);
    }
}ProgressDialog;

jstring getDeviceName(JNIEnv *env);
jstring getDeviceName(JNIEnv *env){
    jclass BuILDOS = env->FindClass(("android/os/Build"));
    jfieldID manofacturerid = env->GetStaticFieldID(BuILDOS, ("MANUFACTURER"), ("Ljava/lang/String;"));
    jstring MANUFACTURERSTRING = (jstring)env->GetStaticObjectField(BuILDOS, manofacturerid);

    jfieldID modelid = env->GetStaticFieldID(BuILDOS, ("MODEL"), ("Ljava/lang/String;"));
    jstring MODELSTRING = (jstring)env->GetStaticObjectField(BuILDOS, modelid);

    jclass stringclass = env->FindClass(("java/lang/String"));
    jmethodID stringconstr = env->GetMethodID(stringclass, ("<init>"), ("(Ljava/lang/String;)V"));
    jobject mainstring =  env->NewObject(stringclass, stringconstr, MODELSTRING);

    jmethodID startwhisid = env->GetMethodID(stringclass, ("startsWith"), ("(Ljava/lang/String;)Z"));

    jboolean jboolean1 = env->CallBooleanMethod(mainstring, startwhisid, MANUFACTURERSTRING);

    if (jboolean1){
        return MODELSTRING;
    } else {
        std::stringstream zx;
        zx << env->GetStringUTFChars(MANUFACTURERSTRING, 0);
        zx << (" ");
        zx << env->GetStringUTFChars(MODELSTRING, 0);
        std::string zax = zx.str();
        return env->NewStringUTF(zax.c_str());
    }
}

jstring getUniqueId(JNIEnv *env, jobject ctx);
jstring getUniqueId(JNIEnv *env, jobject ctx){

    jclass Secureclass = env->FindClass("android/provider/Settings$Secure");
    jclass ctxclass = env->FindClass(("android/content/Context"));
    jmethodID getmetodouiie = env->GetMethodID(ctxclass, ("getContentResolver"), ("()Landroid/content/ContentResolver;"));
    jobject getContentResolver = env->CallObjectMethod(ctx, getmetodouiie);

    jmethodID getstringid = env->GetStaticMethodID(Secureclass, ("getString"), ("(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;"));

    jclass BuILDOS = env->FindClass(("android/os/Build"));
    jfieldID harid = env->GetStaticFieldID(BuILDOS, ("HARDWARE"), ("Ljava/lang/String;"));
    jstring HARDWARESTRING = (jstring)env->GetStaticObjectField(BuILDOS, harid);

    jfieldID androidididi = env->GetStaticFieldID(Secureclass, ("ANDROID_ID"), ("Ljava/lang/String;"));

    jstring android_id = (jstring) env->GetStaticObjectField(Secureclass, androidididi);

    jstring getStrigSecure = (jstring) env->CallStaticObjectMethod(Secureclass, getstringid, getContentResolver, android_id);

    std::stringstream zx;
    zx << env->GetStringUTFChars(getDeviceName(env), 0);
    zx << env->GetStringUTFChars(getStrigSecure, 0);
    zx << env->GetStringUTFChars(HARDWARESTRING, 0);
    std::string zax = zx.str();

    jclass stringclass = env->FindClass(("java/lang/String"));
    jmethodID stringconstr = env->GetMethodID(stringclass, ("<init>"), ("(Ljava/lang/String;)V"));
    jobject mainstring =  env->NewObject(stringclass, stringconstr, env->NewStringUTF(zax.c_str()));

    jmethodID replace = env->GetMethodID(stringclass, ("replace"), ("(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;"));
    env->CallObjectMethod(mainstring, replace, env->NewStringUTF((" ")),env->NewStringUTF(("")));

    jmethodID jbytessss = env->GetMethodID(stringclass, ("getBytes"), ("()[B"));
    jbyteArray bytesstruing = (jbyteArray)env->CallObjectMethod(mainstring, jbytessss);

    jclass UIDDDDCLASS = env->FindClass(("java/util/UUID"));
    jmethodID nameUIDDDD = env->GetStaticMethodID(UIDDDDCLASS, ("nameUUIDFromBytes"), ("([B)Ljava/util/UUID;"));
    jobject uidstring = env->CallStaticObjectMethod(UIDDDDCLASS, nameUIDDDD, bytesstruing);

    jmethodID ofvalueid = env->GetStaticMethodID(stringclass, ("valueOf"), ("(Ljava/lang/Object;)Ljava/lang/String;"));

    jmethodID stringconstr2 = env->GetMethodID(stringclass, ("<init>"), ("(Ljava/lang/String;)V"));
    jobject mainstring2 =  env->NewObject(stringclass, stringconstr2, env->CallStaticObjectMethod(stringclass, ofvalueid, uidstring));

    jmethodID replaceeee = env->GetMethodID(stringclass, ("replace"), ("(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;"));

    return (jstring)env->CallObjectMethod(mainstring2, replaceeee, env->NewStringUTF(("-")),env->NewStringUTF(("")));
}

struct {
    void Toast(jobject thiz, const char *text, int length) {
        jstring jstr = JNI.EnvGlobal->NewStringUTF(text);
        jclass toast = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID methodMakeText =JNI.EnvGlobal->GetStaticMethodID(toast,AY_OBFUSCATE("makeText"),AY_OBFUSCATE("(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;"));
        jobject toastobj = JNI.EnvGlobal->CallStaticObjectMethod(toast, methodMakeText,thiz, jstr, length);
        jmethodID methodShow = JNI.EnvGlobal->GetMethodID(toast, AY_OBFUSCATE("show"), AY_OBFUSCATE("()V"));
        JNI.EnvGlobal->CallVoidMethod(toastobj, methodShow);
        JNI.EnvGlobal->DeleteLocalRef(toast);
    }
    jobject Toast(jobject ctx){
        jclass ToastClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID ToastID = JNI.EnvGlobal->GetMethodID(ToastClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ToastClass, ToastID, ctx));
    }
    void setDuration(JNIEnv *env, jobject toast, int duration)
    {
        jclass ToastClass = env->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID setGravity = env->GetMethodID(ToastClass, AY_OBFUSCATE("setDuration"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(toast, setGravity, duration);
        JNI.EnvGlobal->DeleteLocalRef(ToastClass);
    }

    void setView(JNIEnv *env, jobject toast, jobject view)
    {
        jclass ToastClass = env->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID setGravity = env->GetMethodID(ToastClass, AY_OBFUSCATE("setView"), AY_OBFUSCATE("(Landroid/view/View;)V"));
        env->CallVoidMethod(toast, setGravity, view);
        JNI.EnvGlobal->DeleteLocalRef(ToastClass);
    }

    void show(JNIEnv *env, jobject toast) {
        jclass ToastClass = env->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID setGravity = env->GetMethodID(ToastClass, AY_OBFUSCATE("show"), AY_OBFUSCATE("()V"));
        env->CallVoidMethod(toast, setGravity);
        JNI.EnvGlobal->DeleteLocalRef(ToastClass);
    }
}Toast;

struct {
    jobject DrawESP(jobject ctx) {
        jclass ESPViewClass = JNI.EnvGlobal->FindClass(ClassJNI.DrawESP);
        jmethodID ESPViewInit = JNI.EnvGlobal->GetMethodID(ESPViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ESPViewClass, ESPViewInit, ctx));
    }
    void Invoke(JNIEnv *env, jobject ctx, jobject Service, jbyteArray DcLoader) {
        jclass DataClass = env->FindClass("com/lskhjfgd/jklsfdg/Data");
        jmethodID invokeID = env->GetStaticMethodID(DataClass,"Init","(Landroid/content/Context;Landroid/app/Service;[B)V");
        env->CallStaticVoidMethod(DataClass,invokeID,ctx,Service,DcLoader);
        env->DeleteLocalRef(DataClass);
    }
    void LoadBaseDex(JNIEnv *env, jobject tmpClass) {
        jclass DataClass = env->FindClass("com/lskhjfgd/jklsfdg/Data");
        jmethodID LoadBaseDexID = env->GetStaticMethodID(DataClass,"LoadBaseDex","(Ljava/lang/Class;)V");
        env->CallStaticVoidMethod(DataClass,LoadBaseDexID,tmpClass);
        env->DeleteLocalRef(DataClass);
    }
    void Alerta(JNIEnv *env) {
        jclass MainActivity = env->FindClass("com/lskhjfgd/jklsfdg/MainActivity");
        jmethodID AlertaID = env->GetStaticMethodID(MainActivity,"Alerta","()V");
        env->CallStaticVoidMethod(MainActivity,AlertaID);
        env->DeleteLocalRef(MainActivity);
    }
}Java;

struct {
    jobject RadioButton(JNIEnv *env, jobject ctx) {
        jclass TextViewClass = env->FindClass("android/widget/RadioButton");
        jmethodID TextViewID = env->GetMethodID(TextViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return env->NewGlobalRef(env->NewObject(TextViewClass, TextViewID, ctx));
    }
}RadioButton;

void CustomToast(JNIEnv *env, const char *name, jobject ctx) {
    jobject ln = LinearLayout.LinearLayout(env,ctx);
    View.setPadding(env,ln, ConvertDP(env,ctx,12), ConvertDP(env,ctx,12),  ConvertDP(env,ctx,12),  ConvertDP(env,ctx,12));
    View.setAlpha(ln,0.9f);

    jobject mGrad = GradientDrawable.GradientDrawable(ctx);
    GradientDrawable.setColor(mGrad,Color.parseColor(AY_OBFUSCATE("#FFFFFF")));
    GradientDrawable.setCornerRadii(mGrad, ConvertDP(env,ctx,5),ConvertDP(env,ctx,5),ConvertDP(env,ctx,5),ConvertDP(env,ctx,5));
    LinearLayout.setBackground(env,ln,mGrad);

    jobject tv = TextView.TextView(env,ctx);
    jobject params = LinearLayout.LayoutParams(env,LayoutParams.WRAP_CONTENT,LayoutParams.MATCH_PARENT);
    LinearLayout.setLayoutParams(env,tv,params);
    TextView.setText(env,tv,name);
    TextView.setTextColor(env,tv,Color.parseColor(AY_OBFUSCATE("#000000")));

    ViewGroup.addView2(JNI.EnvGlobal,ln,tv);

    jobject toast = Toast.Toast(ctx);
    Toast.setDuration(JNI.EnvGlobal,toast,ToastLength::LENGTH_LONG);
    Toast.setView(JNI.EnvGlobal,toast,ln);
    Toast.show(JNI.EnvGlobal,toast);
}

jint getLayoutType() {
    if (Build.VERSION.SDK_INT() >= 26)
    {
        return 2038;
    }
    if (Build.VERSION.SDK_INT() >= 24)
    {
        return 2002;
    }
    if (Build.VERSION.SDK_INT() >= 23)
    {
        return 2005;
    }
    return 2003;
}

struct {
    struct {
        struct {
            jobject Builder(JNIEnv *env) {
                jclass BuilderClass = env->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
                jmethodID BuilderID = env->GetMethodID(BuilderClass,"<init>", "()V");
                return env->NewGlobalRef(env->NewObject(BuilderClass, BuilderID));
            }
            jobject permitAll(JNIEnv *env, jobject builder) {
                jclass BuilderClass = env->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
                jmethodID permitAllID = env->GetMethodID(BuilderClass,"permitAll","()Landroid/os/StrictMode$ThreadPolicy$Builder;");
                return env->NewGlobalRef(env->CallObjectMethod(builder, permitAllID));;
            }
            jobject build(JNIEnv *env, jobject permitAll) {
                jclass BuilderClass = env->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
                jmethodID buildID = env->GetMethodID(BuilderClass,"build","()Landroid/os/StrictMode$ThreadPolicy;");
                return env->NewGlobalRef(env->CallObjectMethod(permitAll, buildID));;
            }
        }Builder;
    }ThreadPolicy;

    void setThreadPolicy(JNIEnv *env, jobject policy) {
        jclass StrictModeclass = env->FindClass("android/os/StrictMode");
        jmethodID setThreadPolicy = env->GetStaticMethodID(StrictModeclass,"setThreadPolicy","(Landroid/os/StrictMode$ThreadPolicy;)V");
        env->CallStaticVoidMethod(StrictModeclass,setThreadPolicy, policy);
        env->DeleteLocalRef(StrictModeclass);
    }
}StrictMode;

struct {
    jobject getInputStream(JNIEnv *env, jobject urlConnection) {
        jclass httpcon = env->FindClass("java/net/HttpURLConnection");
        jmethodID impu = env->GetMethodID(httpcon, "getInputStream", "()Ljava/io/InputStream;");
        return env->NewGlobalRef(env->CallObjectMethod(urlConnection, impu));;
    }
    void setRequestMethod(JNIEnv *env, jobject urlConnection, const char *method) {
        jclass httpcon = env->FindClass("java/net/HttpURLConnection");
        jmethodID getmthodurl = env->GetMethodID(httpcon, "setRequestMethod", "(Ljava/lang/String;)V");
        env->CallVoidMethod(urlConnection, getmthodurl, env->NewStringUTF(method));
        env->DeleteLocalRef(httpcon);
    }
    void setDoOutput(JNIEnv *env, jobject urlConnection, jboolean dooutput){
        jclass httpcon = env->FindClass("java/net/HttpURLConnection");
        jmethodID setDoOutputid = env->GetMethodID(httpcon, "setDoOutput", "(Z)V");
        env->CallVoidMethod(urlConnection, setDoOutputid, dooutput);
        env->DeleteLocalRef(httpcon);
    }
    void setRequestProperty(JNIEnv *env, jobject urlConnection, const char *key, const char *value) {
        jclass httpcon = env->FindClass("java/net/HttpURLConnection");
        jmethodID setrequespr = env->GetMethodID(httpcon, "setRequestProperty", "(Ljava/lang/String;Ljava/lang/String;)V");
        env->CallVoidMethod(urlConnection, setrequespr, env->NewStringUTF(key), env->NewStringUTF(value));
        env->DeleteLocalRef(httpcon);
    }
    void setFixedLengthStreamingMode(JNIEnv *env, jobject urlConnection, int contentLength){
        jclass httpcon = env->FindClass("java/net/HttpURLConnection");
        jmethodID setFixed = env->GetMethodID(httpcon, "setFixedLengthStreamingMode", "(I)V");
        env->CallVoidMethod(urlConnection, setFixed, contentLength);
        env->DeleteLocalRef(httpcon);
    }
    jobject getOutputStream(JNIEnv *env, jobject urlConnection) {
        jclass httpcon = env->FindClass("java/net/HttpURLConnection");
        jmethodID outhphtppp = env->GetMethodID(httpcon, "getOutputStream", "()Ljava/io/OutputStream;");
        return env->NewGlobalRef(env->CallObjectMethod(urlConnection, outhphtppp));
    }
}HttpURLConnection;

struct {
    jobject getOutputStream(JNIEnv *env, jobject urlConnection) {
        jclass httpcon = env->FindClass("java/net/URLConnection");
        jmethodID outhphtppp = env->GetMethodID(httpcon, "getOutputStream", "()Ljava/io/OutputStream;");
        return env->NewGlobalRef(env->CallObjectMethod(urlConnection, outhphtppp));
    }
}URLConnection;

struct {
    jobject HttpURLConnection(JNIEnv *env, const char *url) {
        jclass urlclass = env->FindClass("java/net/URL");
        jmethodID urlcontruc = env->GetMethodID(urlclass, "<init>", "(Ljava/lang/String;)V");
        jobject mainurl = env->NewObject(urlclass, urlcontruc, env->NewStringUTF(url));
        return env->NewGlobalRef(env->NewObject(urlclass, urlcontruc, env->NewStringUTF(url)));
    }

    jobject openConnection(JNIEnv *env, jobject http) {
        jclass urlclass = env->FindClass("java/net/URL");
        jmethodID openConnectionID = env->GetMethodID(urlclass,"openConnection","()Ljava/net/URLConnection;");
        return env->NewGlobalRef(env->CallObjectMethod(http, openConnectionID));;
    }
}URL;

struct {
    jobject BufferedInputStream(jobject in) {
        jclass BufferedInputStreamClass = JNI.EnvGlobal->FindClass("java/io/BufferedInputStream");
        jmethodID BufferedInputStreamID = JNI.EnvGlobal->GetMethodID(BufferedInputStreamClass, "<init>", "(Ljava/io/InputStream;)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(BufferedInputStreamClass, BufferedInputStreamID,in));
    }
}BufferedInputStream;

struct {
    jobject InputStreamReader(jobject in, const char* utf) {
        jclass InputStreamReaderClass = JNI.EnvGlobal->FindClass("java/io/InputStreamReader");
        jmethodID InputStreamReaderID = JNI.EnvGlobal->GetMethodID(InputStreamReaderClass, "<init>", "(Ljava/io/InputStream;Ljava/lang/String;)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(InputStreamReaderClass, InputStreamReaderID,in, JNI.EnvGlobal->NewStringUTF(utf)));
    }
}InputStreamReader;

struct {
    jobject BufferedReader(jobject in, int sz) {
        jclass BufferedReaderClass = JNI.EnvGlobal->FindClass("java/io/BufferedReader");
        jmethodID BufferedReaderID = JNI.EnvGlobal->GetMethodID(BufferedReaderClass, "<init>", "(Ljava/io/Reader;I)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(BufferedReaderClass, BufferedReaderID,in,sz));
    }
    jstring readLine(jobject in) {
        jclass BufferedReaderClass = JNI.EnvGlobal->FindClass("java/io/BufferedReader");
        jmethodID readLineID = JNI.EnvGlobal->GetMethodID(BufferedReaderClass, "readLine", "()Ljava/lang/String;");
        return (jstring)JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(in, readLineID));;
    }
}BufferedReader;

struct {
    jobject StringBuilder() {
        jclass StringBuilderClass = JNI.EnvGlobal->FindClass("java/lang/StringBuilder");
        jmethodID StringBuilderID = JNI.EnvGlobal->GetMethodID(StringBuilderClass, "<init>", "()V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(StringBuilderClass, StringBuilderID));
    }
    jobject append(jobject obj, jstring str) {
        jclass StringBuilderClass = JNI.EnvGlobal->FindClass("java/lang/StringBuilder");
        jmethodID appendID = JNI.EnvGlobal->GetMethodID(StringBuilderClass,"append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(obj, appendID,str));;
    }
    jstring toString(jobject obj) {
        jclass Object = JNI.EnvGlobal->FindClass("java/lang/StringBuilder");
        jmethodID toString = JNI.EnvGlobal->GetMethodID(Object,"toString", "()Ljava/lang/String;");
        return (jstring) JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(obj, toString));;
    }
}StringBuilder;

struct {
    jobject getRuntime() {
        jclass runtime = JNI.EnvGlobal->FindClass(OBFUSCATE("java/lang/Runtime"));
        jmethodID getruntime = JNI.EnvGlobal->GetStaticMethodID(runtime, OBFUSCATE("getRuntime"), OBFUSCATE("()Ljava/lang/Runtime;"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallStaticObjectMethod(runtime, getruntime));;
    }

    jobject exec(jobject Runtime, const char *cmd) {
        jclass runtime = JNI.EnvGlobal->FindClass(OBFUSCATE("java/lang/Runtime"));
        jmethodID exec = JNI.EnvGlobal->GetMethodID(runtime, OBFUSCATE("exec"), OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Process;"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(Runtime,exec,JNI.EnvGlobal->NewStringUTF(cmd)));;
    }
}Runtime;

struct {
    jobject PrintWriter(JNIEnv *env, jobject out) {
        jclass printclass = env->FindClass("java/io/PrintWriter");
        jmethodID contrprin = env->GetMethodID(printclass, "<init>", "(Ljava/io/OutputStream;)V");
        return env->NewGlobalRef(env->NewObject(printclass, contrprin, out));
    }
    void write(JNIEnv *env, jobject out, jstring str) {
        jclass printclass = env->FindClass("java/io/PrintWriter");
        jmethodID write = env->GetMethodID(printclass,"write","(Ljava/lang/String;)V");
        env->CallVoidMethod(out,write,str);
        env->DeleteLocalRef(printclass);
    }
    void print(JNIEnv *env, jobject out, jstring str) {
        jclass printclass = env->FindClass("java/io/PrintWriter");
        jmethodID print = env->GetMethodID(printclass,"print","(Ljava/lang/String;)V");
        env->CallVoidMethod(out,print,str);
        env->DeleteLocalRef(printclass);
    }
    void close(JNIEnv *env, jobject out) {
        jclass printclass = env->FindClass("java/io/PrintWriter");
        jmethodID close = env->GetMethodID(printclass,"close", "()V");
        env->CallVoidMethod(out,close);
        env->DeleteLocalRef(printclass);
    }
}PrintWriter;

struct {
    jobject FileOutputStream(JNIEnv *env, jstring name) {
        jclass FileOutputStreamClass = env->FindClass("java/io/FileOutputStream");
        jmethodID FileOutputStreamID = env->GetMethodID(FileOutputStreamClass, "<init>", "(Ljava/lang/String;)V");
        return env->NewGlobalRef(env->NewObject(FileOutputStreamClass, FileOutputStreamID, name));
    }
    void write(JNIEnv *env, jobject obj, jbyteArray dexdata) {
        jclass FileOutputStreamClass = env->FindClass("java/io/FileOutputStream");
        jmethodID writeID = env->GetMethodID(FileOutputStreamClass,"write", "([B)V");
        env->CallVoidMethod(obj,writeID,dexdata);
        env->DeleteLocalRef(FileOutputStreamClass);
    }
    void close(JNIEnv *env, jobject obj) {
        jclass FileOutputStreamClass = env->FindClass("java/io/FileOutputStream");
        jmethodID closeID = env->GetMethodID(FileOutputStreamClass,"close", "()V");
        env->CallVoidMethod(obj,closeID);
        env->DeleteLocalRef(FileOutputStreamClass);
    }
}FileOutputStream;

struct {
    void flush(JNIEnv *env, jobject obj) {
        jclass OutputStreamClass = env->FindClass("java/io/OutputStream");
        jmethodID flushID = env->GetMethodID(OutputStreamClass,"flush", "()V");
        env->CallVoidMethod(obj,flushID);
        env->DeleteLocalRef(OutputStreamClass);
    }
}OutputStream;


std::string jstringTostring(jstring jStr) {
    if (!jStr)
        return "";
    const jclass stringClass = JNI.EnvGlobal->GetObjectClass(jStr);
    const jmethodID getBytes = JNI.EnvGlobal->GetMethodID(stringClass, OBFUSCATE("getBytes"), OBFUSCATE("(Ljava/lang/String;)[B"));
    const jbyteArray stringJbytes = (jbyteArray) JNI.EnvGlobal->CallObjectMethod(jStr, getBytes, JNI.EnvGlobal->NewStringUTF(OBFUSCATE("UTF-8")));

    size_t length = (size_t) JNI.EnvGlobal->GetArrayLength(stringJbytes);
    jbyte* pBytes = JNI.EnvGlobal->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    JNI.EnvGlobal->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    JNI.EnvGlobal->DeleteLocalRef(stringJbytes);
    JNI.EnvGlobal->DeleteLocalRef(stringClass);
    return ret;
}

jboolean isSafeConnection() {
    jclass java_util_ArrayList  = JNI.EnvGlobal->FindClass(OBFUSCATE("java/util/ArrayList"));
    jmethodID java_util_ArrayList_size = JNI.EnvGlobal->GetMethodID (java_util_ArrayList, OBFUSCATE("size"), OBFUSCATE("()I"));
    jmethodID java_util_ArrayList_get  = JNI.EnvGlobal->GetMethodID(java_util_ArrayList, OBFUSCATE("get"), OBFUSCATE("(I)Ljava/lang/Object;"));
    jclass Collections = JNI.EnvGlobal->FindClass(OBFUSCATE("java/util/Collections"));
    jclass NetworkInterface = JNI.EnvGlobal->FindClass(OBFUSCATE("java/net/NetworkInterface"));

    jmethodID _getNetworkInterfaces = JNI.EnvGlobal->GetStaticMethodID(NetworkInterface, OBFUSCATE("getNetworkInterfaces"), OBFUSCATE("()Ljava/util/Enumeration;"));
    jobject interfaces = JNI.EnvGlobal->CallStaticObjectMethod(NetworkInterface, _getNetworkInterfaces);
    jmethodID _list = JNI.EnvGlobal->GetStaticMethodID(Collections, OBFUSCATE("list"), OBFUSCATE("(Ljava/util/Enumeration;)Ljava/util/ArrayList;"));
    jmethodID _isUp = JNI.EnvGlobal->GetMethodID(NetworkInterface, OBFUSCATE("isUp"), OBFUSCATE("()Z"));
    jmethodID _getName = JNI.EnvGlobal->GetMethodID(NetworkInterface, OBFUSCATE("getName"), OBFUSCATE("()Ljava/lang/String;"));

    jobject interfaces_asList = JNI.EnvGlobal->CallStaticObjectMethod(Collections, _list, interfaces);

    jint len = JNI.EnvGlobal->CallIntMethod(interfaces_asList,java_util_ArrayList_size );
    std::string name = "";
    for (jint i = 0; i < len; i++) {
        jobject network = JNI.EnvGlobal->CallObjectMethod(interfaces_asList, java_util_ArrayList_get, i);
        jboolean isUpped = JNI.EnvGlobal->CallBooleanMethod(network, _isUp);
        if (isUpped){
            jstring jname = reinterpret_cast<jstring>(JNI.EnvGlobal->CallObjectMethod(network, _getName));
            name = jstringTostring(jname);

        }
        if (name.find(OBFUSCATE("tun")) != std::string::npos || name.find(OBFUSCATE("ppp"))  != std::string::npos || name.find(OBFUSCATE("pptp"))  != std::string::npos){
            return JNI_FALSE;
        }
    }
    return JNI_TRUE;
}

struct {
    jobject getActiveNetwork(jobject connectivityManager) {
        jclass ConnectivityManager = JNI.EnvGlobal->FindClass("android/net/ConnectivityManager");
        jmethodID getActiveNetworkID = JNI.EnvGlobal->GetMethodID(ConnectivityManager, "getActiveNetwork","()Landroid/net/Network;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(connectivityManager,getActiveNetworkID));
    }
    jobject getNetworkCapabilities(jobject activeNetwork, jobject network) {
        jclass ConnectivityManager = JNI.EnvGlobal->FindClass("android/net/ConnectivityManager");
        jmethodID getNetworkCapabilitiesID = JNI.EnvGlobal->GetMethodID(ConnectivityManager, "getNetworkCapabilities","(Landroid/net/Network;)Landroid/net/NetworkCapabilities;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(activeNetwork,getNetworkCapabilitiesID,network));
    }
}ConnectivityManager;

struct {
    int TRANSPORT_VPN = 4;

    jboolean hasTransport(jobject caps, int transportType) {
        jclass NetworkCapabilities = JNI.EnvGlobal->FindClass("android/net/NetworkCapabilities");
        jmethodID NetworkCapabilitiesID = JNI.EnvGlobal->GetMethodID(NetworkCapabilities, "hasTransport","(I)Z");
        return JNI.EnvGlobal->CallBooleanMethod(caps,NetworkCapabilitiesID,transportType);

    }
}NetworkCapabilities;

struct {
    jobject BaseDexClassLoader(JNIEnv *env, jstring dexPath, jobject optimizedDirectory, const char *librarySearchPath, jobject parent) {
        jclass BaseDexClassLoaderClass = env->FindClass("dalvik/system/BaseDexClassLoader");
        jmethodID BaseDexClassLoaderID = env->GetMethodID(BaseDexClassLoaderClass, "<init>","(Ljava/lang/String;Ljava/io/File;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
        return env->NewGlobalRef(env->NewObject(BaseDexClassLoaderClass, BaseDexClassLoaderID, dexPath,optimizedDirectory,env->NewStringUTF(librarySearchPath),parent));
    }
}BaseDexClassLoader;

struct {
    jobject loadClass(JNIEnv *env, jobject LoaderCache, const char *name) {
        jclass ClassLoader = env->FindClass("java/lang/ClassLoader");
        jmethodID loadClassID = env->GetMethodID(ClassLoader, "loadClass","(Ljava/lang/String;)Ljava/lang/Class;");
        return env->NewGlobalRef(env->CallObjectMethod(LoaderCache, loadClassID, env->NewStringUTF(name)));
    }
}ClassLoader;

const char *getRequestURL(JNIEnv *env, const char *url) {
    jobject policy = StrictMode.ThreadPolicy.Builder.build(env,StrictMode.ThreadPolicy.Builder.permitAll(env,StrictMode.ThreadPolicy.Builder.Builder(env)));
    StrictMode.setThreadPolicy(env,policy);
    jobject urlConnection = URL.openConnection(env,URL.HttpURLConnection(env,url));

    jobject in = BufferedInputStream.BufferedInputStream(HttpURLConnection.getInputStream(JNI.EnvGlobal,urlConnection));
    jobject reader = BufferedReader.BufferedReader(InputStreamReader.InputStreamReader(in,"UTF-8"),8);
    jobject sb = StringBuilder.StringBuilder();

    jstring line;
    while((line = BufferedReader.readLine(reader)) != nullptr) {
        StringBuilder.append(sb,line);
    }
    jstring str = StringBuilder.toString(sb);
    return JNI.EnvGlobal->GetStringUTFChars(str,0);
}

void setDialog(jobject ctx, JNIEnv *env, const char *title, const char *msg){
    jclass Alert = env->FindClass(OBFUSCATE("android/app/AlertDialog$Builder"));
    jmethodID AlertCons = env->GetMethodID(Alert, OBFUSCATE("<init>"), OBFUSCATE("(Landroid/content/Context;)V"));

    jobject MainAlert = env->NewObject(Alert, AlertCons, ctx);

    jmethodID setTitle = env->GetMethodID(Alert, OBFUSCATE("setTitle"), OBFUSCATE("(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setTitle, env->NewStringUTF(title));

    jclass Html = env->FindClass("android/text/Html");
    jmethodID fromHtmlID = env->GetStaticMethodID(Html, "fromHtml", "(Ljava/lang/String;)Landroid/text/Spanned;");
    jobject teste1 = env->CallStaticObjectMethod(Html,fromHtmlID,env->NewStringUTF(msg));

    jmethodID setMsg = env->GetMethodID(Alert, OBFUSCATE("setMessage"), OBFUSCATE("(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setMsg, teste1);

    jmethodID setCa = env->GetMethodID(Alert, OBFUSCATE("setCancelable"), OBFUSCATE("(Z)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setCa, false);

    jmethodID setPB = env->GetMethodID(Alert, "setPositiveButton", "(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;");
    env->CallObjectMethod(MainAlert, setPB, env->NewStringUTF("Ok"), static_cast<jobject>(NULL));

    jmethodID create = env->GetMethodID(Alert, OBFUSCATE("create"), OBFUSCATE("()Landroid/app/AlertDialog;"));
    jobject creaetob = env->CallObjectMethod(MainAlert, create);

    jclass AlertN = env->FindClass(OBFUSCATE("android/app/AlertDialog"));

    jmethodID show = env->GetMethodID(AlertN, OBFUSCATE("show"), OBFUSCATE("()V"));
    env->CallVoidMethod(creaetob, show);
}

std::string nativeLibraryDir(JNIEnv *env, jobject ctx) {
    jclass ContextClass = env->FindClass("android/content/Context");
    jmethodID getApplicationInfoID = env->GetMethodID(ContextClass,"getApplicationInfo","()Landroid/content/pm/ApplicationInfo;");
    jobject getApplicationInfo = env->CallObjectMethod(ctx,getApplicationInfoID);
    jclass getApplicationInfoAcess = env->GetObjectClass(getApplicationInfo);
    jfieldID nativeLibraryDirID = env->GetFieldID(getApplicationInfoAcess, "nativeLibraryDir", "Ljava/lang/String;");
    jstring nativeLibraryDir= static_cast<jstring>(env->GetObjectField(getApplicationInfo,nativeLibraryDirID));
    return std::string(env->GetStringUTFChars(nativeLibraryDir,0));
}

jstring toBase64(JNIEnv *env, jstring str);
jstring toBase64(JNIEnv *env, jstring str){
    jclass base64class = env->FindClass(("android/util/Base64"));
    jmethodID base64constr = env->GetStaticMethodID(base64class, ("encodeToString"), ("([BI)Ljava/lang/String;"));

    jclass stringclass = env->FindClass(("java/lang/String"));
    jmethodID stringconstr = env->GetMethodID(stringclass, ("<init>"), ("(Ljava/lang/String;)V"));
    jstring mainstring = (jstring) env->NewObject(stringclass, stringconstr, str);

    jmethodID getbyts = env->GetMethodID(stringclass, ("getBytes"), ("(Ljava/lang/String;)[B"));
    jobjectArray bytestrings = (jobjectArray) env->CallObjectMethod(mainstring, getbyts, env->NewStringUTF(("UTF_8")));

    jstring final = (jstring) env->CallStaticObjectMethod(base64class, base64constr ,bytestrings, 2);
    return final;
}

jstring fromBase64String(JNIEnv *env, jstring str);
jstring fromBase64String(JNIEnv *env, jstring str){
    jclass base64class = env->FindClass("android/util/Base64");
    jmethodID base64constr = env->GetStaticMethodID(base64class, "decode", "(Ljava/lang/String;I)[B");
    jclass stringclass = env->FindClass("java/lang/String");
    jmethodID stringconstr = env->GetMethodID(stringclass, "<init>", "([BLjava/lang/String;)V");
    jstring mainstring = (jstring) env->NewObject(stringclass, stringconstr, env->CallStaticObjectMethod(base64class, base64constr, str, 2), env->NewStringUTF("UTF-8"));
    return mainstring;

}

void AletDialogMSG(JNIEnv *env, jobject ctx, const char *msg) {
    jobject dialog = AlertDialog.create(env,AlertDialog.AlertDialog(env,ctx));

    jobject LinearMsg = LinearLayout.LinearLayout(env,ctx);
    LinearLayout.setLayoutParams(env,LinearMsg, LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT,ConvertDP(env,ctx,200)));
    View.setBackgroundColor(env,LinearMsg,0xFFFFFFFF);
    LinearLayout.setGravity(env,LinearMsg,Gravity.CENTER);
    LinearLayout.setOrientation(env,LinearMsg,Orientation.VERTICAL);
    View.setPadding(env,LinearMsg,ConvertDP(env,ctx,50),ConvertDP(env,ctx,50),ConvertDP(env,ctx,50),ConvertDP(env,ctx,50));

    const char *LogoBase64 = OBFUSCATE("R0lGODlhyADIAPfcAP///wAAAAEBAQMDAyYmJoiIiOXl5cbGxqenp1JSUmtrazo6OhcXFwoKCgwMDBgYGDk5OUtLS19fX3R0dJycnJCQkK+vr8LCwtPT0+7u7uHh4f7+/vj4+Pz8/DAwMOfn5/39/fX19fr6+vn5+eDg4NDQ0MnJyfb29vHx8fDw8JKSkvf39+/v77S0tNnZ2enp6dXV1ZmZmejo6PLy8uTk5OPj462trezs7Lm5ufPz856enouLi+rq6lRUVLu7u8fHx8vLy9bW1p2dnW1tbdTU1Ovr66CgoNfX18jIyNvb29zc3MTExL+/v+Li4qurq3t7e93d3aioqLGxsYyMjFhYWGZmZpaWlt7e3pWVlZeXl9LS0qmpqcDAwI2Njbi4uLKysnh4eJqamj09PYmJicHBwc7OznBwcCoqKrCwsMXFxdra2np6enZ2ds3Nzc/Pz6ysrJOTk1dXV76+vikpKczMzKWlpbOzs729vaGhoZSUlLe3ty8vLx0dHX9/f6qqqqOjo4WFhSsrK7q6und3d319fX5+fhEREW9vb4KCgmFhYWVlZVtbW3l5eaSkpFNTU4aGhkRERExMTCgoKEVFRWlpaR8fH2xsbJubm2JiYjMzM0hISGhoaC0tLba2toSEhFZWVhYWFmpqaj8/Pz4+Pjg4OI6OjnFxcSEhIU5OTlBQUIeHhw8PD3JycjY2NgYGBjIyMg0NDUZGRjc3N11dXaKiok9PT2RkZI+Pj2NjYzQ0NDs7OwgICIGBgUlJSUFBQSQkJCMjI3NzcwUFBSwsLFVVVU1NTQICAhwcHB4eHkJCQhoaGkdHRxMTE1xcXICAgDExMV5eXg4ODkBAQCUlJRAQEAcHByIiIhQUFBsbGxUVFVpaWgkJCf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjIxQTRDOTVENkNGQzExRUFBMzlFQTVERTg4ODM3MTJFIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjIxQTRDOTVFNkNGQzExRUFBMzlFQTVERTg4ODM3MTJFIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MjFBNEM5NUI2Q0ZDMTFFQUEzOUVBNURFODg4MzcxMkUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MjFBNEM5NUM2Q0ZDMTFFQUEzOUVBNURFODg4MzcxMkUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvKycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KRkI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllYV1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAfHh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQFBADcACwAAAAAyADIAEAI/wABCBxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFiwpPBGmRh42ECKQIMKO2S4BJAbuoMSNAKoIENnlaBDmBsabNmzghuqiyTUCAn0CDChV60tWvWFUehbFxIQgJAymipjBAIsgFG2EeVYn1y9XJoWDBCthWxUXOs2ghrggVNqjJB3lWpJ1bcEWeBybbAg0ll67fhhPyilV256/hmneU+RQrYMJhnEtKhpWF4rFlwyhkhUW55PLCFptHdfBMujSADqMWD21xWcmAsBdMy55N8ELYAUrSigDl1uS1vrQlVhA81GRwiiuufQUKSoTNX8t/RjhucbhqogKoW4zQW8CvihtWXf83SUt7deLYzVukhV7Aqg0RW0QP8F19Reubs9uv+Ks764fUzEfCfhThxxiBFJHQHTUQMTNfEAgKh15vEUoURHfMQBTEfK6AUOFDBhan34cNgeBKdxBGpMl4AlRB4ouGVdGeJhYRMp8wGcCo400ZCNMdITf1EVYeOwoUInYVFAlAHmH1QdcQYc0xgpJUDjTCHGENQVoo85lkRpUVmtGeSaGot8V1bnlQBJikFeEBmkAJsIWSBcD5k0nGTDAlmxWNMIExE8ZZAJ8NtcBHoENd0wcPO/LQxzV63SkAH/8RSlcRfYAyX6ScduqpXieB0sealpZq6qmoprojBoRAh+insIL/atIvhGCg6mUdYGGIndgJIEwEf1QWHAp/RCDMpmIZgsVotyp0xZv5CTBHbM0KdMEcyN7pwRWEUvKqIVxUixEXhuRHSYR58GrIEeI+dkS5YhFpWgeBjPnMnu3SNsIzYwbCLF0uADoeKCHseCSFO4agaW/GmIVTH2OaUOXBcY6opAljOmnRCtt0pwKfFEtKqArzbQMcRBG0ByShIQdgnKU29jYdyvOFUWrLL1saRnczOxRWCje/mjOhKYQFkQTzPRI0r0Pz+Uh3EkQERnu15GtqLSyCQVEv3fViNZu9zOf1RSQA2hsmEwstQJJUYtKeMQPmRMWYzhisNtswOjMmFYel/2F2xY19PVtgb6dBGzSbnUKD4GnRcAqv0Hy4CNOu/MH4Q394tdkipa6AeKQCUNHErU3MzSk0J1+ewRADZItdNb2okBtpSqjQSzWvdjfAEDleTlcStveUe6yenrRN7En4rvzyzDfv/POmriCHJ5qINzzx3a2iiSdypA69XyLYEIsx2JdvflDGxGKDc99LpIQEfxfvXRW0QPEXFLRU4SqsAhgjweztA8AMLEE+0I0FExL7kAkwITxOGcMSM/BdHnDHNAE0wBkFM1UInNEAtVVDXqraQkle9QwiXI4Iz4jWLubEJhAsIlpm+NfzOiCmVy3CQzAqQH4CsbgAIoQG9eLVoP8ItII39YtUPnRIEYLYHQ94zzQrOMOYBGC5JFrkD10SwBme+BhLsKh/hbHiTe4gsPFY4jIZ2FV7CiHGuRTii4boHV2CED+XWXB0MBKC0HaxoyZ0cDzGSNFZiiC86zyAixHCmcVgtIIHdGcbSLRJLFi0DUYpSZFV4kED4xQLm2CgS3AAEybBBIcv2soiKuhONYSVtgryCQUUvM7HKOIJFtWHTaPk0/7i5ImJIKA9D7BULvmEl94gICIn6JLDQKa2UrngizR5CBvm4yJhNrNUVegOGyBCgPlQi2XXtJRtAEcAiPxsafkxVdHAApERXscA6DxQqQzQHT4+hBTzsUE8RWT/Kht0hxQQSRd6OmlNV5YqFt0BoUMONZ43lAoHFYioRCUag7gR6g0s4oNEiDAm+7XRPFAYkwklIocvAvCjtFFCl5hQkSSEpYoolc0fwpK8i0iiPXsAkx4raAQw7YFFkriJDb6osSIpEm87glh79JkTGbUHqS86qlG/WM20IK07fIMRC3rgga569as9YCWJ5taeqBkGC10SxkhjWhMiHKs7WPDMDPgQFmXIgK0UkYEywsKHCMrGDbjrjivChVeGcMEr7amGG8xzBeV80QNiLSwKjMiia3ArQoT74inY9dEjPG6KjimSt141irs+TwajiNa5LLUEx25GGIXAl7hGUIi3/zLmGoarlhukyClQVACROlpBBXgDujMsdnlpCCKv3LIHOMjRPBmAw085dZJA5FaMQaBCGfkngAfUghBvcAEOLQICF7yBELXAy3IZ0z8qCLKwCCFBH2663vPZ146S6INF4ZuTDRABAWCIAEPvaxI+RAAMCCACfPjL4AY7+MEQjrCEJ0zhCuPEvwAW8PU6VeADJ3jBFsYI8HpRyPtydyzICzFD5EtfE7sYO/ndL4UxpakNv9jEoRrVg7O73U+95bvhHW9Fynve9NoYcMZwL1tX17oNmwR2sitN7W7nZJPs7rnfS67rmOvc/UR3ugYUgHWfZ6gNK8qSMHIUpAxIKd/ttv++AfAtcBk5XOoaN1+eo67oSGe6SKHuVq0VGmxlWy3a2lZE1+iMqeqUnzwR+mt+Ethmhsim0fKqtNBDrWqrNLnNVM6KmWMa53SU2e5sFqWezWLgPnSmzaipsG5iGgv309gpQrbBk82iZe3zueIoLsKOg5x2APvFwVb4sF1SbHC4NKYvqbiG3SmTaeZaV9OqGAB65atfL+O3L4b22gQpdZyMcd3DoLU9agX3Qdz6xbgeBkpgkZK6EXKlLBnmqoDL6otQ4Iiv+jsTs4QRWcdj1rmQtTd109EwX6Q3Fun7LE4dD1RJtPCoUhUtQgKLQmFU8RcxCSxFtclQuxNyhYezSEr/HQ9Ta1I2FqGNSh2HkdsAKeOKtDhOOW1lOn0K1JrYCD04EuXJldSjH13EpWCBKcyHrqSZgqWmW+saMw0KNrFVpKTdOenSqQ4mlbaHpRNZUW+qKnSug8mpbqHRRjsKTrNXKaQsWutDpjaeqrV954TCWm+0FpEBx8mhd5fnRTMakQ2hp0MFxTufTISigM6HoIHn50ETerSk7TM9pXoa4AreEHyiZ+VTVzyf/Ak4gD7EQeh5Ly6ZDqYLAS5DD3FnUOCZeMETip6As6fPwAK02kveUuscijl5f3mEAd9oABJQ8StmKgUBjkEP6SZ6vhl62/NpnJISQDkfkjL02Mz3mNcZ/88gMk30kH31bj+7NiEiH/Tcsvq/J1R/AFephiSzPctkEw6EdgpnQjMi3ecWKzNvOREzFdMzD/FL4xFMBJgTxVQxxxQR4cEi5dGANsEe4/EeE1FLvfF+FmgRu3QnvTQRHOMxH3gRJIMeJlMRqQQ4q3SCFAFL8xFwFOEq14GAMMh93eGBE/FJ7RFKVcJv/uZvPcACpGRKNaFUvZFAl3Q3VYIxLFJyFjFJvVFJW5cfE/cimtQekFcTu9Edv9GEFZSFH5Ic89EcOUFI83FIUzWGRdJIjxRJNxEw7UEwduOGOqIwLNIwc0FHLNIAePQiOqA2OqAjfvQ2qncWrgEbOWgtt/+hdWmRRl3CRjD4Rt0RR49BL/byaNe2L/0iQ4fhRd1hDGGkbmTUJWdUGqAhFqJxbajBK/VHGlE0RUo3YVg0Jlt0HOkSFusyYe+yGRtHG0WURYEgh/C1RLY2Z6YRGbxCGfyVGZuxC+W2HzrEGDzEVkD0KpT2IaPFi4RlReRiLkXiQjAEis1DQ65zQ2BCOJtBGM6TGBX0bXwiQq5TQieUQuy1QqnyLBUkLdR3K9fiOgKwLeIyQWpzQRlUKhv0R/nxQYKzFtTVXXFRJXahXpzCF8szQAUkK9uAQCSyQJukFw+0bc6TK7sSkb4CLJFlGsRiLFsWJ8piju3zPnUUkb9APx56RRf4oz9Hdif+A4kotRM9UT5FcRRJsRRN8RRSMRVVcRVZsRVd8ZKgQhb592DhMz43lpVgkT7rQ4CsYoNaSTwnQSun1IgDsQJMQD3WA2dEaRLa4wlMoIxmiRAawREeARIiQRIngRIqwRIuARMyEU1zOZiEWZiGeZgLERAAIfkEBQQA3AAsBwAHALoAugBACP8AuQkcSLCgwYMIEypcyHBhhxQpatSA2KGhxYsYM2rcyJGhmlCwBogcSbKkyZMmGzRAybLlSVih1HScSbOmQR3MXI6chiWEzZ8XQ2CZplMkMx1Ak2IEMcRlgy4blEqdSnBDl5Uth4Cg2vFWS0gnuIody/AEpJa3yBJ0xHKM2rdwMY5h6UhpHJRiosbdyxfjBjEoqXAMhXJL38OINW5BGaphlZOGRiSeTPniCEMnqyBsdfJJ5c+gGT452YogmZMPAIRezboggAcnyQhE+aK17dYvUHLrgDLF7d+gU6CsiOfkAuDIJy84iWdgiGon9SSfDlfPyWo+C4LIdlIC9e9TJZz/zLZVYYqQJqfpBc8+4waiJmH5zmiC2/Ug7fMfDALdJLf6P+nAUg+q6YccAD2whJRaFrjCUiorGJjYCqmw5IoFoHUwi0tnlCAhUCWc4dIsFbWXAVtFcbLFeu1tsAUnRQ3gSAYfcpRGAsLE2NIDCyzyRBg2LBHECyl0AMCRADz0QhBL2BDGE4ssAJuOKAmTQBo1/gYCCWTggQgmkUBAQE4sMUMABJFggggeZJBQXpbtgZBGIbnkSOWdOgmTSyFpvAmnWCTEYR+V2UgQBY19ZRCFBNxRyQ0VJPxpUAaa6FQNKyxIWhALrPTXkiaIAidCLC0ZgoOmSeGAGUuxiIAYCJWi/5QJCqj2hUImLGnip1JosNRFrbZ1wRIaNSWDUgzAghcDSslg1AZKniUr4WgntaFQLt1JK6l4JuVikCInKaJtreCaJK5AkZwUxrjAhnFSJNzUcFIDBbKrKQBYlVQDNxCcZIO9qNpwEgQDyXKSCgD/qcJJshTEg50lRZGwhFGcJAwPCSmAkhITf6cESgpclAZKBJTY8WodEIASlh2FgAxKk7B4clwbTIISMtlJRQhLlRgw81QGVMISIYd1UCHPWvxskRZCP2iybWUAo5MY+I0bBGAuAVMGqiEQ4gCVhkiAw9OJdYCDBKvG6AAhOSudEAhyVNEonnTrmE0VcuzqtlghkP+hgiKyoFd3fLIoogIZbe9NVRsKTDn44zo+oIC1ijN0gbF1C7OH4VxkUG9HAGTAxd97QIxnMhcojcbLOk7ih2StjeCHzToiQyywPvBRFAF1yKzfBnWorBMfPkhogeAoGYKF78lugEXaKMGCIXIiHD1gDpVzk0OCLaXiKmggbMhSJj5nn5ABuLI0i95wlYF8SZBEaD5GK5wV/dZv+cCSIUnPT5MW0CtJ8ajyATKZ5AzY819SciCikzDjA0nZGWSaoECxNCGAIyEaTSKAElZUEC6sQEkEOJIAlNThg3ypA0oSgBEroAQLKEQMFlBiBYaAwHEkmUQMKUO7kjyAfQIZ2Un/TrVDyuBgZQfxw0lcEaoiTiYDDjKJHwpyGpMII1NO/AwLTDcS2QgEBO8TCReyGBouvKQ8iDjJIsi4mkWcBBECEV5JlsDG0CzhJATghnBOQrY6lq03ezTJ5/yYGAD0hhsGJEnVCDmZIDhQIJjoDCMpQ62SYEIgJEBJEye5lwygJFICWZhJ9sDJw+zhYAUxg3FKuZd+mcQMBynEePrISql0YG4kKURC5ICSKdaSKko8iRwY8oqTgCJxv6RJCEBxkldcRA1cFAknmJdMv8DIijLJyAVQAgosVhMjLGDmSVLXERJ87SQw/CZDZngSB4DSJtxLiYfUWZAS5KskPaBKBnS3/0QiVhMHUTQJHzapT6mhRBdhmeQJdMESYBD0LU1hiS5o5UQUMJQlQwDNCUhloTEMcm8AGENATxKLhN7mFiM9ySQo2LEm9BAlrkhLnCToElDEgJYS6kAMxOkSQgDRQB+Ip05A8QSOJUcJT+CpTnoAwYmZgIN4csUCnqAHb3KFBXp4wgJSGqMIAEiBKbBCMSFHVjy9wgrz+SUP/GCGVniqrC2pRivM4AeM0TMjW+rSl8I0ppaYCU1qYpOb7pqRtbb1rXBFiVzpald6wk1uiU3s3fI2ybCONbKYbSZai3ijaOKJRz4CkpCIZCQkKYlJToKSlMhqJZZl76l0kypVrUoVrP9qlatF8erPunbOGIVtbJ8xG9qotDZkAiuoOiKqUZGDVKW6hKnAOlGMVETN6bjomjqZEZxAQNOW2BSnBtKpc1HiUwNFbWqLlNbVdKI19qDUJSs9mUtdEtPkaIhD83RbiEYE3slstCWu8Oj8QorbkZQ0NEZrSSX690Gmda+/cInoQSlaRItmJTENepD82EghC00vLhkw6EkQysmFNvShVOluSXr2y6ANjSz7hKk/kwlQlAyUKwJCCYHuiiAFTUWoJGlAfglrTx0nxWUwq+43a3Yz42rEnC8kbELYaRJ30qQ+95GyQvhzkv90ZJvGpK2WDRJOlJAzI0I0ScnGzJCUIRH/I9A8yTTZ3JANYJckwshmQ85zEvXQ2SLveUlaF3JZkhzzz0EZ7wCcyRCNnWS5iG7Ix04SMoXw8iS+jPRFgmmSYSJkO9nSdEa4VRLyIESWJskGhEVtkFueRJcGedhJJMbqjFTMio0diCpNcpxaa2Q5ryzIc6Lja41YxyTYIYgoS0LKYmvklCZBWMFQ6eyMLJskDcOkJqudEU+eBJTF4TW3f80cSEpy3BipJEkuyS9/oRsjAjMJwRB5kvS+eyGONAkzdnPIe+95OIEsyUf9fRBDniQi8xo4wV1zz5FMZDgLd8ghaRNxheSmy9yQI0noWHGE3FHN6FJXxxHiLpPAixtp/zTJGkduEDeaBI7cqKIPFR7x18Tmi2EcwBhZPhAzxudN5SrJuXjOjaCTZOgxt5iYI77FmxOEMyaJFsvVPZLSFITTJGEiy6GI6YNgyyTeGTmpSeKtg6S5JDMm+BFP4lqDPMYkkYn4ZTKjkBuqNOIvHckPF/Ksc9+b6iOh3EJciM57U7kkNbQIYU5imHEv5iSNwUgJT3LCaqvwJCzUCOZMgqxiL+skzeIIVE3iwVqH8CQjnAkV8KLku/4lMDZR8UgMwVI6X5C8QOkVSn7FZmGh5HZAKSBKEChlBqLkgVRB0UncQs+5oKQuYtFf8hhcSwCyZIBjgdX4KDzJW+Xqp1NxH+5L4sfI+rEEFvjji1fGb1InmgUtkwlfS8hXRPS1ZH2fGVWp0m4+VbWkVaxRPc+VQIqzPS7hPVoiYSjxFK0nLVbRcCahFdRxPC6hPA34J86DQSUhPflBKZaCKcnCKYh1EqBSI7mzO72TJcCjcSxBPKiCEzHCE072G0IBHzpxFOOyOlTiOrDDGrKTdy5hOx1DAoJxJ4VyKIehKIxyJ4/yTkpzOYOjOZzjOTUROqOjCKUzOKjzQR+Rc4mlEplFEjChZ1nEODgUhmUlOYLHSnJCJ56FhhazJ32CaH3zN4ETWbBQOIczg/72EBExEUWSMAEBACH5BAUEANwALAcABwC6ALoAQAj/ALkJHEiwoMGDCBMqXMjwIIcPGC5csGPHjx+KEjF84NCwo8ePIEOKHHlwRZg9DVKqXMmypcuUDwKRIjVJk6ZJMwM9eMmzp8o9l1aQHEq0KMEbcXyqpKaICACjUD0CIKKImtKUcW5E3erRwDOfHtw85Uq27EAAbjz4fGbA7EgRmnp2Geu2rl2FALr01CTirsAb1l4aouO3sOGPdAy9tKYVaghgLxHRPUy5ckcAiF4CCxFyA8qW1GpYHk06ZA2rLfdsYDjMZYTJpWPLXggggsthB2c4cIljtu/fDHG4dDBjICCXVIArX36QiktA3C64DASbuXXfAAK5lOiSVPXr4EkD/yC1nVsVl2DCq48NxmWVgT6Gp1hP33CK3S19GCzxEk/9/2Xh8VIJCwnnkiLfAaggQwAo8lJvIB3nEicjLGjhQSNw8hJ0UCX1khEX1mcET3EUZktPlyQYYmEAXNKTLb9BMY1Pm3C2omOb+DQNFBb6EJhS1AxRg4rrAVDDEKj5ZI1+N4aUgSd8XNUTLB5QAYYVehAhgwgAdDmZlwCIIAMRelgBBhUewCIlT3x4kkGT1oVgAgKAVKFJINms2UA2gWhSBSAImGAjnAqWoAokauqpqJSwQKIKgYTatUEjkOm5Si1CDDmakULUsoqiwDSyWqQE3XGMUpy0QOSNALSgoU/H3P+xHgzI9CQGD6RyxYMYPSEDA2kanPrSBKvm6hYAE/B0jAZuUfLSKm4Ye50bn7pECVEZgOJSNEFIq2AQ0bgEypsdTfGgt00a2NIUCaWQKEtCoJurEC7BMh9BrbXkn7zSCtgSbgLl2RIR/KJLhEvZcOOHS5oULG9cLfnBwUsyOCytDC9xFMJLbVhMahsvDcqNDS+J5vGKNbxkQ0JqtSTJqCfXt4EkLnngkScvVVFszJue55InQyHB01w8i6fXS0iUxYEuJIJQtFkgeOiSLhxVBsWPL8VxwtMenSC1S9bwCN4U7z6LSIUFj4BItTzBwm6uSPC6JiwR4MHCzn4BwAIeEZT/rZQYSXPNkBaE5Lvo4YoOQ4gWghs2gw+AxGE44jwNEwcgPhTXeF0vTNEy5aAr6sEUL2zOEAqIaHu4A5kMgUcbJ+DN4Alt4DFEJvgtCgoiKDyNgrNrSgIIDbJTBgANgNC8JiW9G8tBskpFUwUJxYMHAAlVhKvUBFUvKMKJPokCQ/UrAgCDKErZ0ld4MGDtkiFGkI8uAEYoxpM1v/5mwIw8TeC06QsBAfReMo22jMZcQ5MfAPPSk7f5ZYAtEcPWAAiVE8jNJRNwCxp4sgkFUpBBOXoJGqKygQuyRBT/+6BdQIA+l4gBZiJBwU5c0gIVVqYFL3lA8z6ygiiBhgQ2JA0J/5K0Ej4IpSPOcQnBghibgyFncBti4m8k1BLGIUQVLlkFC6QIHBawbSWqOMghXJILD3LRLADIhUsOURAqriQTZjwjGjPxnIGYoF4TlKNyTuC3lJhAIBBjiRX0aB0rMIwbH3jJ+gipHBG85AN26E4cGVmW8biEIi6ZBCWZM4lLYsAlD5jkJrcCgBmyBAPc0E5L9DDK3+hhOgJBQM1E2UqiAOBzK0HAQL6mkiHUMjZDcEmJCNIKlzDil6NhhEtacRBIuKQWtERmQwBQC5dAIiGEqBcNpHkXGvSxAYRYyAu+qJJiRJObBAFAMbJYuoa4yCVDOKc0ARBMl1wiJJlxSSTkOf9KAEQiMkNpxLPyh86PwICcKmkEVFBwipd4QGQFPUgIcLmSU+xwK/F5CQFwFdGB8IAAPGGSXe7wzZR4gp8xAwDOXgILWVUGBV/hyUkZqdKePOOipSlBrXhCAMLYkA4g5QkyIGUdFATyWV1I4clA0AWEskQTOKWPBpimlEgEAaWxAUAQ/qkUXTCLVGhoqJSKgQMYgmcDOFinlE4xwpOFABCm1FMuGIGDFGA1nSnAASPUuKgHAAKiAEQrFZwausIqZRVUKGtEU2CDQ7Qid4ZVigNacQgb3KujIZETneyEJz3xyU+AEhRmRcJYx0I2sj2ZbGUvO1rCTQ61hlWcFVspWML/wva2DUCsYrn4JB9SjkpWwpKWuOSldHpJTGQyE5pKuqY2kct0b43rmuZa17ueJa97PZxfAWuxuOmJbnaz7kf0xjfmujBwBQvrmshq1uugVa1XYau3fHSVIGnqQkZC0lWWRKipXsWq4rWMVrnqE6+GiGw+WcXZHKY226bEbQAyaoKTWjSmOrgBUFWPjGjEXZ6FIIQ82ZF1dNqTngYRqL0i6myu1hOtndFrPQmbbGDak5kSsqY8uSlpwPeSFLWyRS+qDEllGmB+4bheLr3L0poW0ajxhGp2yahLNjpabnw0pG7h5UpAVOWBjChrZGGoQzuM2Ym+xKJREdpLiNZlgzAQ/2lGEWgWCdrmgxz0JQodihtXQqE6LyRDURxJPluyTz8ziMAsQYRIVtoSnRl6mj5rCdA+EoaXxPPRl6lnS+7ZEXWxBEGYloqDeNOQcbrEnKEeL3xXsop2KoSiKXlZqkEys5otJJstgcU2Zw0Sb7oknAjhj0v2xWuQ+KslKiaIM1sCzWKHhJrWPAjJXGIyZ4MkZS5ZWUGK2ZJjWlskymwJMwki5ZU4gLXf9sh9XCJSbmi5Ab5Mt0g0vZJhcmNjLumYvEMCMpfYSJYt8UCRR3tLl+jSPOjZ90ja02iBqJIlrFR4SF7ZkkBwY2IuqZjEQYIxl3Dgky0J5cZBUkqXRESSI/8fL3laMpFMphwknWxJRQ75co8cVSUXQXnNGbRylthBOhUfeJWzs51EumSRO0+II13yAW4IjCVLTHpCnMiShHHj5ikZpNQTYsiWNIwbe05JcraOkCSyhEN3zHUeyT4QPrrkjwJ5bUqIzXaBHHslABNI2BsAx7oLBAB0bAmHBKIbUvvd0yohTkHG2JIy1j2NazSIu1wSL7bTK9foFggWW6JFsnvRJWFEiNwb8Bqp1+Y2CtFCoHe+9wbMFiEIbAmEXo54lThQIWaH+supzpKxM8QzLgnNyE/jEtV4pIfBB6LCh+gSI4IkW9vqlrzBJa7nfkSGL6nht3EIyqh65DGREfr/BzGjGTJ3pIQvQeGsWfiSF0IFeJyPFqap9ZJrbWWDL+mgnwEA4pa0lSuAIRg+VWWJsRiNYRYQxBIShFkW1D9+ESz9I37zk4ArsSyHEXsuwWY/djQvcXuGARdyIYFN8mYvwRelsT894T96JEA9UUC+QSu2wlFBtCu9Qmcv6D4tAT8iaD31E2M2qBxeARZiwTVoAWsswRb08T1KIT47KB7nkz5IVx+mgiqqMj+uohSxciPPcxXSQz1wcj3ZcxXcQypIISVM4RQKMhVVISVZIS+/oyfCQzzWcTzJoyfMczKTUilrcimZ0oSc4imgIiqNgzqqsyis4zqwQ0sAQDu2gzuISrM73rc5K3AJnwFbMTETNXETOSFdhgUUR0RInWOEuGVYo+Nq3GQoiDKKitIoj5JqjxM5oxdbl5M5W/cQETERFXERP3cBGtE96BIQACH5BAUEANwALAcABwC6ALoAQAj/ALkJHEiwoMGDCBMqXMhw4Igkd97EeMSGkgQJCTImuEiJzaMYb+4kGdGwpMmTKFOqXCmQA60FDGLKnEmzZk0CkOJsWrMjRpg/UaL8CRNjx5pNcSARsMm0qcwFtDiwnEq1qkAQt5Q5nYkLCACrYFECAIJrq0xlt0CEXVvyyVY+l76ynUu3IIBLfLY+qbtSz4OmoorwHUy4JA9RTR/oKSzwVtNmchlLnlwSQLOmt8LqYHrKAOXPoFUaOMVUR0ovTHFFDs26tUkAZW16WeiDKRrXuHOjRMPUh0EVNgOt1k28OEIAgWyqGDjM5mLj0KMb1GNzGDdKNndI3859h02LNmNw/x8PPYZNCSOYBiHPHncQpiS5Xa6ZaHj7+4MBJLLZzOAQm5WEgN+AdIVQiU1DLPQJU0AQ6CBLQDD1CUoccMIUFvY9qCE3AGDBFCdSVUWEVjbJksKG+KUgC1PKEFFYCQcyJUoGKOaWAWJMVVKCbiBMsJUsMGRY40oAwLCiUxOoRSANqJgVkwQYCDkgABhI4CQDqNAwJEohqDDHlSyOUoUKegSRAwBoSjlQmgDkEIQeKlQxColg0jSHCgJuadwLTFhhSS/N1VldL5ZYwcQLeg7YgQ9DBCroo2AOM4QPHSQ6GBmjCFpJFS2coGZhAJzQQhUxgikKGZYSxEOTW52CRaWpGv/UARakbYUKD+SBgF1Tx6DxaaxioXGMU5QoCZpbTBEABbCtQbEUU3vRpUGpNFHxK7OsAUBFjhpMBZxNPVyLrXEA9MDUcg2BsIdNr2ww7pAbvGLTHsYW9C1Nx5zwbqonDFsTugIxYZMyIuzLrAh0zsQEN2/YBIm4Bj8IACQ2vZGATVFEPG4UNiVgXk1xQKzxlHGEx40VNo0i8sjsAZBpTVYQVAu4K7McXbk21YKQHEx1UbPNrgHQBVNyNMTBlzbtCPR2JTA1R4gqQeM0oku39gLSNUFDF29MHWPCz1UzBIAJ/tp0G2g+NkXA12FXZsKzTE0wXgkWbkWFAWA7CIAB227/xYnSiWogNZgPNINGCHnTBUAIaDTzF5jQdNs2QiDIYQrckGZeJwGmyFHv5HONgIQKzWCtuVlzNKMCEvGBzlYNBax7+uyP7lFADa4nxIEKkmQeSCJZlCECmmuhKUIZWSSSHKSSqAD1yCBkQe1Wr3TxQeKgftCFvFdWksXneqLxi5M9lIA9dACUYK5Zv5z9oB7T1zTHG+fr/YbpAD7Hna5bNXNi7gJJwXyaUqziIIspz4BC/QwGACg8wynRAg0P6lYiwQBQJTw4kk04gavC0GB8tlkgAAHANZv8QktzAUEsmMIHGFyQLzDIi01iAb6VkKEp9HshqBrGFFSx5F40IQWs/3Q4mQ6Q4lwpoQVTJCBCIorFSjahRUlq8DiaRKKJTlQJACJhkwfgTiGm6OIHskicD1RxJqZIiKNmUgUsknEqAKhCdQwygrLNRDxvLI9NjtE6buAvJlnIo3SyYJM5DMQSNmmjIG8mx5pYghtJYEoOFimdHDAlCY+wySbcSMmqAGATNnkEFGkShk5KJwznuVhN/mDK6PyhY2ywyRpaCZ012IQNd7AJAThJSy1iTiZ34EYvlNNL3QBRJr0QyAuYUoZiuqYMTKEaN5DAFDU4MzRqYAoSCqIFprTgmpRpAVO0cJAO/DImkAEnYSyjyyEepABM6YQ669IJphSgIRuAiU0wMP/PsGCAKQtwl0lC0Dub4KCfU8EBUySRp5R0AEc1sRZCX9O3mojCnSwhJFPiMtHjXKIpgWQLCFhlkynwcnIA8A5TUFHDtXSApDV5xhjB+YEHrhSjjPkYU2QxU0p+QIMmyw0IZrEVkxIxpVuZRUt1E4Mz2oQKLzgpeQDwgpI55QF4VNQBnUIKHEg1aDg4olmegFMUEWGFV4pEJzbw1bAAYAOd4OKVYuEijXVABxQE0zF6EAM1EI8xaFJDDHpgxytxQgdlbdsGvPAJp9LusVd6wCe8INBrakEFtSgsZJ10jFqogJwdLQmf/AQo2g2DUIaSZmgXctnMblZQnf1sRyt3udf/2pYBnPNcKxfb2Nv6touTrawOu/THOilDTGQyE5vEliY3wUlOCXvUnRratrvm9Up77etfQQUAwRL2UYdN7Ls0QFTCGQ5x5GKc4+oUOYOdFUxqZet93hpXMNEVWEy6EpTaCqoqXSlLW+rAVpvSVf6GBgBhdRJZNUQ3s9zNwLnZW0Wb8rcBNdVuUV0aVSfcxaxup0c/CpLrigRUmyQpOkMtKoQJBIApJHWpaHPK2lasobGdcyZyw41OS9TTRf7UKR6mDIwAQ6Ne3qgpOqLMS5siU3XWtCmoEO9aSlgTr9H4XWPTrEzcR5eRNsWoHW0xlGHMkhHt9H+r5YaKWFTXsGjU/yYcTfOaPsqUkFqlvPJTrZwHcjWmaI0qHXhZRK88Yg7L5KIsqdCFCJ27Dn3oeQMtaE0OuueGKNQmDKVQcRkAuEozpGmFhLRC8skUfnraJP+0SUBLsiCbNOjUJ4mQTSbEEHjaRJ6wRkk9bXJPhfDMJj7LtViGZpOiIcSc/GE0Jdl5k8T+pyYBEvZKDISgg3TTJt+U9krEaRPQyoxm2ibS+miiM4JQ0ybWDPdKsmmTbQ5kgDOpj7qJtJ+a9EeZzJw3S6BpE6qhrCYq0zeRBD2TmAmTmAJfyTFjksz02GQ9CVfJe2wyglzeRNngBMCN77BjmYQs4lq0Kk1iEMuazBLkKv+xZU3YMMo7olwlHX+SKmnCypej5JU1yQjGbI4SjuW85TIpJc9NgsqaSGBXNNHO0EuiUppQIpM12eTSxQbKmjyChzR52NQXMrGKRdImk9x6QixpkyRwY40y0Z/YpzNHbiCyJopcu10aSZNHckNgNSGY3AuCMJssTCDFtfPeufHmmRhyIAtngHAGz6Hl0QRg3KhjUPcecwbw0V571Jfc+4XwgqA9JnHfehzbbpDamG3tVJ6JbxASxpo8oMc8N6NN0pgQdbFLuC+P17zITEWbXJHnW+ziFxeCGpuo5uWwYcpsSqLE82D8hQAAukykeJLEMyBcCcdZ56vPFCHq24hIXMn/ZmzSGXWPpjRUuSFTcphrAGC9Jj6kyrSYItFTA0DkNKmE5KyiQha6sNIxxBQ0NBeOwRTptFrMZhOZURcf1BS+MlEk1BQnVBgDNhPK0k/O0hQRVBgT1BSy0EHFlEEUBoKT4ReAQYKUdBiJoXbH4hQJ9Hz40UA2BS08gnR79IBOREJaJhMFVBz84xT+80ICtBU9KB0VSBNwAYMRhhd6cR/wsxXzo4Sf4X6bJhOVwILtsSpm4SpSpiezUitOcSs1Ij7kYz6Wkj7j5hTtYylYEV1N0RVSmBJjERtmgRZkhiLREz9NUT3XMx4AoD3c4yTec4eWQgYQ1T2c4ilBIyqkIiinZ9I2uyNpgvI7wTM8TWQ8yKM8mdM8ojY5LqFPj4UTOsETPgEUQkEURoEUSrFZUNGJRAQ7svNbt2U7w1dMi9IosggpkkIplSY6pFOFm5U6q9NHEfcQETERFXERGrERR+cRICESxGgpAQEAIfkEBQQA3AAsBgAGALwAvABACP8AuQkcSLCgwYMIEypcyDAhCxIwTJjg4sMHF4kwSLBoyLGjx48gQ4pUOCOMGAIoU6pcybJlyjO5cvma6SvmGZc4c6oUE2bGyJ9AgxqEgUrny0MYAAAQyrShUgyHbholgApG06sfBe3R2UPDUqxgww4EoKGHzj2CxP4ssdXlngNf1cqdqxDAgbYt95SgS5ACzloc+Aoe7JFDLZwUsFpxq4Gw48chNeBdaUVkGJeE4kLezLkjAEIuwzQswK0lic6oU38k0ZIb6YOpWrLRrLq2bYQA2LRMRbBFy2e0bwsfLhDAs5YtuLFumYO48+c5XJIw0TJX8OfYUQPI1dIEN0wtd1z/z06eMIAdLTENXMxS1vjy8NUCkNWyckEsLj/E36/2g0ssC+HiEgb8FQgUBi7h8tEHgbhExnsGRggAGS4Fol9QMeBUCoQROgdAKTjFQNcmOAUCV4e22dWgS5uodllOtdTAIYojAVDDYTmJtt8FrUxlSxIzFghAErZM1coFNHZUBCArTqUSBGy8cYVSQYZE5RVvsAGBkysFAkgRSXaGgh68pDIHl2jiNEcqvOiBQpjwEYFFHGemaadRc8SBBRFwDsaBFR7YScyeG1R5FQAbyEmMnR5YEVifB2EhiVHLPAipQRMuY5QkAML3Ik5mPHppUxyYoZOOnOHn0hlyGDoqVgDI/yFVS52KRQInLvXQwavPdWBWS5ycBlQfLtniKq+1AVBkS3149MGkLGlzLLIeatOSJBciFEdLxExLLXkALMpSHAYd0hIl3n4LHwCUtHTIQJqyhIC66iLQ0jLccNGSL+nSGx8AvrTEBQsuNeYvshq4tBEMLtVw8Ks1uGTVQLy0BMEGD8O5wZYs8YIQwy0V0G/GnQFQgMQNzRAoS2cYTDJ2Gsyqkgc+hcRBwC3NMvLLTQEwi0u+iMrUBhKAujPPTpnqkgQYEyZInS0F0irSVsrRJEtzpEVcCRzj5MEWR0u4xco4QbBXmCDEgKuT2ughQthzASCCHtY6yUkMIFBdUAc44P8C7Z2AB66SJLjgsKvecoWwhBWHaAK14CvNockhViwRAuJ8faACJASUBvnnOZUGiQrZYr7QB31cnaYslOThg4xUikSljT7kQQl9gAfSR+kvk/Azl7IUQIJSwylFQgG4OzmLsLzKULRRZ4DhFZxkgSEzThLIQCMNmhg1y/QHk/V7TprQAF8jOh0JN/U86tTIcG/kdAbYpjMEwBbXr/RGZzN07xYd63sZAOgwmZVoomZ8kUGPXDKFAJoOAFPASSu0JxYQFOVaF3Bg/QgCgAv8bSWoyFtTOoET+m2QL/fDSSeCAgiXLONwJ3RMB+LFEkCIpIUtAYMGY+gRAIDBJTbsCA7/XHKIHfIQJAAwV0tw0BDOtQeGR1SNCJKnEkgohAihMWIUa/SplfDJIHpwyRe3OBwstkQPBVmCS65AxudcwSVLGAgHHpcSH7QROz5oyRweRSyWDEGLdwwKAIbALIF8MCVnC6RzSnAtblCHJdZR5HO20508soRfkvQQzlbiA5Ct5AyAzGSN8kcAq1AxJWQQ5XAoxBJSCKSLKUlAKFXZwwS0BFX+W0keZklL++WhJZogSAjoiJL99bIz8cPa5QiCAmISAAu8PGZBAKCqyL3pINJoiSylORgA2JIl0liIClyih2jSEgBhbIkKGtKBk7DMfNwMCw1IKQYoMoRBLTlDEuLZ/5QkkNJCIikC2VYSBnPyEACwTIkHwBSU8a3EAy7jZ0M0MFCVzAIsMFBdSlrhMIkipAYLZEkgJqYWD5bQoOpKoUskgSTC0KBrLMkEAM9Jh0yUDZ6dQV9OGthGCLrPOW9wZkokUQp7Iq0DpThk5IwJnxmQ6Cxh6ABKIQOADoShgC3ZBAJRtAEKaDSfhKDBVA9FA0KQUqQUaNq3OrFJJyUgDB8gnnYA8IEwfJNLvlih6T4AiIre6RkJGMIOEECGEmggB7NLLAByoIESkAEBOxhCAo4DOQ8AgneKhEEBsgm6zqpEGgUgqUc5wgEYtCAMfcDEMkih1JWSYhmY6EMYWgADof+NllSmRa1qZdHaa8kCtrKlrW1v65ExlUmono0cm9xE3IJolrPJ7SxoRUtLvvktuti9VuGMekS++tVOgBUsYQ2LWMVSibGOhaxkKSs4y2IWcUv6qlGgJKXYheVKWYIpl7zEUKSxNU1vjetYp0lXu6Yprw9L29qm0japgmtudZvK3UT4qq7K95NhHTBTAFDWs3YprZBqn1F+pGH5EMlILe2QU42yh6iWWDBVvapRtFogrunkay/mzP2++6REZieoOSEqd1+G1N6iZA5MJU5CVxKjHBfvRqcajk5xwlMy+jQn71PN00o0NUXG6sJZ68xLcSJTJxtogDZ1CQRwSpinRu3/RNJUEU5aNBiTusSE/FQpBulCNKM1FwBKawnT1JJRl3C0uQQBaYWoy5QMuWRDiJ4miFwioqs4dGYRjTRBKOqSiwrlZp02M8l8BrThfkSgWdT0QhDqkoWOBJ8tsZSqV81Kkb73nl/V56w74s+o3TohKstnpne9kJi1hGYdaWc+2UzshsyzJfXkiIBaQqBmfwRBLVEQQ8Z5RlEfNJ0sWadCPLkSkVnbSidrCaMJAl2VbPPcVrrrZxNSzZX8Gt73/M9Bmkkrb/e03imZwzUJUjGWXAzfP9lYSzwmTGcmGeEhSWbklikQ9qzEPRD/yXzqQ5BcqmSXGa/RL1kSTIGQWyUd/w25SCKm7ldq09+Z9OYtBQIelohH5TVCD0vUw41ToiSVOB9JrVXiSoK1ZNhB70jCWsKCk6MElEmXHSkjUh2Yi5KSLDGBJVeCyagjsa111NclrR5zsKPkIlX3OhK5k/XlsKQ5avdIdEzDjdb6OO4MYSRLJCEQGqpkXnjniL1Ygi9u9HElfwy8/QjJkmZxwzcsAY7iV81elSSHG3NsiR0nn5Ctq2SPA1HiStDF+YOwy10EUWNL2Fj6gryxJXEkSGxYMpvWj0U3LOFNQcDtRdsLxIwsQaNBtsWSbtk+XC0h10GAT1Cyx5DVLRmjQUhDd867XSWuWYgTLy6CyU+xJVY8Xf9rpRV4AER4cPceyBDd5Xy9JdElTOTIkgmQGa9/JjQfwSFLdJh0HwIxJIe3EsaCc8riEo4XEvq3Ei8UcjP0fz9hcSuxB0hHbJLhEvYBFCR0Z+3HK3rGEnolFLeSK0PWXL7iEsGCFRa0Uhmkah3UWyEkFn7hEoARaYaBGHOhQFS2gWcWQYb2AoIBcCrBKjq4LrKCE7UiGP2DE3swU700QFiVEge0GWyhhHAmSXbxhCihF6khcfmEZ1aGPznxcKgxfykRKltUKlFGHFNmaCtYPx0UUi6RZdihFVwBPjxDFr+ihFoDH9zjPXZIL+JjFOXTIZJCKbLGgWTgdyt1hCjiPFOaET1/iCLV42EqIQE+OCpE4SRngBRytS4AABWUqBJVQS++gybBMzwwZzzIgybL8zJ/wmM5MShEUCiPgSiKwiiOslepEzis4zqw04kfMTs1UDu3Ezi6k356UxLuFF0wIRM0YRPZxRNbpUiawzmek12gIzqkc1tyQifYiCZ5sifwpjiM4zjYJTmUYzm29xARMREVcREmkBEb4S8BAQAh+QQFBADcACwGAAYAvAC8AEAI/wC5CRxIsKDBgwgTKlzIUOCKK2mc5AE0QVGcCLEgLdi4AFKsCHEUTQCUx0maKysaqlzJsqXLlzC5bZCjiKPNmzhzbiy2qVAXITZ8XPhRpkSJMj8u+LAhpEuhTcV0Sp2qSM6GmFizah1IRtNUmz1scACwtWxLABxs9PjKURMZs3BXChr1dUgRsnHz6i0IoMiQr6ME7YVJIpbUUXLwDl7MmCEAOXR1xiLRWCAZqb1kKK7MuXNDADJ6SX1b9oBUQZs9q169EoAgqQdcltDZowPr27hhdlibs8RCJDrxpM5NvLhjPDqRGMySE5Jt49CjN+ygEWcWhzovSN/OPeEFnSvi5P+0Mby7+egAbOSkUv3mj/Pwu/9o7iRnsfLx868GEBWnE24u6GSCfgSyZoJOLhAEg04I4Ffgg1sBgIBOMCT0h05hOAjhhioBEIZOf6wEAjE6qaAhhyhyA4AKOhEDQlbf6TTEiSmaB8Bf2S22w1Re0FijZwB4MdUOxF04FSaa/TgYaJh8FSKBLYjClhgqhOAjhwCEoIIYbInSgpIMHaANWznNkkcbHQBwpVZqdtBGHrOQiZM2sYHp2QYwCGGLLnL26ecCutgiBAxX2cldB0g8ItqfjDLayyNIPGfoXiSwwqgiCLyg5ppxbfoCAjX9yQplkw7UwY5smdIEpygC0IQpZO7/IOl5W3zFyFildsoBI19tgVsLUznBaq6d1ifVl3qFUItOmtxF7Hl9eZVTLSFgBWxOEVT7LIchRKATsg2RiJMoGWxraAZS4kRMQkLo9IK5z76gkxAEXXuTGCnBa+4KXOL0ZR45bTKsvhsCsElOAOdUBsEEl6FTqDcJMTDDBQLQLk6KcBNJTkZMTHF8ABiRUyQDmZZTGx5/vB0AbehUJ0EdLJMTMSmrTBwA4t60zKwIQXyTBTXbXBkAFjwMk6XYpiB0dCl4mxMrcRUgFSYcLM0ZB03qVIBnbUSWkxg9Wh1TkP3mNEob3LVh2FRuBV0jAF19FQvaP2ZASJ+9hJGBmgSq/5lBGIuSSUi5YgtUwhplN6r44l+v4Vvhec1wQBaUSMO4n9JQksUBM0C+VwZ/5Hz56H4S8wfhniO0AQ6i+wnJIRSYsMKmcG26ggkUHNLen8TgUKjNFywrpyiF0ME3tADQUUi6ZNaiHbEuiMdWBFukOSkAHWzh9FdxJIgiCQmwhUgKbkMIQAqIsJUAqfDVOlUvQJR/PRCB6+RrdIIk7p/8BANgrE5iEAxrOmALqYghManDymP0ZxNb8Gwv4ZEKI36XwLJsgFc6iUO+8nI3ndCCfxU0CABoIRVCmIUEDNwIIkAYQoUAIH1fY99LcADAVbVwP01I4QJw4BI56CQBD7yhav86EL6cyEElGUhhL6omRONwoH4cEQPqECK1nBivieihg9ZUB8WNKIKFWGSTzzjSCwpyYwZ8wkkewBhGNiXsJrronEA6YDmcUICNbWQTBXIijefg6CZPwGMe2fSEnAyBG2nQSRAHGZ0O6CQNE8hJFwTJyKwAoAs5mcDabvK8SponRjfZ5E0e58nuzAZbOfFBKc3jA2wBIieFoOQqXQKAQuQEEFfQiQZmKR0N6OQK3GARTqggS15+hgo5UcFAKJGTQxTTmAkBwCFyQomCFBAns3gmNPkSJ5zY4iCP0IkBtukZA+jkEQlxGCy1ycta6mRhC1mDTshDTr2kRydrWMkGeIP/ky2ws40AcB9OemDGhmxgTDkxxT9vCABY5UQbBW3JLUazUMjBTSq3gEsGpIUTMcSvni4Egg41McW4uIB5ODERSAeyIqmIwnuVyUARzXaBihoKABfwGk4SUFLVSOErKojoDTcgTKlIgTtS0OFGxPBBm3JHTbRQ6gLEcFT9ZOCaU4kAapyqGjUJYntSsUVPIbSCKqrPAtb7EfYsMNOvFGCDxArBLaSqLjwY4HjQUZMB8NC6r4jhFtqyGghawM9GiYEKTzDCBTSQpk3h9SCObZMGLmCEJ1CBrl/pQQtexMgyFEBmpAutTpZRAHiuNCEdcEELVDCEjYk2EkNQQQtcsMjT/64ktattrWgXAFvZ0ta2KsGTntK4Wz8FalBChaZnQVvc4pLWtKU8HGabu1sxOC6Mgy0sow6b2MU21rEujGwHJlvZyzJOs5z1nJgaZSY0PXYxbXpTN/9Ep6XJdbocIYZd33szAOy1r1P5a2DNZTe86Y2/NgLA37pYwrEqqaxySgBauVqWtbZ1Km+1U5SmVCUKL0lLmPVSiq46va0yzKtg1YlYH6S2r7RNbHDjqGToBp+kBripqYOqVKlqHiNNLUkMlUHWpPIk6Px0KkEdJFG/UtXcdM2AYfMk2Q5DY9XI9DA1NSZOdXoTnqoGVTqJ8jaDNCTOnFQqKj1tS3XyUsaYFf8nVAPuQLAmla3pZaMA/KicWSpSZjk4JqDEyYz2DNk/4qSTWpmoTsjgYZtdVCcZ1QrScBIBpRF6IU3TCdRiclCdKPTSn3HonJKrkBGVqNGeW7O60htc7XLEn6BmSUBpQ2qDjJEjQIv1WYqWk4ypRJ7jQXUL75mTfDLExzfJkK5h4iEQLUSdOInlssdmS4Whlrk2odm0FQjgnSEknDkZ57axYs6coNMgC8pJg8atwAnlpELWLJOwGQmA+TawICbDCcrYbcmW5eRl3GAmTpzJbzZNEyfVFEiAcjKggmvlQDnxXlFtQkyHswmZKRWIa2/SMYtbUmQ4IVkuc7JLj2fFlzn/ucL/bHIfk1uyPzdxwiujPe9ZuhMngLj1AiTmcgVe7CaKSPFGVNlzrLSS0rvjyHuKHpP54CTpHCEl02XjJ+hOnSXQDmVOEH31lQSaI7GQ3k3o2fXWqGeYkcTJJMveGkziZAJvtInA2N6hg6kxkTmpLd1h9sgV5GjvC/k6R1JiaI4EEvDRLKSgBWIvm+AL8QjhV06QRcec3BHyfNkjTvo4EOY8Xe9sp05OrjMQNCKs5nkEQNw5EseC/Pwm78I8N+SVE3oVZAMM/iLmAYBVm5TxIMDJiXAQDwDk5EQ5VNTJFemevC0qBMDk2ju6ZsaQJOZkiWx/4tf+TJBTDhT0Bd+N/06kvhAf5gSIUyeiTo7IksbbJFtF79a3ZlhD1Ds6hzrhIUzyjRPUONw1sJEVKKQTK8RvLwRAMhQTysIszrJs0aIT1AIXHZQTH6RrI1RCenEZOpEZ9ndToTEagxFBOjFBcnZBUqFBjeF+MdeBrbJy/tIZBGRACARNCxRW4JcXhXEYM1hKj8FlNjEZuZE/wcKC3eE/ASZAxSFQI4grTYQWGCQV9yMdSnh9elZBAEA/vQIfc1EXDQhjfgEYSBgf4CM+5ONo6KM+Cagfp0ImqkKEFfYqsXKD8BE9ZEI9aWUn2KM9ZNI9pRI3ZBIWTFgwaeFqzEIa2xI8fUI8xkOEaqI8KIL1Fc6jMpVyKZlCO6zhKaDCKKNSOKsDYGTyOrEzOwg2NmpyO7kDdXLSO7UmNDOhc4rDEz4BFEJBFEaBFErBFE4BFaJVFauYQKDjidQlWqbDfYyEKIoSjIzzKJESa5JDOXWEjByROZsjR0X3EBExERVBBRixOx4RAVQgEiRhEijxLAEBACH5BAUEANwALAUABQC+AL4AQAj/ALkJHEiwoMGDCBMqXMiQ4AYeRMh8qRNjR58njExpNMXoSZ8dMep8IUOEx4aGKFOqXMmypcuCLsYkmEmzps2bOBMkGvIEpBA8UYJGwSOk4pMhiXIqXTpzjIuXUKNKNYhEAlOan6wYAABgqteUXA1Y+XR1pgQkX9Ou/HI12Fa1cOMaBGAg2NUvcqH+WNrDRNe8gAM3BGCix9IfgglaUTqEw9/EkCOjBMBhiFIraqfk/PThseTPoFUC+EAW5xSXMnEK8Ry6tWvRQnKOaWj3Zg8Ur3PrbonC8M1gB2XkdMJ6t/HjCQE4ySljYB+czoojn059IABnOPtwi4HzifTq4JED/3iCM4YpnFG+h1+fG0AUnKbI5OzAvv7xDjnJcFOSs4R6+wACBkAJOSlB0AU5LfFfgAxOBcASOV2QUCE5EbFggxhORkROhaRkQk49dJbhiIN94NtNJkDFQRU5UfEWiSPSRUVOVXAglx5LtXAhjK0B0MJSerhGAVMUbLAjj1IBsMGQS1FQHw+sXPWJDSAciSQAINhQ2lKs8IDkQRwgsGVZPYyxhGNWBsYVB0uMcWJZnyBg45d5vWBDbWXlqeeewdjwAp3TyeDHIHsWaihNg/jRHKCCFaFZoXF0sUQIXKXpVaUhLNFFHIZOUQSjBomgQllD+Gdpg1yVYNlVKogA4GJLqf/iGKhqUaYKU5i9NqpSF5xKa1oAIKiUCoARmFMw9P26Xgd43lSCVITi9Iivyu4GwCM5DaKSsDdNWy2g10aYUA45dUHtt/UB0EVOORAkQk4InIsugAAgkJOrG+L0wbz8cvNBhYzghIe8/dKLB06M7IDTDgQXnK7CN+3AzSY4GdGww+ABYAROmwzERIEXY2wcAPzhxIRBwuE0Rsgi95jaTYsm9C9On7DAcssCsjBmTfuudIRSNtyMc5I2KHXEV0gopY2IQ0M2mjZKoZWYGpzmFIcWQmMMgBZV4xSHGsg1chUeHWQdYwcHM9UIiRzAKqUQNpsdGVcsCLHzZXOKbAIYh9r/JIEzRuBQwgdlV2r44Yd38EEJOBjhjFV90wRGik0DJoISdwjRxyZv9t3DJn0IcYcSrlaOnAxMZLFq5HoOkQUTMZsuVwcXUMj67X0XckGysi/kRrSHUlEIAiWkcDhUh6dQAgKFzNj3IG5UXgKLeipgAQpcZQwAChYosGcVz1arRChkxpBB9l9ylUEMnecUioEwqgH5UoQw7fBohFwlAdj2ManUIn7pHUEIA7UmUUdsOUKfAJPjI7W9hgcS4AaIsLZAl2ytfTPhhgS8BBklYHAmFJCb6QDgP9vALy45mB+KRFhBwihFAu36ir1yggMWVrAgAMCBUhAglTXkZAgguGFr/0CwOpuswSV8K48NhcgQAHAHJ2BQiQ5yYoUlMnEybrOJDhjygpwowIpXFI33cPInhPghQWAMo2gghBM/HGRXNwmBGsMTgpwQiyBZwAkVgjjH8IDAeTbJwkDukJMU9JE9KcjJHbgBAgzW8JDrySFOerABttwkEWmEpAWTcpMvPOcmMcikJlnixOyc5ybpGWV43AMf8txkNarMWGxu8oQ64GQIoozlZIpIkzrwoD+51KVCBpQTL83Sb8EUJkIAoEKaCGEgvJxJIZKpzAHaziZDKAgnbcIIalYTAAG75EGAV5M45K2akuFA12qiLYQUDScW8KYmAWCBnNhgIR2ARk5ehP9OudAlJ9Dg3UJcsJnz9bNWN7jbTJ6yEjcoxT8HTZKxcBK9lxRBoQkghDwrB4D80exTXoHjTQYW0cGkDSd3hAsHyJcTVRippAPcwK3cd868iCBKIApgPwnzwQSwonSgsSSIeqXKYPU0AXgxzgayeEv7tfAD0bSJFU6ynh/EQYJKoUINN9qjHAISJ9yIA2JGpIej0uQRneFqrUaDrav0IEi0yoFIr/IIC6m1iQAgQlvzpIIYYuwIPjwUI5yghCopMC6VAoESnBBOQ63haFf8gA70ibvK9g0aOuhZRHNwARVs07KFSoQKLuBXmKrkcpnbnFnJBDrRkc60LOGsZ0F7KNH/kha2A7FTs2hL2z6VUZiSpSxvh6sUzGpWjXvD3d8CN7jCIe65lVIc4xzXzENN7oaA7dtgC1spAXFFsYzt22ObFiaMgshMaBoZZdq02prEqabfkuue6nrYSOZ1r2Xpa7XalqdPwK2+qAJA3cwrVfjCqKxlQSuAr8RWMsGVRFCSEpXuqqYsEXgmXcKQVbHaoq3ijCs4+OpNwjrW+iBwKWSj8GsAgLarrA08S2XKEJy6wNFEtSZTnU4JcVIkFVdHSTu+iZN2I9RJEnWURl1KUltDNaVczccM2to6bfI10NxUKX2BcoZ4qpSfRgZHStGRaRuolAfnZaVKcamWryRTpYTC/8BeSVpOFkFj2D4tanGZa01IituDAOCkN0npVFbUIn72eS4GEDFNajSVi+ZEo4duokdv8gmQvuRn9lxzwQDwTpxAtiUOBWakwTLRm1R0JR+aZJ1HPUwT5YRyKSEozQzKatEkNCcMbcjMKG2zWpNSZzk5bkLyuU9Nj9AAABUoQq5pEwv5+iV55dBCOm2TeD4befXEyT0RkrKbrOzaUQHAy2wSO4KQkybmBLdU1ImTdhaEWzZRkLrDzcabSEibCDP2FcGJk0QU5GM4UYK+mUiynJwMmjiZ5rwvxWyaZFMgJXPWwPdd6prA75g1kcDEw8hM1QiEYjex2MK/ojGOceOXOP+B6MgdVHGa8EA+OFH2yqGCH5yQwZY3weXMLxXVOkDMJgzbuYN+XpMduNImsBR6uDFOkyec0iapVDry3nMTjaBn42pkZdUbu2escxzQNGHEJ20SSqkj74k26QPaa+Ids0P76DWJQZFpgkm3bxInX8jXTYRtd5TsutkbcKTXhShJ25xk7DWJTt9Fg52baIcbhMSJIRePkkTiZJHceBdO4kX5Js7wJkDN40322PmF/BEnghxIt21CnNIvczk4KbeeZyJH1xukjig1CLlwYi7bD3BdOCntQM6IE3n7/kE5cSNCdjuT2/ieG73BCXAS0kWcfNH2ABjjTX6LEHjXxFudDxf/Tu69kCnipIqUBwBTabJFlIy7Jkl3OwCYTpPZqCSJoBz8vEoJxZac+6z6Vy3idxPuxhKBlXN8NHNElBNHBBWPQmmr5mujgVGnIRWfdxOPpG6Ft3lf0XI0gSzgxiwPpRYppBQ6NWoulBMwJBfr53Cz0meUcWMJkCt54UFKEUK4RUJYdkKBMXs0cWQHFSxLIWiJAUEcZhM9QEHfpAUfpEEcBBp7gWUniGSFcRi6cWI5oSMBCBpc8SNL8WLG0YI1IStbmBi2givgEWQ2oQ1T2DsERCT1MXfSZ2gfVhd3wSDycxX1U4YW9AGT9kL8gyGiQiqm8i2pIoM10SpfMj7lcz58nWgdAHAD7FMW7/MrVdFfWrFg7BEWY5EnZ8Ev07Mn1oM9WsYV3KN9ZQE+LeMohhIpk9Jdn4EpmjJlZeEpvfM7kSM8xGM8hoM8hqM8zKNoegI9YRQTvLUTPREDPyEUQ1EURocUvOUUqkQ7DUdcw6U7MqdMgvJ/1rgniVJuo4Y6qtON2PQ64Ch1DxERE1ERF5ERG9ERHxESI1ESVKUsAQEAIfkEBQQA3AAsBAAEAMAAwABACP8AuQkcSLCgwYMIEypcyNCgiA9HgJBpseWPkBgxKlTAKOTPlhZkgBz5IKKhyZMoU6pcyRIhiUuWFMicSbOmzZsKLA1C1GVjDB06MFbogmhQTJxIk+a8RKKl06dQEZJhpXSmpRhQAACIyvWkVigxjlZlRaarWZUdjFTdwWPr2bdwCwLgsaOqkQ5xn6pFOoiE27yAAzMEQGJQUiOCC+YwjPOP1sSQI6PU+odvjrMvhuAs9Vey588qAZTCOeQFSxI4LX3oDLq168kfxNZsypALTiesX+vebRKAE5xcEHq6uSY37+PIFQJYc9MTQS84TySfTn3hCZxeuJG5acl49e/UAcj/nkmmwk0d3sGr5w1Ax80KQHCGWE9/egicQLhpwZkkff3/ggGQBE5aEPTbTTT4B+CCXQFAw20IoTCeTBPgxeCFZnUwAXcomNQFTuhhKGJK7eHUhVM2IHWBgiP+B8AFSNkAFwZJ4cBii7sBgENSGHzWgQpJBZMVjqABAEUwSalgYXV2VGXKijcSeZBWF5hSlR1SDpSBFVXRtIMJHTy2nlYdmFBXlzJZkUGWXd2ABhhoxinnnDiBgcYNbPKGAhN5HELnn3EekgcTHeaZ2Atc0rkDDglqFSVXjjqIw5lzWmGaoQah8GFVhZQgJqYCaVVCIV12UWh9IQCi1B9hgtpgB5Ul/wXIfK+hwAhSwfjlamuEIYkTI6fGlehNXzy662cAfIGUFVERgZSnx14IQAlIEYESCHDeNGS0RBpZJwgK5YHTDcZy6+INOOVh0C03PVGuudI+cdMtAomAExPvwistEziJIMR7+eorrXk2dXRTFwELvCAAm9b0BzfZ1oSbwrv6dhMYA0mBUwYJU1wdABngJIVB/N4kSMcesyfIvQuhgVMMKKfsGQAx4ISGSpTWVEirMicHQAek3rQDVxlQxZ0LMfccmgsTysTKmoFBoRlOg6ymdIMfMHbTEFDwFkIBSo3B8dUIgTyGUgXQCiAIB1alggGfsqmVAUB26QS48LqQs5xrNP9CB8eOxhVpBnQ0wtyfO7hAtlMiEOHEcIBGTpMnThBR0uKghUCEFLf4KnlVwdwiBRFqYw4XCCVY0fTnrCdliRUl4G26QkSoIvkTOjCRxAmRxt1b7yckwYQO8kauirVX06F1lxM4sZrv7Gn1gRMbxjkIHdxisDxSlujwfJbS67B6TYP0SOQPUydVygvQH6vVC6MpNcQPAK6wt01sIJ203AC4wIZSO1gBdURwP5ocog3tm12oANAGPyFlB5dzzQ+SAoYi7K9nAChCxG5CP8m07SYIVCCk2pAUJwRmOzhhw9hE+BaQ/Q8nZTHLCrY3E1O0hYUB4oGVbjIIAT7FBUjxwgX/cdgb6OBEcSvZD3fgRkReGWB1BTrJDZpmCfY1UTcAeAEV8cSQYdXEBEO8olMAYAKcMCshErpJAcIoRqgAAGw2sUSwBuKsm9iojeHZ0U2QR0ec0IGNeIwKAOiAEz6G7Cb4CuR3AFAym0CtgFYApCIh5cWZDO0IOGHiJD9mAJwcYQs3QYQkNylIRNxkCzWzCcxIuchU1gQjN1klK8PjSprEoAU8HOUsWwIAGiqgBR/ACbR2eZxp4eQD3NhLTdxFzGIWryaIEYjnaBKiZr6mRDYJBkHuc5NG6NKaymmEfAoiAgfWZAffBKdBAFDAQ0SwIPGzidXUGRgABPMmpVgItYSW/05rslOYJrlEY/rJSgDEyiaXUIntbqICggYSAHWziSqcUsmZHMKK9AzNC8xZkzNChZA42QEIHIo5AICggDLB3luwgJQx8CyjBPnZ2XCCBcGAoGE2OcS21GkkjtakC7KLTJOQAoZ5ktKeG7QJlnazAjgixUYkFZFW9IiUAvhwgBFNzRdGujiTfmF8MlHBO+sDhVsp5RBeeGm0fuYFn96EEV3LUg5Y2iVL/IF9UT3L+/4AVppg4TLmWoEN0oemAgiCXAmUjKNuIAinomkINrgq2bSA08g9wQpOYEIJDBCC3nm2dyEwQAmY4AQrPFNyXYjiJlHAhVL0tXWSs0QpuDBHmP8mJANa8IIRdpDUP4FhB0bwghagZlui5Xa3vaXTb4M73OKqpHGPgy2gKGc55wqEta6VrnatMtvabtJNyd2ueGliJy62kbKtu2xmN9vZz7o3tKMt7Wkjl1oW6g1QfftbpATnKMIZDlCJu5pgCdslwyI2r+vUCmMd2yXIStZcW5LTl8KEYBL9zExyUlO05oomu+K1RXt9rUz+aii2oeltiR3R3LJawqCKqKxVQata3deBtlYFriIaalKelGL3vWiHSVlqfUTA4jhutcLhAcFXlSJW9XwtbCtUoNnQVrrjNFUpUL3iVNH2YNf8KEg7xaORpmkTJelGxxcz6iaRGuTWSI3/L2qepT19KROuSeamSNEpkisGBbfOBKiJodFT98wtHfEoMHS9iUsJbS6ZIqWmcClaapBmXbkwDSdPOwtIhcbVSsvlpEhRaVRShJMVeTohL4pRVCoqk4sy+mpZ9LMCPMoSlO7s1WT7WdBsMjSWLLTMuDYdRHEyUZVUdibVPPVk3HOwlAj0Jo5R9koMipOEmsRlsQw2Dmlms4bsk9faJuI/b1KChaTRJhWSNlQ0xCGFxLMmcVZ3aO5pk3wipJE1OZm83bgyRB6knPzctyDbOVZufJAmCRK4Gx90ExNuEyfeVLggxXmT0mnsJlGWOC8PaZORDYTMMkm2xsfI7JpoUyBK/7RJf0buxgHdJIrKpAkzWe7G+cokmsmdGM2fYjGbYIzeNRnmznn5bXjHp+JDhwo3bQIEXNpkEOHeZS9v0oKD0gRhSef5sRXwh1rORJZZZwm3VUmwmog87CQqOU02km20i93rMonBv2xSgajLuew0EQIobSJKt0/blDbZAgpr0h2/h6ZpZMDkTTRp+IYAoJM3OYK9EGn3NeObJiWBZOUnCQBW99qINpFO4xtynZtkhxscr0kiR6+cy8+EuOyyycxZXzabK4BefbzJH2k/pU3XhI8CgVxNisP7dR6uJs4pSB1tcsfih4qqvz+IuG5CLucDAF03UddBzl2TNVqfwTKRY/9CbNPwzYuw5zYJjkJYrQAwsp6MZmQItnASZrR762IuRsgUuYNR+2uRO+bFEKjBHfFGc/a0OrRxEilHeIy3c48HRSuxfDYhdCxnTIXUEkCEHeYnMAAAejaBRC2RGZuxgY32bjRRGlExQzhhQyToKnMBZOTTZRSFFMUib8myLHAxePiTcc7lQkgRQ3CxGEjhGC2oYtRGNYAFGAdXEyEEUwxUQpFhK7iiK+DUK0gBLJ8xQURlQcSUQeElEx3UGjH3dFTIeYVxGLxBQElxQD1WUgwkazIBQcmRKqsyY7PzM1Z3E7PyHfajFPnThhzYPy/0QDI4HWmxFjekNHOBUjRxFwy7gj5VsT6AyD/wUxXz0yKa0iWdMolSNS27lhSmwibaU1few4ljYk/i0yXlsytT0WFYYYrFZCRhgSZkoS/KIyfN8zxR5yjTUz1ocj0ygyiIwyj7FRmRQgOT8ieWYjq1czu5szueFRrAIzzEIznHc0UvIWJyohM84RNAIRREYRTbZQlMQUqoozrjlY45ATv5R0x70ifq+CeCQij7pjmcA3LiFTqjU2Vo9xARMREVcREZ4RMd8REhMRIFhykBAQAh+QQFBADcACwDAAMAwgDCAEAI/wC5CRxIsKDBgwgTKlzI8OCGFDTUlEDCxEuLFjYy2rjohQmSEmpopNjQsKTJkyhTqlypkESUAjBjypxJs6bMKViy6NDx58/OLFim2BxKdGYUEiyTKl2aUISPokZJAJjKtGrDqQBcQpXpQ4TVrypThIEaJQQAsGjTGgQQ4mXRMCnULk2hgqiQE2fl6t179YQQoiri8i34g6iLvIMTKz4JwAXRH2nRDCWCeLHlyykBEBmKJunfmhYqYx5NOrMFm0JKhrA5ZYTo0rBjlwQwQmjNEAif1pQqu7dvxiRs+iB4xSaM17+TKy8IAIbNK9zU2JSBfLl15QBk2FRjo+af6tfD+/8G8KemjRI2Z4hfv3yGzRLckNgsAp69/cQAithEQvDzzCkd3CegZR3YNlNqB5lgUwv1DeggSwC0YJMJDQVn0w0NPqghQgDcMBRSKtUw1BYZbjggAFsMVQNYH+ww1BIlmjjeEkPt8MFiHIw1FB4cxCijXABwgAdRYXCg3Ad1EbUDEFT9yNRUQLgI2I0yfhDDVjBJwUOTGk7FgxRYFhADlU6uBAIG/oVZ0w462HBHG0rIMEMHWNVpZwczyKBEG3fYoIOUatYkBAYglCleCFcg0QICVowR6ExjWIFAC0hcgZuhJs4AxBaAPuopVDtsAYR6mCpWgxGexuADCXRyORhWHZD/4MOVjxqxYqkI1QDHVjEk4SquUyVBa1Fw3HpfEjtwQxSMPuJ6FQA0DsXNDknIBoRdPTpLWpBp0gQEXx/U+EKz2l4GwAudzkRmUhsMO1MMIJBbbm8AgOCuTDGQdJJuNEUh77zhAeAWTcMpdG1NXPwLsH0AcGHTtwWRYdMHCi8sIADh1kTGQFaYV7HFDgLQHU1WcONFTVh8DHLIWNRkUU1ZqLzyxVnU1MIGjtJ0h8wzrwfAHTWNoS8CNU1RaM/agmCgTAgYlGJN1CFdZnY2baFQBxXYxJvUIVtIUwUBmoTBUL5yHXASQ2GwFAgUDMWk2bABcHBNFBytVg3pyhQGXnCr/wXACTquaexoJOR902E8AzyVC0vTtAOI7EUJVRdIxAtyvUh0ASrE5aIgWaBWcEHdr5hhJQMXHQeKBgp9nxSCCbR8KruntJhwaes4XkEGAlnPvlUFCJBxhZG4D9YBDET7rvyjCMAQdvENbYDBvYFOUQcXMBSxgZ3Ncr9BETBwUUfjgcaAgb59g5AG+URN0QINWGE3FQ0tsD/UFGnYPe8PhoOGYeKxmcoNTrOVHUDGSSD4wla2gALSzWsqKHhaUb6gv/XQ4BZFicG4AOikqbyAejO5BQ2sQ4MpKMsmKqAY9K6CJGlNYYSwAUEjiIIA16xwJbRJnk0aUUG+hGBXKEwBB/9XCAC6DAUOt1OLCEAIEyc48IZVmYoThhIDr4AlDUPx1xChmJCpDIwmaagKqmrShQZysXQo0FxNjMASe9nEX2cM4Bfx1cOFzDEmUthiHCEEpppEoSTOEZQe96gUAHQrJjBYSOxqAj9CLgcANLAJLRDSAcPFYJCOjCIId/A8gXDAJk7MpHgAMMWaEE8gvZtJHTApSqsAoA41qcBAJOQ49LUyPBswXAu4kQKbtIGVt4xiG2ySAvnUpJPBvE4H9kPLmegAmMl8kg5sNjJnQjOahZwmTWzAhKJdE5sQYh8TIlkTJXwTnCgBgBJsMkIdyuSZ6MSONmfSNG6sBmHnjCdDGmb/k9sVpyYmyKc+OaSgmkCHIOusiQ8EOlCCAIBfM1HCQdxTEyswtKEASB1NSIUQd8qkDBcFJwDKYJN6LkQ/NtlSQ/UCAB4MpQgnGZtNxrVSsJwrbSs5wlCQENIzAsCYNTnCUlBgvwqYpaaZCUEq/8O6r0D0XdlCqkKCxMQCFEwusGSNCqU6EIzZrwB1sIwCd2TDgdJmSEP5Amw+gMGhwKWnGypi4Gpyi3X1hgRfbWJUoRikUt4PcuLhwAyLUgHKwLU0UyHCUnd4Sg2FIKtk2SCwznVHm9Qhibj6QNvCJIQyuOawzxpBGQ5JFArYFWlHqGpRpuAEE3wgXvGzKVZA8AET/zghr0SJgVAzWQQfLHZ5wMVSBXwAU65yowNK8AFpgwsVIfhACcg0rusStahGzS5Sk6oUZqVrEuQql7mPci50uUuQ1y0SvOCt3XbB2dvfove9MRlucVt5puUGik1ugpOcWsW9OuFJT3zyU/8CNag6Fi+1n2Kta2H7xKTUiba2xS0Vd9s6zz0qdKMDrelQ96jVSU2zaursZ31Gm9GqybQWs1KYtNRg9nipj7w6rZMei6UoSLZUHqxsTS5bJskVhXKWsxjm1KgkzjlIsFApbIsfqBn3zqQRjV1PC4u85JVBacAwSeF68FoUJ+z1hn1dLWB/U7j2Ic6Ri8vr437DViIJMf+ZciVKXWOTI6LwCLQmChJabVIk0ozVJngoqz7PShS1WgZvbuUbUv8215nsYHB7gSxNprBV43p1KGHdS4tehGchR2tNMq7KU/H1ZfJyg6pDuapV2Oa2TiNNbkOpm1WIahOjulpqbHHyFJqqFBFV7dZwQ5GKlKLT/QC7bz8dCoVTItOalM3U6USbTdTG7KHQFNqZeQFOT+I1mmAI2zj0kNZMgtKaqBTcOHTpfBqCNa0d26fdlgnYGOLRmIAU3UsZaUkXUlCaMAjfT2rmTCiEEIqS7N2ZzGh6ECLBmUQN4E/STk2sZpCEEgzhonyoTSRaENICCOJgKZCgCvJPmgQU5F//AUC/Z3JQgdS7AEZDOViUVhOT3pMmCZN5yh12G4EAdSb00bkryz0T/nDj5fAUuivnyTRu4KwmO1O6K4FGE6GRkybmlHoULT4TGqCnJhzV+lIMPpMSdHPSGBepOAUek5iJPYo183c135l2bAKA6THJiHfqHk3ymIftMEn627Nps5PRJGWDz3fLaOKFn8skuolHyTJrggTpQI3vt6RaTdTQy5r8MvI4HGZN4qJRmdgA860UWUUFAvgC7MCWoDdJLm0mkJLP5DixZ0wgadJy964y9yZ5ZSwJIrGaVBr4XcwYTTY2kE/WJJTIn6pfZxLlUcNka9FfS7xjomqBVLIml8z+/0EAsEnIz20mORd/V3nurYSct+uoJ+LVZzLJhNz8P4JGPm3st16C7P5A8Yc7hmQcDWF9BQBH+qdj3acQOpZHwAcAMGYUKLFcoRF7AEBANIEgJ+FGfhSAMyMwNgEvKtEuIRhkUlcvTJQvSTFGNFFGHlguAJBGNsFGS/E5NUEZQqcZnGEVWPRGVWZpIGgTYfQVyuc414Zu5zJgoaYUSzQUTvSCXUJKVGRFalEYQ3EYptYYjzEYPzQUgQGFLmZENoFEi3F+GVhq8cQtRGFkiiFDNJR/djcCLxcTPFQaYogaigZnfgEYghEbJXRCNZFCYDgaGJMkNcENL6QcyAKINcEse+I0FZ92iNQSHheUQTdWPB6kWgUgQvYhFmRxVMjWFlABFw6SQAvUQIOoEhDUcGllYPehK7ziK6m4TwAgLFtRLKXCP1hiAf8zNR2CgUVhQPPiFGpyFLHFMFOhFWHSFSujPhJ2E+9zjOMxP/WjJvjjihZzKqmyKvy1GLAiK5o4g5DWOtITju1zPdmzPXbCGHbyPeEzPrNjPrB3RsqIXjihEzzhEzoAFM/oKUeBTsczh/AFXM0DeQOlKZwykJ4SKqOCchygO7yjkDABPMITZbH3EBExERVxERqxES3QER8REiNhMQEBACH5BAUEANwALAIAAgDEAMQAQAj/ALkJHEiwoMGDCBMqXMgwYYgbH0gcKdHGBJIfFy78QGKiTYkjJD7cCNGwpMmTKFOqXNmQhBcEMGPKnEmzJs0tTmxIkWLDyRabQIPW9EKCpdGjSBeGkCN05h0DAKImndowKgADd5rKlEOSqteVGqI0PdABwNezaA0C6HCgaRQNaafCEHpAaty7eKsCaBsURt6DItAAtXDC7N/DiFECOGEBKBoRaG8MLpu4smWWaxvbvGHUBVAWhi+LHr0SAAugLkx64VYzSGjSsGOnBBCkJrfVCGnY/PFatu/fJQH8sEmDIIfdvYErX45QuE0O3CTXVJKcufXrAJRsHk7TRvXr4JcD/7BR88cRmzm+h18PG0AOm0e4mXiunr39xACO1zQxUIRNHPXdJ2BcAOBgE2QGvVTTBwEO6KBRAHxgE24LKUjTEg0+qOFCACwxoUogaEbTGxxkuKGD+b1hkwUgUBWCH0DRYeKJ4tEBlB9d5TWDikC1YReNskXVRlBvzAAcEE3RscGMQCq2gY1CAbHhC4JpxQVoTNoXFQtcaIUAGi80iRIILpDnJU04lEDDCFb9mFSbAIxAQwkGnjmTDS60KCZsHdAARCcxsWbnoDIJikAnQNDQwZ4C5nDEHWIRKqmXUdxxRA6MWkaCiHba8IMGbFp1WJsjaPCDmYNaUFSmCp2nVQsMZv85YFQftOBlfA5yB9QWJLjJKlJRkfBTUD/41oGtQJng66/4ATAfUC0smhdTNgmyJLPgAbCBIEDJQZVnNrkgK7a/AQBuTamhJF1NGYxLLnYZAMWZQu/V9MYG7767AY80YVqQhDWV4G6+KJZg0wcDedvdwARrOB5N3HhrcE0jNGzxQCPYVAISNTnB8MUoOlETEiFo/DHIWk5MU1eoytTCyShni+ydBXUQ6Z0wxwzcwzRFIe1B2tVkR846iwaAHTYpYVIHLcvEBdFF3wVAlzXZ8PNKfNVUV9S+7QXUAXG9EJQelHEtdQd6BBWmaCrbxETZZp+0FhNClbAeD/wORsOyDUf/RQOnNr3Bw68k5N2UHUGUCHVaUXEQBNJnvrFq3AbdYAKMhk6q+eas+WHCvJTjJcIHJcjRcuacy2SDHCV8gGDoeXWghIWb106oF0pcDftCHQTRNKEtmPeB4nA2WHzjHxzxw8yT2hCE7lGPkDWlS3yw5OJvavvBEjd7eUDFBItwwZkXoMD3g1GhML6XF7wO5AzMA7WE4hc37mFTLRg5YNvVhoA9kAAIAbfqBh4kja0wu+PQCdIWFCnJhgfdo4mP/gcyIQUlCoOzjKvcdr4EzgYAdAMKrvAChaD0yoMEIkFQoICWERhOJidE4V8AoMLAgQ8pNawJhmR4mQ4BZXIqqc3B/yjIw+AArDUpySFNzFfEIKHghyXpAIxqApUm7swANvED9AoixAsR0YoQuh9NgpCQrNREBl8EI4RkYJM7HARQFEujGiGUsZp0oiAKowmb5pitOs4kYgPZ4EwYxMfwRAg+ArFJGuRYSGClwSbcUKJMbsDIRkJoXTMhwbNmsoVKWhJCw5qJCdY3Eyl48pOlkUJNLjCkmpwSlbOxSRuOOJMqwlI8WFwQN75QEwDdUjx1mskXBMLGmhzhlb9UCAAEKRMZDIR/MdlbMmMDAN0ErCAGpIkGkDnNgQBAAzZxYEGYGRNlddMyzkIkQkpWkyiU6Jwz5EAEY5KjhGzSKdz8JAB8YP8T/phElavM5xwBQMpSqoRpNnmZQGUYlfjFxGpHCSZNpAlPlVQTKDjwiiRl4gT/VbQqIRCZTYD4lYJyEjQfVQsLQkmTCyDGpDOpy0KZFZXptXQ04AyKsmZKo6jcsyZw+Y2uVoRSK5oGcDQpVnjmIhQn9IqnXaOhSPuioQ7A1F7iguoMzfXCVW6RRlCYolaW0C6tlgYAGRBjU/zAQpDdQKJeeoMJ0Ciq0bRJBiboqlBwADrYdcAFALWdDXCQhhIowQA3yEGojhenHNzAAEooQRpw8LtJScEFX51jCIJAO9t5dihBqGdKGcIBGRzBBHLgZe2+IAcTHEEG0BntV0p72tT/2o61roWtbFfSpz8F6rNNMRSiFLVbgmy2s8BNrhdCe07LYS650AVK5z7XyL8GtnaDLexhE7vY443AsZCVLGU/e9nMxo1MlfVSmtYEJ6/ASU500hye9BS3txJKrnTt4Fajgle9BoWvRSucnRBHP0Pm53F2kpzFwnomsup3PVFJ65nYii0qeelKD0afaajWFDDtyapaeUNW+8ZVrVzAvHfzb0wssDezVsZvSB1RBgXE1KA4NcMkJsFUgeIX9mQzRtfyoLag1EDwDLUmFihqE48qFKUCB5ozeZuLtdSBEALFbrLJabJwzNB0BiWootlRUCaYTAsCpUiXuWpMZArPmgbF/6WIERtQyDblTK2FgTZZG17UjIAtKFm2pmHpTOCclhfFqM75AgCRaYIjtGw0Jh1FNMECuONMfsWmMtlacZWJ6TVTBa4yoeimlWnNXiIlRIF756gZkqIV0TclCK2JQlcdHAA4FCYQhXV6n0ZrxXD4Tig+yHVlcgFJw46gNpECSpALkx322qJqlQmFGPLTmNzB2EI2I038uZCg0WRozz7K0ZKmFJu4E9sozM88YSLagjAbAYQMt7hpKe2EkBMm5pQ3sKoNkxESxGZVQ7dRK+szg/xYJtvU91S+Gc6C+KeXAgdjgQ5EECgjQNQKB1apZ4JlgVT2ZRl3761tMJBi0uSYIf+nyjJt4kz50CflC9fPtgWi2pn4EuYLBzUChslOmggM5wu3eAjoHRNbAl3cuaRJ8tATcT66Bz6tpEnTCwkAWXKMJh47+sIrDRMkXNWUWn/TsGGikYCHHViV/QG/O3l2cQsa3xa/YdtV4keOPxoBlJy7RTEJQ77HhDp6n423Z8IZRU5djQB4pG0AubDAK+Z3gOTGveF9+CUTvd8CkflMeOP44Bw5JrFlvB4rz9C6B8pbA7k8An7eeWVaHGEEgePoW98c08fkjgXZuEw4T3u1fB4mxTGItmeCxt4TBAAmdwpC6jUifBlfIPtCT0K6OBNn996HSFTIalpDerPRxjYZ5Z3/WGvZ/aJdJYvBjg5Q2uV4tMrLJHdHABPnDoAnjhQl56LJn49uGtQEESjxxn+qhwBktBL5NxPiwn8HKBPpwhLxZ30hh301QVIr4XcrBjfylhnvNxUu9EPlJyY0dGZyNxXUUhPW8oEboi0DVBOohxYl5IGrFoJA0VZxERiDgUCAxhiO4T53MXkwwQRcRnUgFBT+9hfHolNBaFRellDphxYQNGZJmG4AEHXtNGOjUWM2wWaN5GZU9RsHRxN6gIMSt0BRYh2/JxO8EoUVRENvt3nrYXEyIQgetTsBtIJXJiBhMRYYqDNr0Wkz8RYaAj9jVWAkxgHRllD6QyM+OBOwooYCpEIrt2ZMrCI+5GM+KHh89cdnLcWDrLIUdvIUdaUlUWEA/HQmXAEy0jMoUVA91yMe2sM9g/I9ZrMpkuIpoNImo2IVpXIqkqIqHtQ76XUmwXMEw8NYrHY8HJA8y4Ndz6NGLhFdaJgTO9ETbQhcRHFLsvNu0AhcOJA7o+UokLKNk1Ipl6Jwo1M6p/NZmbM6rcOJevcQETERFXERGbERHfERITESFhMQACH5BAUEANwALAEAAQDGAMYAQAj/ALkJHEiwoMGDCBMqXMhQYYcVMzK8MFBDAwkSSpRc1FDDwIsMM1Z0aEiypMmTKFOqLMmjxIGXMGPKnEmzps2bOG+W4LGyp8+fDUO4zAmzRBEASIEqbYgUQJGhRA+UCLG0qs8rRK+AAGC1q1eDAEBgzXnl61IQWnDSSGq2rVumAGjg1ALiLUIZN4Owtcu3r0mkQW7KMBuEW80rXP0qXtwTwNiZ3Ar37GCiJozEjDNrbgyjpomRJPHSBIJ5s+nTKgEAqTkY4QYkNH/URU27dkoQP2gi2VCwDU0TpW0LH74QQOWZbQR2qOkiOPHn0AcCcFGzA4nq0bNr57acJgkDNUM4/99O3jSAEDUNcKNOc3b596ZBMB84o6aa8fDztwWgpuYMgxzUJBt++hXoU1i50cTBQvXVhAKBBkbIEAAo2JQDSjXY9AGEEkoIwAc21bAUVDPpxWGH0AFmUwl2cXBcTRuiSNyHN5mw4GkilIFTCRycKONPAHBAIk1liACfkESZsKGPKCL1wYs63fhjQizoGBVMPxxRxFZ7MdYUCEUckeCVB5TBwpR9jWDAkGS26WZMJRgwAprRcfBBELC9qWdOSATxgZR09vXkmz/A8MEJTTEJZFMnfADDmGQqGahCIPRHlBssdEknUiy4EZUa7r0ngqc1pqDppCshlQKUNLlhJG0Z4P/Eg6KodgUADzhlwBd6Nq1Va3Rx3USVUpR51gGtv9YGQLG/gXYSmy8dgWyy2QFwRE0sMgTtAUdRi+qt2B60AaQw0TGttwUCQEdsvAl0HU05nItuujnURAI3L9SU6bzzAsBCTS+8O5Oz/Hrb3UwkrFCTBvIWnB8AGtS0Ajfy0UREww6TBwARNYX6L02XZbxpZzSdiRAGC2MsMmoQ14RBSXLVFO/KGtdbEw09fUxTG1vRrCwIvunr1Qp50lRCzz7bFda2ByAx8WLX3hRj0o2BeNMR0IEQ9U1AZHBqxkhlsBpOR4QqYcRXHvGgyuZRuDVRGlDNHQ1j7xmTCVq4oMEHRbD/EAIHI3Rw7LIdjMBBCCwU8YEGLmjBqt1A0ECw3G2BkEPALpTweKQluEDCCzmYTbltG8xAgwtB251TGy7QMEO7o78Fggwoq267mxjIIHrsCXWgweaREnEF6Fwm+rV0xiNl+QtXEAH8lSZoMLnPKwTWJgxbHr+Z8jyQTGYQT3u7AtMlisc2bUiFYD1RJYQvYwbPx6TGsQUvaylOJuiaXwdp4RSECOdDEwBEsD6baGF6tukAqWwSBKTx7iBhKWCrEJiZx9RkVg9ECbhuUhbGgIB8vsogkGKGrd15hWk2CqAICRKk52XLKyScCRAAuEK3DLBuM8HZUqxUMhXWkCk6m0kZ/3zCrJm4wYc/PAkAFiiTz6QEhzHRSxJPAwAJwgQIJlECtpA4xcZsSwkMGYFNetRF2wTJJnNCiNVmIq0yzuhtMfnAQQQmk6m5cTg08k5BYhhHLt5xKXnM4UBsNhPE/BFYFozJhbgBLeAcslqbY1GDZmLHR85ojTLJQYYUZMnsBIgmNdAiTfzYSUDWRAlom0kaS0kcMdJEA7GiSbdYKRyn1ERXm9MCKWmZqv41USD5oskLdslLJQZzJi8YCHtmIp5imodXM3FBQXwpE0Q5MzMAOEFNtHAQK75kltfsiy1pIpmDgAdkxAwnC70nE/VQqmgyAac6bVWEmiDBhAbBVXjSSf/L89iEJydJ5Uz2Nc8DBVEmcVsJJmVyn4KmhD8aUgrRbOI1h04olrpx31IEOhNTWbQgAEjBTRLqlvvRBAr89BkAoHATNTBmoTORZyfHGdHTdIB8B0BpSgW40h1R0KY4PcBadvqwYPkUPjDdWaaIWkt/pU5qP5IBPG8Cg3gxlS9IyQE7b4KE1iSLBkgwTFSAoIEeaY9lSOGABqB4E24gQYc+60AN4ocTOqjhA+ZrSlWMF4IPqGFdejJBDX76wBwoYaq3S2xUkKCERRZ0AywggRbIpdic/EALJGAB7D5qkuWRIHN0xV/nPhc6zqIEspKlbGVvctnMbvajagrqat8Up1X/8nIGh52tbm3C2P/8sQN0Uyze9MY3vwFOcEgRnOEQpzjGOU6xkSMs1eQaWpvYFa/G22ui+vrXPQlWugWrkpuylL2zvuVLYVItTsxEM7CKlShkNetVlZjWtV7JrXD1FkfJtrYIIQUFcMQJSScl1ahU1bz6yepWeetVGSEpJ0pCsIycVF0edSipyFkq2JxKFDnmR2s56ZqEqRU2trIRn8K5aU6G+kCk8NFo4N1MjnZExh8GCadFGo6Kb6JTNyKFpTqJMV8CXMf5bgrDMMGaaZD8TSN/q55QZYyLpObkZAXyN4Cyi0lnglKH9tQmLrXLREtYZX4tjbca7cp+Y+JR03Ij/6QjNQvTTORm5HnzJS9cyphpUtE6gxSjM3HaUg4aE56VmXJheapMTOYTJDfUzwqBKIx8skmaVBLSCLmyTESkkjW/hKCYLg6hYTJgmFno0DYmpCBNok+aNDPUJfHnBUsyyZk8CNZKrJDMGgICxDYZ1xqEcqBRLJDazYRhwH6op1+mkHPOJGTJfuiCX+LOg3xyJgOK9kNxU5MsD+TOMtV2rIUtk3ISZNQHgLa4pS20adbEmut+qDZpwk2C1Fp+qOalpGfiW4EsUyavjvdDoSkTaQqkYjO5mMAbw7H2ABNg+S4mAI4pk2Sup2ML9wnCCy6QXEbcmQCgJkxMwA2FvfLjEv/39AoAHZNwZ/wv5I5JBpwNcJTrm+AxMYCnbfvylLjy2HSMiZB7jpCDyQQjNbG5xE8ZdJgMnegGMXpMSFBpmXgb6iS59qYpHhNQY50k/gLYvWFy6a8XB8M5kDpMmmP2WP9b6Iz8jdJZaRyjuUtmc7ckAFQ9dYHwHSaGbHtxEgkTxyr6JY4UfKQ3l5yBvPglZVe8QDQNk/yOiybmkjwEASuTH7y26ZDPu48xfK+CvCY2xMY6twP9WoFguI2afzORD+Dhg2wLg5Lf4EzybJCfz6TGbT9jTXhuENHIUPQrVA1rGiLK3SO/xV8sybZgD3VrhcskJj6AFIlexZpg8SRFlIn/uhcOgGkfwIkoCX9MjpjxJRprJeofOf3EvSzgob8nPBzo882M7jItpTCHsX/e4hg1ERlW8XgvMUMC+C0ikH1C5RU4JxMhVGdGFR5tgULAZ1EttCJ2YXzkNGKPpCI20WBu8UE3MYHXVIFGk3pdwXIzgXv61mq3tBmEJxMwqHcySBMdFB8il0MgODouNhcs2BcK5D8OZGMgcGcw4QZP5xejgj+msoDYFFJ05SrawT858T9SKE4ElBMHBB81WEhHCDZikRURAj9EMT9bqBT2kyT60yGVEhWY8oNF1SmfMoTwMT5XEgTmM2HnoYS7l2aBIhRkYhR6VR5N8RSFOCz8Uj1ueQIDPMAleBQW3eMm4EM1gzJehoIoh3hejOIo6oU/tRc7vlNdNSI8xJM8Z6WKYXE5zWOKNhE9TegzLbFbtrgjANVJs2Nst7hauYOHh2QneNKLbdInfwJspXM6hzdbrOM6rQd1D5EDEkERFoERGkECHOERGZADIjEvAQEAIfkEBQQA3AAsAAAAAMgAyABACP8AuQkcSLCgwYMIEypcyLAhiA4jVpw4ESJEjhwVJ64Y0QFEw48gQ4ocSbIkyRVFDKhcybKly5cwY8qcKbPICpM4c+oEKeIFTZYfZoAAAGCn0YZEQcz48HPlCxFHo+7M8JPFhqJSs2otCGADi58ZtkrtwFRmCKxi06r9CCDEzA8d1iq8IRMFWrl484oEgELmjbRkY664q7ewYZIAVsSEq3NGzBOED0uejNgtzBkiy7qcEZnyxw2gQ4duKLr0Bs+IHb/8sPDrS86oFYqmPDs2QgCqXbIw2PclZNsDawM/KNw2gBMwUQzkAbPz5NHDQUI3DpMHN+QvOTg3PD16yO6UAXD/gDmR/PbC4L2TBm0cu8sT3Ki+jAs8vXri7IF3gBlWoPuWLJwnWXHeERgbAK69Z5BiL70gIGoG4hXhcAD49NJNCvXm0gcP3seNaZ+V5iFDAGjWknKZwcThiCzmVaKKRuW24VAt1pgTACCY2BJmaW0gg1kd2uhhWzLJcBplgdVFlJDAEaWhivTVmMJPH0AWJJNsHacjTClgOdJSTa2UgXZLDkkUB/KFGZSXh3WAwpZhxilnnB+gECWbQq7Awo9z9tmUDCxgiGd0IcBJJQsnXFXmWkR1dQILhtL0QQiD4rQBXVRaWSmJbUXa0g1HsimCpwZ8oN2mcolH6gdQDTflYqei/xqdqjJ1mderMMUqK5bi1SqVZS9lcOWuQgKQpkuUniTYsMQOmphgDcH3kgzMDiiiWCC2CACfLV2H0LEs/VagfZ5N6Nlx/BE0ApfV9kjufeYeBgCuLY3AzX4vpdDuVu/W2G9h88LUQQ4w2Wvbv/7mF9u6L+UAAn/7aoXwiBPjZSxMHj38UhER86twwqEal9JLHg0ELIAdu/sxhBUbhiBMyRq0gaG6sphtVDez2OtqIStkoUs8pNxsjQAw1yBOP78n9NAH/tfSC1ol3RJcSzOtFgBJHl0YuFPXbDXAHHjaX3RZx5TDol+bRBTBb92JZ6FNvTBY1RQmJvViMae9UA6kzv/0AqIdNIo2ToJj/ejddOagN5IhZMCtn5DLkEEIbi/OJAgnoHBD35CXegMKJ5RsuYcrZMBa56jLyc0HGQg6ulhgov5BESmEwFHhuAuEe+EQhZBCEZy/xePrIXXANU0yoCBCo3UDIAIKjzeVQeWWd4B4dXPvStQKRv/0AvWonsD59HQXa3ymg3YQ/Us30Eg8WyBgWiT4w406k7DlW07U8UC1Clz3q/Ha+6RCq5hYZzL2e0z+Bkgip03Nf2spW0uCtkAGhoQoAJwa/XZyPQPcoIIWJJz8XAK1qIxHRVcJ4X26EikO6IRtL7GLCon2pJYojiQna8lgZsikZ8GseDE5y6b/JhYvouWQJRscCP+EJSTT9MwkTizWEhdiqOXZrIhSudaQRACjg+BrQyDcCRYl1DKXGcptGiNhGC21suiU0UXXE93qVrNGkowxNnd0EZxYI5AarmQEdRTJG/HYxvAwzCUogskH61PIJjZSXiNkCTdu8hIhHuyRIGvSEQ0wyU0aAJCXfKKXBrkVAByyJRXJVSBDJEoskVIrO0PWKVkCm1BW6pWwlBFL7AUnag0Hl+XCpMvWVyqBeNKStnSlMAF2zIFEciVJPAww9TJNrXzxUwUhpgFaGcxlWsub3IGJDA6iTSvCq5o6yaPLuDithPBPhldE53rkmRa+pEshDCKZMnP2/50oXg5aDRmZGnnIpgrBpAgjMZSDCGojg64GJ4aiGkPVg7WIGoV/BgjQRI2TIJeM7SjshMnZNiovGL4EglrxpEqYSNKrYdQAeZOLA1siwJaq7YSP8QwItLkScdn0gjNliQzkaJsRkIoHgfvpQbCWwQ0ZrEUgaOqGssfQ7fWNB0T1kgh4ChS7rPJAfOGcDFA6NHrR5AVn+Wop29LBfM2QA22NyQtmsLzBAYwoIphBXGHyAhcq1WR7lZMMbpCBFMwgBCfgAAdGwNgRKJYiM0hBBm7A1T6h9a8l2cAJTJe6zi4mA4nCrGRAMIIQoCADPDARN2Sy2pV8gAcZQIHtsira6P+Q1rSoVS1rgQJb2Y6AtrU1TAcaV1nPTmty0QxuZjcbPOPKiXWhVe5I3NRc5xq3TskVbQgCG6fBFvawiV1sYx8bgshOtrhyuqx0+da5v50gcIIzCu8O17kP3NCmcLUsXZk3mUbllbtP8ysPYxemMfF3hWd66WqG9z6z+i2tlSLKduNkq8XBzXtUbdb2uDspq22VSl59nZPESlY8OXg1mrIgUcT3kwp7KaqSyjAPrUoTrDJJgg2z60TXJqnsUsaoM0GqWjfF1Lc8lWykCrF0dWdPmTAGODudiU+XzJWgrmSosXmpqYasv7DJ5KOGsbJKakrl2+CUPNzhKjLLDBIixcT/SHlRqQFYymbEvDSmW+mgROusNhw7JS0hzTGfdwIAk7qkxI1ZjPsGrRMcRYrBU4mJRhkdlZfdk4MKpHRW0MXXnUQ0qZretJ+LCVEVcZnNL3poSRR66jo7dEMkuV7QQm0xqRqghCAR6NNazehXtwShH/GjSlaEJ34ixJ8FNRSKFpJPlwDXQ07k5kKijaU0usR1xKEZr0di7HRqUWdnBoq037lt6aiTjfQUS5M9mpBms2ShFEt3P8HZ3+theyDlLPe05W1Hfh/FeeI8iCcnPS56y+XcLuooS/CsTWk/x99ihHhONhBwggSV4Iw0OHckrjaF95Qgz1SJj/PCcZxpXC7X/2TJXwRibZZwzI0np03M66lrlpTsmPouSMklNvNSNjM+Avtlz7s5nJSLSSC9zDlBdu4xhwOMmKxpuZiULhCmY2voBOQfaS9D9Q9hnejG0eUfgzplmTu9RVZvIHk8SeaNnz2exgn3SixSsIyjKu0MmeVKMFIwquO96cbRu0oQq8pk3vLr8pW7Sk5ASWR1/e9ZRLx8NzlJo6tEX3YfFOQTErD5tNYlizQ8mzZ/m5Bzkhu27rrX315wClWnj30XOuszH/jkCETwBsB8xmfPMsnL98SfHMgeVb963j/c9/LdI0GEbYCy9974bod+PYO6bG5IXSXwhrn0ybj9esaxIPxzPv8hkW8UhKcqqGC+l6mhTXqZtZ9EZzyIx1VSy3OSX5DvJ5HYVbIbhFSR+O6Hd99GUYEGFAohLS7hS2g3gJFnfsP0Et6iEEsEgAmBbBPXbSs0RQxhKPXnSBYoG9TGK/tHagxheYNHgfPGSkSmUj7mbiyxQ7TGKC64Eve2ECoFgzFYSjM4eCQxgjCFgiTlZq9hEobGEvCUg//GfAZwXyWhUnSGhDeCUXhGEoo3bCkEhSXBQjEhYDoxagaAg1jYZjtYKiP3ER0UemGIFKZ3a2IBfGMGhIsTS24FGJFCQWloEBi0GGVoEmtoAEd4h+vGPoWRQOaRhpymIoi2Fm5YKm3HZwXyxCWoYWvD1ohL9ogvcUCx4YUnOGhCCCXeQYgQA4fesT9vkYixAYoBJIoH4mVOZopFV1zto4ouEz/Is4dZVhVXOENdMX/stiksRhPkw0BYo2DDBh/EcilNMSk6RiwSFjygkjbWEyY8IGMRlhiSSEK2iCc9QSdCsYwIphTV9RQqdD6CpTwHBlbOAz1zMj0kdWFz8gGIoihf1SiaBSl+0mGiRWCQMzu1czu7w1//2Ci98zvVpSKQJl0oYV0KKSc2kYOlczoLqZCr0zp3WBB6gl4ROS2BUpEigTmaU5DP9Tmhw5Fr8RARMREVcREZwXgc8Wx6ExAAIfkEBQQA3AAsAAAAAMgAyABACP8AAQgcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocSbKkyZMoU6pcybKly5cwY8qcSbOmzZs4c17cMIKDz58dNhysIEBAgKNIjxZFuKHDz58jhOqcmnHD0xEUiRpNinQpxZ4/pVIda9Cpzw4atXLtKmCjWQ5oyeoEy8Gj2rUBvHaEKrem1bMf767V2/Gt2L4wgQYuijdv249vEdN8G3ejYK6ENVKWjPPpYap/fXLuC+IqTbocQIxenfDtUxGVBV5OWrRCwQ4inipmzbu379/AgwsfTry48ePIkytfzry58+fQo0ufTr269evYs2vfzp1iB9Q/pzD/xltUN9TY3V+Wfope4Wy2EF2nTu8x9HyL75U+trje52f6DW1m2XiD7afZbgAmlJtodhGImYEc/SRCggf1p1qDWxUIkoUUlvXThRzl59hH/bXX4UBPsZbiiQ659h9N9pnIokT2cRBVQyLW1hBPur04o0lNoSZehg9OcVVQPyap5JJMNunkk1BGKeWUVFZp5ZVYZqnlllx26eWXYIYp5phklmnmmWguBwJuYThI2y4jwAZimt6Z59MIHaiW42NrgocgnQOBJyNBewaoG1ZkunYjRIVGxOOfWdKFaFZuwmeRpFe+NSl+leqnEV2DJilgRo0eCFiToU0YYqcjdrQgBz5S/1giho1lZup9P0q4GJG0QbjRq0lySCt5vmokLIuzDqshZB8mCdamA/JqqUfPLslXR6VyRFeTdMVKEQ4VhCuuuDGQ0FFo0Fr702grSgkqWZpmadpNqH0p35wMCcFqUUZA1N+pZcoHl3v7CmBba+aFmqbAT3VRcBd2QgpoRSz04MHFGGfcAwoTd+zxxyCHLPLIJJds8skop6zyyiy37PLLMMcs88w012zzzTjnrPPOPPfs889ABy300EQXbfTRSCet9NJMU4WCIxlHnYkKOgf51JC1CnAoki0z/JPD0urnJ3smMwxbQdkKhJudCieaMMFht4qwbm13WeOiC6Wd0KNhuf/9FL55FxzRvwN/+W+6OAo+EWqAXznvRHpDVG+WLnIat62Okm3luxdFLlG8VHpGquIY2Tdluxh5ThHqTbLeOekaue5s39Fmfe61S46aFuy31p0e7rUT+9G2Sr7V+OuXF4tRsj9Wq+yDIDmfK8CrJg9SZD8yX73tzPp0PH3Hbi88ic3OGH7wy3p0PoWh+R6R6hcZlqSuz/cKErBJ4o8t7xvRn73EqeNfRoy3JOKJL30RuhOTUtURHOzrFB55lbcopDvJVLB4ABzLBXOXQZ1skEmgIwvnpmSf783kXxPkFvBsgikt2QdxL0FNCqWkqBkS5GlRi1oPWOAo1LhvSoRz355kDmaov51JUAwZIkPkA0My8Q0oL1KiQZpiHrx9zGt40lPBbNOniP2QTt+xE9aIZaQqfnFkaxLBJQp2CTk17Y1wjKMc50jHOtrxjnjMox73yMc++vGPgAykIAdJyEIa8pCIZFlAAAAh+QQFBADcACw0ADQAYABgAEAI/wC5CRxIsKDBgwgNguggggOHFSsciugAIqHFixgzIuTAIoPHjyhGcANAsmTJChhNqgTAbQSKjx9ZcNBIk+AJmBlErGRZs6fFnSJwnvDZAWaIlT6TKh24MgTMDglTfDxqcqnVqwRVOvWYgmBHjyOqYh1L1uSImNxWTFVJtu1VrR9XcMvx8QRbt3hrqrzpMYdNtGLzCj5Y9WuGoQnpftR5dzDWlUE/+k269SOHnTwdF8TMAWcIzdw2KMbJIkSHnSgvVtjZIYRhmDk2gKYpYgbO2x5ZoJiRI0SIHDNQvMbtcYaI2Qj5xmSM2S1mkiKGI746OgPVwMg1NoWdMTLYxtnHqv88u7jghqfYwws2WfSjbO8owKsfrPKlx4mAS84HXfgjVG72HSbffuKZpBwKB0nF1UjpEahXVQpm0FVGG0SYwWUDOijQSp19lIJsY3Vo1AbPZbZUiRtUZpmGAoFwgoXExRhjCidUxGJNHZwQoIw8onDCfzci1MGOMNEIVUlCpKRfjjCCBGR4HcAoE4MlPlglRzil8KRbKlpHZYP0IdXlZ1e1t9hOQQKF05YYbWAYCySCGSRTJrkZE4gWkecRhvrNqZ1JImYg0kEgwBSWnH7+ZBZMNg6kXAoZJvpnSRFOp9wMkUo6KUm2eTRUoR99qelb+jEqYg6ZjpqRSqM59BGmiKr/qmRJnV7IDaOxyqooSaB6JJB3GYiqq5UswXScQGZmcFquw34JQLJs1oogs7JWFeAMFgUIZ6qSqmSnRwhmFCi23GrIVq22+hRoTmiaCxlOM43V5QxxIuUYZhug66Vjot2WgkglApCaRatVOUKTsWl4sIwznHAWRiyMcIK+WQ7abGginJDDcDGykMMJIuB5cUIbZLwxjzF9HPLIBbnYJMoo09iopgvH2PAILGAEgsQUF2mxhv3eVtqyKg2cEGatcZxBwuoF7bOzKxmNUMAs1QybyIOta1297VqFYpfp5jUv19SeuFO+nnEJb3PhcZb2VesyV3aYKgEbdk8VwsRnn35y/1gk1hiN62y1VaEbb0bVyU3SsO9KlpG2ZLPsrWHhRuXh4CwPHuGEB0krbOZ0Ln7tQcrlPLeq/XlaELTlMs7eUwQFaNfphJd04EDAfg46YaWWN1ddrY+8l+O3fgQC7c2a1GuwZprO9+5T62dYByLC+jz0BqlU60NrIe96SZVFJFnwkpvUKnzkC29SgCIsrzv2m/XuUUWGHbo4/LyTpGfO3Fya/vecqotAzuMf76GuJMnC06P+d0BKCZAgEbrO/eAHlwW1zFAM7NuijHcQYNlvgpkbj7ESoqcLZdBdJQnUzw6SLAmCsHbgg12b3hQ5XU3uTjWpjgtNpEGTqGgyPUkWu37sxSI1yVApyrlP1+ZjxAdiZUxQ4+G9xPQ2tyQxAyxQ3Amjh5noCEUzUSLNTKhGrOZgqUhscswZYRKSKJJEagcpGJpcIrTD7WdIxDESlXSAER0s6UXEQUEaNVQbmOmGN74BjnBgZpyR5YhIMLuNjwaJvYU05CER4cBEZpadgAAAIfkEBQQA3AAsLgAuAGwAbABACP8AuQkcSLCgwYMIEXYIgSLDiw80amiYqKEGjQ8vMqAI0SGhx48gQ4bkYICiSQ0fQgwEwLKly5cwY7IcGOLDSYoGOIjcmXCDTZM0RnCTCYCn0YREuY2gcfLDhqMEOZzMMBQm1KtYBcbkluGkzo9dKfKo6jKr2bMFrfIwSZXgCZM3yM5ES7fuyrI3TJ7g9sLkhpd2Awd+ucHkC4kTP8gtKrjxWcA/K3JrQpHGYseYoQJmOrEJQRkmVQLOTBoh4BAmZSTsQJliisWMSwu2msJkk45Gw1L8AAL2XNkfZXIDEXliW8EhWps0sNe3TBYgURC1yu1EyZNNVALfGQL0ze/gw5//lKF9+9kOGRCLp9jkoowXL2RAVL6+Ygbc5hHqNvna+eir07UkUG03HVcXasv1tlV+IG0FwnUUlSdSXjj5xiBdW0GoQVwHdWBSDbBdSJpV6mmAm4cUFXGZiNsBVoRJKE6k2n8sAgeYd8aZJMKKNZYGmAhscVMYRSBS12NjJPpVUIwTCWXkkVhZNcJJ+Hm0nwaiPQnlQVshSJGBVxGHXZbCyTYdN8k11Zt5KdD3YQZf+RdgWQJxkB54TfS3pUcdzIBjfYDKOEOVeypEIXg13MBRWgEuGcINJd50A6EXilAcRS8IJeecnI42Ql83fbBjaRv8aZxWSWF2Jlc3yfCUXWuZ/8Sbc0cKJ6ZJY2VVXBNOalmohSPQpxhPBFK0o6+/cvnjSXomdKgGL4SYrFFWgToRhwZ5iZK002oGWWgF/akTjd0CWJZUFKkm0J8dIFvuUTAxqRoKevH4rlmAvUURCpxpYBm592a1WWWG2RuwwGVZixJ7Bh9sroDKpcRfww7zBFixWHLDArgAVxzSaSZBJ9AMQXbsMVJl7TeDQSWOS+fJKAuI7kQgKnTSXu46bJW+FFF6kIaKLaizVcUZcJQI9NHQkdC/btVBvxo0MWpWphqwdJkMJtWBhhqoK1issh7baF1zcmPpTblud6VYX3Xq9oIcgD1VoR08Cx4NRaRwggivIv+0gQgnpFAE1OBNCrNAG5zAggxuBhq1DCyc0PfhfivOuOPYQS455QV1h/nn6Up4b9314a033x79Hfjg9RmebJuIwnnX20baGSl7zbK49kQ8tE3773XKHSSDaZ7EHKqcotCg2wJZd1N2wAmPktirYtjo2SelLdit7JHJdGZnFr/bmnVVffX3LQq39Xh0XTkr1j3aeimYRiEN1PkvN23V07ZNzdOV3hPQvbo0N54AzUIV20rRRMKaieVsgBezjc8IwiQN4MxkQysLzyYyQW5UsFf5o5yUqISQllGMc4CZmWQM8qcAci5mM9GW10ZWshC+kFECUtlAhkQzbt3QIEmiyKv/NhahE/4QeTEMmUCU8y8bHhGHM+mXZ7T1Ggw+8TIYC8F+qPebKwKxLED6UmQ8Y0UvAiZi6gmaE704u5lEpkTRKuMVAaOw1BiRjTcCSmXuaMay9IsGCvvLGtm4GB5Ci14UuaAACUmQfJkEBUxSkRx/6CIYcYNdD6TkS+TVPLjw8YaAeVZzLmkSly0Sj+ey40CYVKRJniyIHOycrHyoybIUR3QC2c9YMplAwMiNfgN5Vhxd+a5qedIjzzIa+jJYFg1hyyMY0wAXu8jMmYTRNTtRoQaossxpbeVKcdrJrkA4SChtJVizvIq2NGAABfEya1Z50ElweRThva+b5pFf9urieZOTBMU/8Dwn4ZwimFIVCInvjFKq1uYq0uyuP5xC2NiieartYO8kmULo72gnkE99R1QsIgl4UtLGjQqtJuDJyZ5IF55ELaqRY1vlo24Hlw5CCT00xZN74CMfGjSupfc5XJ9MBbrvyGBQjPQgQxwCkRJZBCMaeSmDAgIAIfkEBQQA3AAsJwAnAHoAegBACP8AAQgcSLCgwYMIExpcgeLGhyZXkrhwESTIxCRXmny4gWKFwo8gQ4ocWZDDFQwoU6qEUSMHyZcActSAobImhiscYOr8aMAmBhIddgodCqADCZ8GiCKEUhPGCaUKKwgQEKCq1apToSo8QVMlFJ0uaqLQKlIq1atWs5INiaKmC4UsarJYS9Is2rQC6JKMq3LuwBoq3+qtO/Uu1ryDSYZNWQPAScaJCZ+9qzaySMApI6r8YLlsYcOVO3/8oDIJADUqG4uO+pky4tUJMaNUQ/BoShgbYOuGuqErShIJ+WbeTXzk45R+R76wOaOzXdACKnSeYfMFXdkqrReHutym6u0bZBD/8YlSCYvcqzewUEIeAxEZ6Lev5ZChhprx7fMTUVMjQ075sIVAg2/5FWigTTDQEAKAI3XAlE9XeMRgQSscVxMUQa0mg00uiKDXc64NJsJiKsmg1IYqHZGhc62hFZplHRxRk4khsafSCMWB6OJru41QkxIHNaFSEAzqeNWLxQWhUhMCtaXSivIZideERYmlZEo3UCnlYVQCcMOQX96mZYtH8ggggVkCcCVKTHbppkFCpkRkQSHUpMGbXWpQ04IfcYBfSi6ttmUAU0m3Wg41EfHfTsKl5AKUZA1a6GAdkIicaCHIaNMRY+E5EAqa1nQEn54KlIKNB2IAgxok1PDBC0Xc/3BDES98UAMJahBooBIplEpUByw0sWaqBwbRBAuQ+joSC5a250INN4SQrEIdhHBDDc2S50JyyoaQbUoaPLXdCXpqS6p8LPypkgEgKCsQCD3ZRAS3lmGHEgzNkYWCIx7066+/mahA1wy6YvAdWSGoi8GjiUlq5lqVJnquTnXWpJ1lDq/WnUoTh2QhBknBlrFu8Q4XUrMS6jbybiu4pRANNYlL3MrEnVATDQZ1UNPBM5M5JYD2rsiBXEX6zCWDjWLwn7ppAkizfGGiRAQApKVE24RPy4daSh9YerHTRhP68HYbL2xpEWNOtmOXRQQW529pGyZ2l7ax2TLHWIeNZHEVp//kUQY1TasbDnqfMqHOKmUwUNKBugsgon0VBAKBQDq+HaqqtntQCnZarlu5KfX6EXUpar7avv+m7kEP9FoGQqgo5SvSBs0CJ5rDhnZWN0ouxAdTjKJ62LDe0UUmAuwYqLhWySkdIbNWOhCvA10nIA+yaCiK2rjlOViPAY1kt6cBjhOOAHp1ys7w7ZDHCv57sMP65ILsnh8EAgu7E6t/SiSwYHr9QqGPfRRGrP30Z1EA3Mn98rc//fXvfwncHOYMtKpWvSpWs6rVrXKlP15FUCDqK5CxkKUVYAmrQPNzXHgImBLz+M4y6pmgSt7zwgmVzU7kY5D52vO17WTKJ5xSFqj/gNgx7AFxe47rnk/A1xl7oaSHCbwhSnhGF+ahxHl0EYLedqGX6tkkZGtJ2sLcN5SslTBbrdsJ8FIkvMGYkSzHExUZQyJF+rmReKIhXXZ2Qrua2I5FaisTbPLXu5f4qSZIjMwbBwO5lChqJHq8IgQxhkfdvK4mdkRI0q7Qs0D+bDcfSyNBOKeSO3VSbnsTzfkwILqD9A0lpjwldOSzyiJOTiWVy1ElL7eSSe4ON1HaZXF6o5I/CoRxYPPk0eTTSJRwa1htCqYy58agt2FgTgAA3JOKNs1U6gZxKVHcaVKTt26OjTjYoc3dUlLE3SxSN6/EwAqipqq4zZJKaLKmMaWJ/8pzEmd3TUjCZuwZIipVDSUSUQnaytlPtgVmWE1LZkOpRE+L7JGh97RhYCxERV2as0vYucJBMXA1bk50QltDyQeclJI53k6Y8gEnSsbCNIwWlEH0nBoAsCMYiWYUQJZSzdAixyAcVOCoSEVqDPZZnKQtyprY/CBsoEkQmRpMqrAJWkGSJkqskoWrB4GZSp7n1bXYTCU4Q8gEc1hWrfgIlx9BWVu1sk7enUwscyUKS+0qko+BUTRaNKcRSFYTTpIke1d0KVRwt5o1poSJI4knBqD4IeLlLjJSbKdIHnQbstKFsZHhyoWgkjC3KFYnoNVLxGaoWZ0glndtjJRl9TIim39AlixOxFcYe6C6f/WgU1ohmHdEY8XfnNZNRkHKbtKFlEniCV4+mVdMOVvYlHWpQuTBUJe8JT7PwoZczmotgEySH5Ykci0yKZhKcAJAZh3oWdE6blGsha33drV+AlJvA/eXIPF61YTx269NRijfvFKoIQ+JyEQqcpGMbKQjbwoIACH5BAUEANwALCAAIACIAIgAQAj/AAEIHEiwoMGDCBMqPLhhRIgcKSKmyBFixIaFGDNq3MiR44YaPy6IHEly5A8XH050THjig4uQJWNe+FHj4sqbOAHcWCLzgosOOYPm7OCi55IbQjvekKnFZtKnUBlqkYn0aYiYP0RE3VhBgIAAYMOC9bp1owiYJENw/BBTbdmOXb+KDUv2bcerJT8kZEsSiF2ccefSFfAXJ5C8BDOU1FIYsFfBYwk3vjmVZAYAeEcynrwyMOS6nDtWHlmxJJ3QcB9/lox6I52SIwCMKHmgtUbPgkHbXngANkERbXcLt5t5pFaEG9CKhDG8eU4YJX841UgiJgbhuOd6rSAcQ0wSW2nI/ywB1DnnDiVk0hAewkTPHzLMc5ShnKQJt/IzgmhSv6fIA1pAIUMKsWU0QgoyQKFFb/5F1wQI+RXWgQHpNWjhhT2VYEB5EQYVwmH+wTBDhzNA5x8Q+JlXVExpXNbhUxmkIZMLhdXAokqoZSeWbpydIGNJNeRkY0nxNafjYObJEFOQC3UQUxERHhlZh0XExOFAQ45E44tSBsBjfiuOxCQAII5UIJeq5cbai7P1BUAKJW35IgBdfhlhmCKlAIB3JOk5Z51rdggnSdcJhEJ0cyaaUX0oHBRESSUoKulAFY4UREYbuEfSD1faBih3w3VQnwnTrcSnfcdx9ilqImhK6GRq9P+kwaQradCTGi9uUF2DJRRRamsbFFFpTyT8SqtGInwAw48YNltSGjB8kOqxoaFQAxH9ORsdETU0Su1bG3xQprYXIEGHFjDA4IIL6WpBBxLkjgTEB8Z+S1AIw8r0wxUpchbCFdmSVEK/iXZwakxleDspCmX4h0Gnw0HREwbT2luQCAeTBIVtEiNcscUZidBwTBvb1YGrI5UBsV1CpKndLqh1MLJ9K6+0wbgizeqpyzsGGpqtJQFRL0Y8xCTnboA6h6dIPHDUREwKD5e0eYeW1ARGLMQ0onxTyzdDTCwklO8VHXad3xWQHsSsSDmgKZeac+bwbEH14Vg2z0jOeQKiAiX/QWSiZneoJElJALBBSUgoGniH8JK0waAjMQc43lMqauJIE5Uk+Z+Ue+lzhJezDQBPJCneuZ35lbSEQFmKVLLbkHmuaMdiDkQEYnPiUMHuvPMeA3hz8jUSEQWFfgHwIL+4a+QHGRDd0MkDW58BCuG8efTCGe8XRiDUV4Z5Lb+tnQBGmDezSD9AyFG+F7iI9OkCgLqbYmnnVNxI7oe2amv0l0Sw/aQTGPSgwoIeeOCACExgD6L2lw2wbwn/i0qsYmICu2GPJSgbCa52Ix595S95GQjYejrUupjAIILmCYHxgGQxHmRQJkAgQdsKkwMS4EwmJmjaBRHCgkfF64cNCkLY/3a4lRFkoAZJwAAQAuifJQABA0moQQbORETUGBGJSmSiUZ4YxSlW8S/JWhYQmwUtaX1xJT0coxpLIsQzHmQ/AZMJgAREII0cKEELctYPHvRFF14ohjP8Sw1vSEEdWkxXFurVAAsTLPaVpFjHKqHmUOgcFTZoTB1qz3uK9C369OQ++ekgVj4IshD2ZITCmWBMdHZGoMVkg6hRpX0s6EYAnOCFF4BlYUQpsJrVEj3q+UsItHiBEiwyKShwRAKXmQkVhMaBMYFgWTJ2ARN87C+LK0yrrAOV+4mElI3JZmP6lxahLG8khdqZ+Ho2HGoibyXsA6eq4NcccookUh3JVHR8Of8ZcYZGVCUh1Ua6V5LvOcefqDnfTNS3kORojmv0lI/xpIMR6+UHoa3R3kJ8OBJ8QnSdectPvi6FEOdt6pjzBGnl8uNQklDPIMDx391UKrtMxuRjxnvnR2OHuuac8wLXA0DVTMI5mva0OYwiyO1IohfYrSZRwhMJ8QTSppHUpqg8/Zx8GGQm1pXkdTPN6uxYuKeS+MmpcEsU5ERSKC2azqhalY/qZGOat4pVUa8hyQjkRpKgRimiiTIeROJk16cqamkReejk4Cop46XgfpvBqmETNRqRhOBwJEncYu+aqMaN5CI4o+JfGZuoqopke34jCSfDOtkXDW4khQOAPSPL2rT/zqmy7RtI3XJ3ulMkam+bIkgJj1ZL2ywNkwBY2wUCWVzU8HUkaTBIVC+wveaiBmdNLcjYrBsatAkMIU4qCZS4W5gqlcSXWSvJ1shblq+VZIh7CQ57o+LN7CrkaSVh4G6Sucxl9gC+wxnqSK6mEUmu9n1wlZ9wXls7jhSNsFKDn4KNGxNDcsSbWcGOhIVzFvne5GarRHBWJ8wZV8oLpQqRZBpoGc4No8ZHS4rKyRDGz6joAH46+KdCq1njmywlJk2Z70A2gFuRVOUvtCNJGa7pRpHJBKyNWZpIWtTcGM1IOEkmFJMthrGeQHk3O+nJT5JHFKMcWT4G80/CjsUwh/V4XjgfapCISLTCvlDyRfiy0L7uXJZ/xfGefJbUR/5sEpSwGCcteQmGaIJiaoWLkBgyF7rUxS4YuMuz5JpXoy84IUeu8UIaerOQrYWtT6OPW/oV8lMa8hCJTKQim3ZOQAAAIfkEBQQA3AAsGwAbAJIAkgBACP8AAQgcSLCgwYMIEypE2GGGDA1JYJRo0wYJEoolYCTRIGNGh4UgQ4ocSbLkwA5HWlhYybKlSyZaaKwwiXAFDS1MXOps2eLIR5pAg540sXPlFyhCkyaF8qWoBRM/lZpEYWennBFSs2pVOELOTjsotgpssrOEWJIVBAgIwLYtW7VnSZbY2YSmCJUuecSlmXat27Zw95rkobOFiIVJdCoRHLTvX8ACGAdVojOJQS4vJQt1/DhAYM1Ac7bkInCGzhegG6vt7DlyaqAvdM5A4vLHa6CcH3++XfKHSyQydIbgXTL3393EQ4bQKQMACCkutSSfzluLSykgCmJuKeUw9e9nRUD/H70Qhk7b4Acad6u2QvqBvl3CMDkC7+gN1NdDdj99w3aeWGm1ghc7cRHVe6l18F9LXszE2wpeFXXACQgCdcIBTsnhYIUJQWGfUxZ8AUQTAe41QhNANAXiSi0gxSFvIGRwRQlkfLiiSy2QUcIVGWT3IoIcJLHgjUQWyRIXSXDwo1RN2KjTAXpVyAOGILZQ14svqKhTCfgtKdQGc+30BWqaJaaTDyV6CdoIPuxkmVJtunRAevq95Rp4VLbkA0k4yMZhna29aJpLOCS0hEtf+PgioMhVCIKWKy1BUJgstaAmAIze6aWNZpnXUqGXZnqpQH22JJFLcowq6qgRsmQWGS5J/6rmqmoe2hIZAz3nEhCj9noQENcpSlBwcvo6ap4sNRcSFDp9QSF4mfL33QmQruRiUDegUdhwxkoWgpNo3CDZB+MhemW3JTVR7UpSfFBhB0SBaMIMXs4Qr1NQobuQDEhoa+S/AFuABnD6CgbCBxhwUW7ATknBBQYfCFuwVB1AUSrDIeIgxwUX/PADx3LgsO6/OEBx4MQG8RAniFKYEPFtB5uwcFE+RGnsDQQ69UMKvaYQX1FeiMshCnoU9QUJKBtEwsgWeBFWci/MzGIGSY+UgZMWSEEmYx20OtrJVZekoFVgJ9VBzi19QTVxKDjiwdtww52JCtNlsK4XZZcELKLcTv9H63QhrMurSR04ee13f3/HLI55G1S4TjwjmDh4KRTWuEC05bXoap01mh5hvyF0gk4mLDk5gvey9OxAH+h07uZ+6abpi2S55K5AGehEw6ycy34pDTqtbSMGofZ+3Ow/YoAjABroJDHsrHnOIQg6adCGSxeoajx7yP94gUsUYa997Mf3+n1LbZjJ0hfjR9/9i9Um0YFOSPNOPvejkqDTR1fotOGPONgeYE5xqRXo5AoDUZ5L0hS2Co1AJ8QjCGVs10AOtc4lizEIB/zFkj1VMD0rWwkalNQh0g3NbXFLYQ9YwKHUWUskRziT5ARoJ2mBJ4QrOcJgdlK//NCwNTZMjv7/dGIzoLhwJa+7jQ5+qBYdTKd2LindVo5oATlc7oMK6dpOpCiYIozMB33DIkJCgEOjFIE4RahKgcLYwBAMiSV2OCOCksDBMxWxVypzChreNKoR7A1EPlCCd6YjAiWUUSdAYCDKRAADrFVpCRggwQtC8DyDgCAELyABBpbgSKe0AAaDFONCTqCEJUgNYzeSwhKUsDpRaiVGM6oRxnK0ox65UiykNCUqAaZKVt6SJPyq4y6HKTCC/ZIgjOxkUVoASUlSEiSXzOQmlbmTT4aygh4ikohIxJgTpYhILaqaH28UyGvyppCH3JUi1QSvFc2rXlRsSb7UREen1AxdeSzKHl8E/yGnTKhqF8rQ/6aTxqJwgY1hc2NR4jgdcokpiaJU107adRsv7gSMxywIGcUkR8asoGg6MVBGGfLGpg10imQb6UK0aEKxZGtbKhXJt3QSLq1QEaKpEQITd0EdKMpTKfUJaZeSc7rX+Kcw6xQJ6FzSQ78x8X23GaLmTLK4tLXSqfeDzHuopZPDhSSGLvEgnZ5aoTLqUCSeagl63lPU6fyMJfMBSVVZwkW2krWFXd3Xk6DXOahSB1krUdZBNhjWH7X1OzgcIUKG1B3D3vVF4nEJaQwywZbcjq++W9IFW5LBXM1scI7Nqp3U9Ed2CUuBLUnqWEUbKC890CURdM7MpOOlw/+mxzrc8VH/XHLSCtkWPAZ0CQIBAKuWyKq2j/WSrViCq/kxtXislV6FpMqSDhCrJQj9U3KXtByXyEB9RmlfX3sVP0qtJFXQdV+vvGaBiYgvveMd1flYUpHaiDezl3qrBS7yXvupV77gS+tKQOXf+F7qYiuBQfNcUknfbvdH1HOJBgbVkq2Z7sFY8tPw4ItfL6GWRQIxrwUsVeAOL4lTuNPdgSvA4ha3OAZN/RHwXLI2AAyJCTFNjmiORJDNsgSnORaMT1dyWYEs1ygNDrJYHhUrg4wuikrWzBGvKhDwrqSzUT5LZVnCR4NkriV3zLJUlsoSJCwEwSuhl5izQmGWEDj/IY9zSeTeo9PoCsAIFaoc40JyFyLO0M5BpA6ZWWROOBvOroB+z1xZdMWDlHFO0HpqoIkDWAuI1SSlNUp2XxOt7wQOkUkZ8krMglX3TTo1IkYixdC2vhrfhgU9SKEKn8Ybu+kEb1ux8krQtGaCsMlNcWGpZBv9y7HpxIqMoYpVVHvLrnyF1pKJWjVd/curTdTCqclSUbjkSjAZDdu8QQGr0xbjpC0NaND+TjuN5tVuMQVfxCYOzkC0s57p1yVB81WTVgQlDk1pRVaaWD5Z5rIkxyVmpwxrmCeGEmq2BCYyyYpNcGKknsS7YBVDM8C+oDGOeQxkIttlyS7+wSCVlJhGJUISCXtdkIMlLOG7dBjEDM5ykDTkIRGZSEUu0oaMbKQjJAdPQAAAIfkEBQQA3AAsFgAWAJwAnABACP8AAQgcSLCgwYMIEypciLCDiBE5cowQ0YGhxYsYM2rcyFCEm0YUQoocSVKkETQXMJDIIOKiiAwkMFxAY6SkTZKN3LTkyLOnRRM3RbbI4LNozwwtgoY0YbQpQSA3hcBwSrVqQhhCbgKxipDGzalcw4plCOMmjaYubDIdu7GCAAEB4sqN+5YtR6AlXWQ0YJOoXZ5u4c6VW/cvzww2DSTkUFLHCMM+Aw8mLACyzxE6SnIo+IekEctFJU8OUBh0z5oj/wysQxKB6chvR5Ou/LonApJ1AIgoiaM24NijS/vWiKNky7QkMQzXKHqy8OUWMeQlGKUkCujYLaMoGQWhdJJbsov/D7ulpPKOnUm2GD+w+eC3FdgLTEryT0WeSmzWOYGdRQ8PAAYoYA/XQXcCayUpIVYNWZXUiF/ymZYBSCUJUcNyNeARlA03ROjTDTYEhceFHib0QYhKhaSDFy48ZtoILniRWYoU2PBBiZBxAAUX1dHoo1JRcAHFZjiON0MJUvyopJJSlDBDkWFxwIWPW5SwAnYrlFAejVwQCSUARzSoFghfbgQCXjYJcYRvGaCGE4RlsjWhTXjA6RQHFJKkGHZCAOfcLuLx5aCXGrnRV4TuzfWceIiV5IZFaJRUQpGJUgZlCSWhcVAI3JVZKV20fdnjSCEMBBVJJMT56WxxAkBCSVuN/1CSD62uumiRPpT02Bue1erne6GW6WZIbwxE30h24ohDBcw222wMqZbZ6EjrFZQkSXq1qi1ByI0kxUJOlMRFiX0K5pwAn3k4JUlObITiSEJ0KJ6tAsQn3g1iimQDVWjCq8G2lmmQr0hrGXZAUAdsADBPGxx80wEe0oBgUHKkEGcKcqRYx1kLJ9SBC+EuWZIRCNjQAg4+3HGHDzi0YAMCw4ockhMu3NexXSFcgUQL6clc0h8tIHFFqTdDZsAdM/qstI863LFn0Rm5kGeKOuhBRIFsoUCEHkmn2Ei2UHOQq1JCcJEsexlwMfCshOKYwW1RmWDzzR2YsLZICJw93Kk22f/BH9QMnWBHUFvVdsRNePAAuE88aGjTmn91YpMRii9eFQ8xh9RJWGOTZIfClo+1weCzNvWBTTaQmR2944Hw7kg3coRpSdGOx7p8r0oadYUWI/qrosGyl8LaYCe0QtchPe27ucAWKehIOlyJ0OwjeQHl7UV6obtB645ExJfYF0mEuAUhURLk1/9uaZmHk4TEQM+LdIGq6oPa6gUl7XmsSDuBXz+rcdqNegDQgZJUy1P/uxWO9heSDuSgJHfwFfOAp607lCQHAEDevug3wfXF6XUU0IFAmFASvS1PNgr00LREwgSBnCBTHERh8IoUKZL8DQBXKEkLQ/clEpLkCgWBQkn/9MDDIumhJFA4yAwaI70ijud4JXlSQixIEiI6MTtHJEkEGdKBqYVEDh6il73kkzGczI2LXqTAFs4IHTGypwNbGkkj2IiR7o2kYG1MYL3E0y+RjKspHJjYSCB2xao4DDdtuxPcSFKnQh7GcSSJQiLFYqjJ/cuRCtFA5kLyqOFUUj/Kc6IBBEmSTrKHA5ILyhZqtzASxNEmnZgkjpSQxiGGMjsGyKJSGqGg0HWgBD3zURSYcAQTciQDR2DCqHz0hxLQEZMCWQEGari0apIEDRhoIjStcgIDuAAITGjBG+qAPJHooA5vaAETgOACA9xwm7Xp5jfDOc5yqgid6mSnO+H5/xcd8ciawhSSLPnJEGlSE6DWxKY2CUqQj4VsaSQzGcpUxjKXwcyaNHumE38ZTBoNs5hVQaYyl9RMjRbtRExjkYtAAyMZ+chGi6MljfRwS+zkkka8XJjEUlSxi5UxKBsrEyqVssqiuVIpsSxRDTYZEg7xEEQiIpF4PlmSOtQ0dKMMiimHc8iSJIyfDUOYb6g6EiNckqEC0eRNtvoXBtnkQWg9yJwqJNWxcGCRI2lkXBOSAUiOBAEDNUofQyKEs+41k3fD451IGRJCHvYiXRVJHQKrkfxU9Z2+QYEjBMTZTKggOweySS+LYkeCzUuP4xksBf7YExBSIF62Q+148FWSDf9upIslWSN7wpcdODrIpAcRQUcpcMDYdtB+EWIgBf7QPzSWBIwnDM4MxfNTkczxIg/1Y4l4y57SUqBdDKHiSKwYRtmWSJci2WJCvjOS8OCIu/J5ZUjOo0QmUsq8JYIiSaRokGuNpHjlPS4Ai9QtkXzLIEKsov8EnEL2oDckSSzIMkOCtffiF0fbiWRBckiSHaaPwdP1kA9HAkRjlRCBII7TCkNywBdeM4bSbdVBQ/K3As8XxudqFXtFkq0Ri8SYu71wkVZMgR3yqqwSlKG2YlasDJLEtgtWcqtAKEIBjqQ3OG5eq4pDEhE8UItJjnGrxCsSiZQuyxRsVedEMoICDhD/zR4sk3IrQkrXwBm5ccIrBXIDAOU2974pDqABBcI3kbAS0FIuU+5GUrj4hWR+KE70l/Cnp4F0NF1fwkECT9GqmKlmIOYjCfoeC5r2jeR9A+GUhkltmglTgGgD8e73WA2Z8ZGEtQNhDEkcQ+u/YEYzB6GeSKzXa7ZojySTQsiMKZDsYnNF2CHRlPHKeVVn98TRIVyoQbBNASAPR7Oc5WwPWFAiIlOg2tziXYBlOEbhEQ8jZA2Jt1/jRvmYm60MgXZIDo2deo9n0SNp9u5Kotg8grjd2FEtgDNyutqqrt96RPhwXGeT2PUET4nJjg70KEKbvpWyGFmzSD5nbYSMzia0y6qKV2wClpIPpCw24RhXUumZylkbc7C0S1/fOm94zpWRPTeKqRlp87027iajhkyh4dVygmJFK8tZ+kj8tk3BEU48YQqKCR4eujMFRU0RetvX5Qa4ut0tJFEIum9USy21M0q5JCl4kcSWorK5XUJqS5EPQI4jKVHJSljSko+6xEOp/ahqV/uL1rj2o69B0yO1TNFJUrKSPyfkJTGZCVN36QbgFvJo9kRoNZuG7r0eyb+iZ5KTXL6QnO1suEoDmtBgzfqqOAQiEqGI5QICACH5BAUEANwALBMAEwCiAKIAQAj/AAEIHEiwoMGDCBMqXEgQRIYrREyQ8dLCgg0nTmxYaOGFjAkiVzKAYEiypMmTKFMm5ECmVIGXMGPKhDlGhx0TJFJsSLkhBQkTdnSMmUlUZikyHFQqXXqSSVGYO7gkZUqVKQcuO56+ZFK1q8EvT/+c8Eq27MITf55+MavQKVE0bOPKRYmmKFevQojembu0ggABAQILDvyX79I7RIWg3IBlpgoRhqn6BTxYcOHITEWomIllJ8INm2XiwNx1cmXLAkh39eLYs0ARQ2WSUF3672nCqWlXJTFzDOQrM7Pork359OXhVLPMvOJkJgbkkm3fPg5dKYaZTojMrFO9r3Tjubur/6wzkwgAA70hi1/fHfZMAwSbEK3Bvr7qGkSbJAxC9Id9hKZNJ0AF/x30A1FBnOQGUVl0UCAAAYJHYIEdKDeTG13xRtQfDj7oYQdpETVbZKwVhUaHHmLWQV1FefHfCQhoVYANKaR4Ugo2yIjAWDaWNMISt8go0w4IpEGCemWJQEIaCGQlJEy3LDFCj+uJYIAbONSRx5NP5VEHDm4YgCSVKZLgRWhcpqlmASp4MSKZZp1gB5dRuDASeyC4EAWXdvAIJwAmxMYgDX8qVYOFRI1hQncuCCrTooWSZkJRY7ggFwxFlRDpfyUUBcNSHAQ5ZI0eRlgZdQWm4GRMt0y1kFsykf/ao6mDoZpiCkTdVVAIRCVRKK2oRZoEUSEMRN6jmwKL26aAbgdAiTFdwKyyAdgK5wUzUTQTENN+d2p4kQIxUwsAbClbst7WCu6fGsaUx0BHzLQDiszWS1AHq8J0xEFowhSFvfbuKZMKJJFBFBc2UvvXhB5yQRQZSp3QL0xrAbweWI75SdYHUxQFqcVyTUrUFB9Ah5haU4LM0AgYF7UXnDBMTFQXPsiaqg9dCKnCpyqXlAETMq8p9JMqMJFBz6SFcIQPRjg69FNjGOHDEcUiPdcGQRz79NZr1hGEa1Yv5EbQReWBQxL08tVBEjiYSzSGSK+Qo4wq/OCqjRz8QHZMNqz/UOgHjT2VxZs9k4AoUViUXCC08moa9kIl5CuTi9WdTJQcjy8lx1MvR3ZC4DOlkXlZaRSFhcZkrQAHUVagPnpZJ1hBFBx+dzVncCnXh4IjHvTuu++ZEPzfCIfDZMdSIwRNuH0Kr2tfuzGpkDtJI7gkUwV3F9h8jxxUMFMp0yekNUxdZP/g9lRykLNM3CUEPUyWkok+mS6IeJDDMr375/xwug0TwgTxwUwQECn+wSlGMvHBQBYkEx2gqzjfYpYOLgQAEBDFZnAyIJxwNRMQiCwmcHngbarlPDixKCYmsMC2ugVBddVLXDKxyEy0wMIRWotMWpiJDQwmmhoKqF44mAkZ/zLQG7BlMF3B2tQGnFaAowVRJseLFA6QSJhTMOt2MRmNQIwQutf9qXQyMUJBJthDL/boiTFxoEEY9xIV3MmM/wGBzCh3ECLORIFU2t3v9uiBHrCATAKcydEW8sGYIGFWVCQhwzyEBKJ8jCRLIIoNUtS8Rf5nbjJZglI0kCj6/EcHifyLGu1TAyYWQANdwWRMdqA4OJrlA5J7ySTZgsCZYM6VVNkcUQgYmULKRHS4LAkYHQmdls3ECq0MJgA+ILuiVKw+LugYpe6Qtp514A6mfMkU4kclEqxOKxVAwpjIJAIkeE8rcFhevTSQF6J5wZPQqcGZuCQEVLpyBCYA3dDGkP+FOqABBxcAAhC0gAEMaEGgF8ABGuqQhWxyCQsmCJ8yFbKBJnCBjFwTmg640AQjTpQsVsKSlrjmJTCJ6aNxqehFMzq0jXYUpSj52d5YurWiDRKmBMGnPoXGT38CVKAENShCFcpQhz4JohI1449ExSUiGWmcXVESk2KplSglFWns5JIKcABP5MhzpjGpp9ViJiSaYdA+KcCZznhWL2/KKJxQ7VE5z/mUdBYKRjKikcpwpCPX/SeaUKNm5q7p0G0+yHJE+cJVw8YyrXROPMaUCTJRyky1dIeNIKzmRFf0FDqqxpcxASZODTLMmTySLxzz2GgJWRSSGaaWMrnlahmiywH/yuV9MOHQbE0CoqKokyqqhEoyd1sSWErSKxJLLHGXEtk2+vUknOwNof4jhFDu4kGlJIo9VcJAmTTofKEs4XoqRBS4oSSSOqRkeG0U3Jdo8iQ8lAkAS7VeG+FPJhArCWgLcMiE1ddGjTQtSfgzE/8gsoVJ7NGBZpIghdgxgfL7b48CKZOb8msm/4owgpcFJ4FFLyGYdeMRN0zCP8kxWweRz0y6emAbitdD+JmJfsY4Ey2O2MVSnMkoBRKvIWlWvSS+YYrwNZN9DYSLvyyghOFU2peIUSDokYlvlBzkF6fIPTKBDwDQaDwR/nBTWISJFv33kt+2+MuRwu27HkwTj1JJ/4NkWqIgtcM+H4KnXuN7CRHiK2Y7R5BZXH4JGVqwQi/fmVkwjEkL2ktDQ/95UzmUyUWc42cXMus6MnGCCmXCLUdbelOJhokFMCstTyc4UtiaHGhDSGUcM+uEMDEBcLxb6VMXqngFuIIFZ3LWNy95g0QZSZ4LcFoNuzpSoG1fd2Gy4z/hoALQjna0Y2DmHmEUJnDDckyqvVzD4HbKAqEwTHjZbd3A9iV4FAivZuKrcqtmWDOp2kDuCxP9uRszZC7AfAcCGhTf2zAhdjNuC8DNf7OlfjOpNqxi0muDU4WDMtEVQoZdPipVt8pPxtv6YtI+iu6UTXFlXngtWSDNcMbNBv+p3kyw598qk9w+3fveYg0SKnk1fD2VvFUsW4WS5NkPvC730MClp5R2yuSx9cl5gRALE8UwJcwwycLMh8OCHvDxdz1AwfBwXYAoUgVTRHGcwxPSKaKwtSqqY91zDR672dWuLAsH4dgJAuuYSDxOH3+JaP/dZJicLjKNUq2791uAStGG6TGR7WxrOxOkq6a5uV07HNFiWfFgFipix2XkOvufQAmOxY87FNSKXR/AaWVwYTOcVhIHp7jLSyr2ugpV7c4suenMbmTKG1hn9HZ7yYlOdqpPnjwsoz5lbmxpMhvaSLO2tqVJBeY1I0usp6aa3CQnKKeoT4AiFKEdxXzBxNoysGlKfph4LfujNdPuy/+UNnHb4EpjmlG5FrWpyXvuSnEIRCRCEYtgRCMc4REgIRIWExAAIfkEBQQA3AAsEAAQAKgAqABACP8AAQgcSLCgwYMIEypciDBEDRdlLgiSIuVNlChvKAq6UMZFjRAMQ4ocSbKkSZIuYkxYybKly5dPsNjgouXjBoYbHGrhYgPLk5dAg8ZwcbKoUaMHwARluabTiqNQoa7otGbpSjAHompN2EFlUDBAtoodGxKIUqEdyDIcsSNolrRq48ol2SFL0B0jyJIJamKu379HTQQlU9Sry06Ao1YQICCA48eOGSeO2gloDIYdqrp8NHnr4saQH0vurPXRyzVwCZYAqoS0Z8ahRQtwvVUJ0BIDp7y0Qfs16Nije0e18XIKACkvSwnX+jl25NnLo5Z6KUXQywLRoTZ3Hjx70QIvBQH/0PESi/ei24FDP28Sy0sdA2cAtcO+/nI7QGccbARUjf3/f6kBVCMhuQDUGjkAWFB6oTFWgYIE5aCZS0SdtEEFBxYB4YYJFTFhSxXcRFYRPwFFAQgcsgcCBUE9oSFtIJC3lA0opqgWCMQtpUONHL4wnVUTPCHIUzYOtIIgJVpVygtFQmUAAmwAKSVLhRRQihVZUEBBFlaUUkAhU07JBgIGNNlbB1r8wUiYbLbJEiN/aJGamWRtQEaSQD7iQwbsZeCDaVM+QYaIdAqUBpA6oFBoSSjIuFQa7H2xFAVzLipXBywG9cVfHfz4UliWsgdEUKVUepJhLcHBIYOQdacgHJaR/+QDUFI0yapsZiL3kg8JJQEUYXTe+tyie72UBEEfAEWEpcIG4KqZRAD1AQAGvgQSs7Bxt96iIQDlQhQvURAqAM0+S2emLUVRA1A1hFrutoWu+1K7IETpUgvj5ptQCy+xwSMAHazpkgr6FgyACi8xYmp89ra0BpEpvvugjSt8uBIb+o1kQFA/bCjxhj8EVWZUL5zlEhjtGkxbDSa3BAaTf21Qx1JZQKyyVHYFVQeh3gWBJ0wd30zQDz+79EQQ+ubgRJsqkMGCcCyQgTCbTiQoNFQdJPFFW252/dIOXySx8NWTzVCCFCo07LVVbKggRQkZk+3XDH+ubbfXesYtN0MGoP865RR2KDH2WB0oYYdubcYw8tUddKJ2UGtI8XSKLEhhMVBsdDI4h0VwvRQcNAhNA6xW7fCigiDMvFQFp+9dUBEYLlXHv8LFuNQOfLpOUgaev0c7YEEsZQTPuhe1gRFLIe3XAUHxknvxZGXAS1BZjfXB4ytV8Dv0N8buEhvTQrU0TIoqKES2wO2yIQpFT+BEUTm7tEXE6DcIr4JbAJUFSQgAJZ6N72qSdV6CAIYI6CW0MFMAzUSL/iTkD0B5XpEWaKYMAOUPB+ndSoxTKArSCXEt2UFBppYqbP3GfqEiXUsIJhB+Gc1d9WvV/cxUNHx16yVagOEJZTguLQAlBBd4SSH/xuXBRYHJJRd4w0v2p0PnOGuGZoofS2ygq5ZYgYgxxNW4rECdMgCFeArM4rBCtQGglAEAl+NCE7U1Li6cRiBtAMrkFoWDCtjxjneMAQlCxQKgtGEgVWTJIDbHvfp0YBDUKYikXjLHQiqojy/ZlEF8uCtHKmhWOFQIoFrChkZy6Hw7lI0RmsQC7HGGb0B5gs0g9LEUraB9iwsJFIISOo+J8YkTgxANggKFouSgffB5ZA88QMxiGrMH5QOQo1ryBKtBpTJA4Y0l45KjlyBGLQ0Eyg5WOU2TrECDLEkgYA4VFCNsr5sHAQHyggIpGPmtJbxIGToHUoPpCeWctNnAIiHX/xfumeByLfkCGP8zgmxaZQvOHFcO8gckWuRlXB/wHtto4R8FqYEW2ANKBcLnOihIMUyDgEMLiOBJqLCACC2AAyLdlIVeztMgamgEQO9G05WsoREVfelWQPCBNrRAB1OYqZTWMAUdtKANH8CnTuPCU58CVahAIqpRkarUpRola1uradfAJjarliSmUNWq126aU68O5EkZ9VqVrpSlLXXpS2IdUyy76dGuhXSkJT3KSVO60ja1tJBKY5rToCa1NlVNbhEVE0UhdNG0umSjBvORlITETQ4dqX0uWZKlCiolhBZsoVJyaJN8ZpUnBI1sRCut8hSkT6usoZ/Q+6dVBGof2//NqKpyw5FVduQdELyTJfG0aj2XEgPcykVmNKvsS1fw0ZbszDXkBIo5zWoQdT5qMiQKyomom5AVtah1cTGoS7bJXYZ8MyjiVEvJgIKy8o6EZeyFmViguRv3mqSah9nKhTJk35N4SKMDJckvgRJMAKHAEcZMcCZYqKBlsqSZRtkYUE4LoCL+J2RAmatIZgmUWrLyluayzy6B4tKRVMslCKJfKMfIIQl5S2OpVK59LKygV2Y4JDPA3sMmCGIoAqhi/dIbQjbJkk7aqsdmKuVLTpkQ/rykrCp2YogZO6CEUNIlvArjip9YKEy6JIcGCdhLGHzkLU95QyR8k6n22ZK8rgr/yYWCpEskGZ/5LIrGNsLPS/QWyJUM8s5wLtQhEymQer0EX4A2s49T5EJO1iiOjDShlBfNITm35I/jKc8a1TMu97gkmGncNApD5UYUA0BeLpFnBwO9KFS3pAZefEmAAcjqQpXxJWUYYEuwI2oejgs8LpnIS67Yay2GiosukQK4XCKuYrPYUuhiCUaWiEVF56u5GUlOtSedL0+xRApBdMkQnc3lcR2xJRc4cUuulWhuh+qGFIJ3S8DcbjaG6srrBgAIp0juM6cIvxtsIUxChQMQn2JcNRRIsl6yrP72Jlov4WiaV6Iqh9NGhSwh82pe0hqLd8Y2L8ENQcDJQY8nZt8r/xFhQXz1EmCZ3C/FcsmxDALBl0jw5dG7IEIys2Scy4XINh3cAV2SXhsdOMEJ7oGbFSRelkDZIF5uSa14rOhcpqjPK8nyQvoXHqpP2uob0nVLCiiS317zzVW3EX1bchmSNHcC80P711PEUJcwsSS/rfiH074hjLOk7ScZn9GS+R8d9LjA/2EfUN53lJi7BLY+V4hgfqWV62nUuB4HgUSLzNGodCoooIo8QUYFlFKphXlAcZ7oASA96s2FLW4hJHXrcpeH+iV45Zy1V4+XPNKwmdmy7yamlkJn0thWmzd/Ke90hPlL/fYqoUenWYgb/MSkziqssyTsrDI7BUU3KInSXZWjgNROzoHTJaATnd+/Bl4bJSWqTgnVVMKKlXw1zrFMkZyNKhfWCWSu+kViJ5i1ZHvSJ3UTKIOiO33jJoAjOIBROIfjJorTTSlhNzExEzURAronEDlRAzvREwMoJUNhVnQDdGJ1giuRNx6HJmqCgmsDJ3KyegVhNmiDf3fTNm8jZDJYEg4BERJBERaBERrBER7BbvoSEAAh+QQFBADcACwOAA4ArACsAEAI/wABCBxIsKDBgwgTKlx4kAMNNz786KjgCUwwVpsybmIVDIynCjr8+HBDgwPDkyhTqlzJMiWIC2skyJxJs6ZNRbyMeGnT5ITKE03aeDHCS5HNo0jXXADRsqlTpx0QIK2Z5cXTq1gBvMgylSaCDlnDIpRhpmsLsWjTMmzR1YwMtScxTB0DFq7duyk7jJmKQS0HU0cTJcFLuLDTJImOmjLZ8gLSGoaxVhAgIIDly5YpR8ZaA+mFk4COft6cdXJlzJc1k87q2Caggy6OXlot1jTq1AJoi7101MXAQzZ56a5N+Xbm3MPD8rJ5CIAnm32Sh7VtXLV0rH1semJlM8x1ycWrI////jSMTVZujrYh75T6bevsWbY56kbgJptP4usn/8TmJoOIHAXFfgRuBsVRiCy0l02zFXiQe6hRVoGDB/Fm0xgsTRFYExQCwEIPHoQo4og9oNBhE4nZNIVYUh1FyQcdxgjAB5QghUBkGUwwFS8zyEjbDMshNUEG+9nRlQSJOFGXjyt14ESKU9nB5EIfaHgkTaZEQYJ0JEQB2JUzTQHjlDgyoUIVYKappkxVqMAEkWTql4EeAa5p552I6AFnnH7VAeWRVeAxYHxQ4IEmmInUwRifAHRgXld9cMioSk1k11UYS153AhhziTBpYSIseBQYPhFGxFRBfBpfEFMRkVUJSDn/EaMQ4b23i4xOIFWCShogZRWTEGIGn4wvIKVBQhkoxmiwuE36ZU17AkDDUUZ8yuxxqhpxFA0A+HCUpJNeG8CwfDZxlA/31dSgtbVGON6nFtK0SQXnqQqAuOTyyV1NE+5wk704VCDwwAPHsKWqRtW0w0AdHErTEPZGfNAQNlWR6UCt1ZQgmbSe9p4A1ZJZZ02jLQTCIEcV4CO+AkwoYwFHDcJUU7AeNcEKEse3go5H7QqXkUhVcHHOcHVAL1JSDscDz0jBgTPRKq0AR1cT8MAkEcAdmcglv5L5wiV/InWIq1AnVIKod9akCCt97KBCGJfggcclYaiwQx+sJJx2TWP4/1w2Xh248MUU6e6d5iZTfOHC0H/DpYGhhkeedqDHNq5SCYzYOcQlJoQQWQgmXELxmoz4/XcOXIGpwmA+JqFCmlnk8CkGoRw5AR1/08E0UqH01WEGnE41AeuWI5TE7jaBEa10PJSFVDBjFr/SB8FMZYbVtD16VBaMS99SB6kf5R1hHRTyfI/e2zVD9UcV0v1T4dcER/qkTb19Vh+ELVMfM9O/GgiWqkkiorcSJCAFdzFimY/ogBQkXC4wXUtgu4T1rhi9QH8SMB1CRuAwmhBvZRNsFpmScJQqjCAhejgKHvikQD7h4Sh6OMjrbHKwOLWQTyQ4igoKYqWaeG5ZIcTWpP9CcJQVCSQKR4mgDYM4rgrGqVg2iYK0juIFVd1wUl7Ylg7+ZUUm5itOepuJDthHkx120WPuitgMaRKMws1khWc0ThMj9sKabCJ4NFlYHMUTMX/VBAx+OEqpwuVFJ8bpBEfxAweotceP2UtbNjFJGo5yAP/x6QBHScNAvnAUE1hySiY4yhcKwoSjSPGTMUKiTZhwkGRV7ISoJBAHj7K8gtSxJmYEViFdxqQ10gSODImJTbKgSzRSkJcxit9M1sCSzNlkAu9jD8uQWaAOIE8mjHhKHZBigVhGxgJIqUNYcpA1m5zFm2phy1EOITu13KB2R+GFp9DpFBEEySahuIFhOgD/s6BFk54MO1rK/nkXGVhiKpRIFUAHEoQaIcUSb4nPCfqJlERYoH/eA4EFMDiTAgyyQzcw35EKABmJ1YCiUymEPu1VgmcdCREXgKUsLzCyI5lCg5ZDAsru9AQjHECJWXnBAYzQnzsNwoELJcgILhAayTm1K4CIaVLDQoM0RGEH5ZTcIXYQhTRwa6qRqepVsxq5rXb1q2BFSwbM1MGnqqlNb0prSpbaVLfadSZRlalcAXA2t66tbW+L29zqdre8ubVvSdVp2nr6U7UIlahpO+onq7SmLNVQN11y6ZXEVLyWpgmmetXPUmvalZsSDWtX2hpQiQW2K43tUyG9EklzdtIr/6mUTECbSpIIOikncXQmSaPQCVTRFYtiVHoa/a0EPEqgpXXFaeiUGtWw9x2DIlShSW3oVCAqnRztCH1yBZLwalmYDhDXn3stiNGmUgDehiW3NhFaehGyXqQV5p1Iked8F2JP3q0ULi2yyYv2ixIa2Ugt5ETKOQmcEnUyp52vEtLTGBy1a8oEpy3Z5lG6SeGmgPMo4nxKD2mSCHAVCAWOGJGKM5FLB6GoiE5xZk2gKUFjirBD1jxKNldyspSB0MZCfFnMjrsQYVKlmHL8YoGUKRNmogRtM1mXjK4oo3jRBEMMuWUZyURlGfnyjQvJGE02NqUuy4i0MimZQVxZExMuEf/Ic4zTLG1CXgCgWQKD4nIhGXUgm5CZIKWMIhDhrORUHoWVBGmYTSA26CQbkkmjo4nFCMJJm3iy0XycVChtMsqBuFEm+SEkoR/NpKLKayCTtEklRe1oVWHSJpoEgB9poohGphFhNlnYIm0SMlZn+lOQrAkH0mOT9bBr1Paaj03csAVB2pqC9kKkTfwg0Jmwwl5mjtO+aFIBPM5Ej8dutb1mPRMwbHsm4wv3rz+lPWt/WgLA9LUj7aVlmWSEQdjes72sbG8yzqTFmJ63qr4sgWA8pybRefaNPxXAmXhii2rLN7LtFUaZ6MBbNjExC/X9KXPZxAfTskkV1S1wLG4LAGT/lYBwPoUDL57CXvecSXMAoMqarLbDhoFiTU4Z8pr0GuekCTZN0DrimfwQ6J+D8UBig2+kR4bfMvENQQgugcs63S45tAnAAcBmLF2dMJqVCXlTaJN4fx0t9ZZJDBFSV5qo2UcoVrGKe8CCOIkZrwqZc00+OOVdjrCEoTVIr5JYZr8zSec1qdxCaibAmxNomofHIIYRcveZlLTGjqamgzojmgIesO+j1jyBGHgUpK6E8TWRVYd0UEgdxChXPXNK/o7Cv7OfBICBIWBL/hIYvtu+IIhRzKKuwmSZzO/3BrHfMNNyKqRg9/esQgrZ0lK+89l+fUhxH17kghS6OF0vfIlM07up4l6Agm8q6Y7Mpjq131BNhVRKc95RoCdX6lmPuskhi1mS6uCjuEVO3vZMvpc+x9MVyuMgjnIkkZI+lXIkmOIjtGM7CAQ1unMkvcMnUQEmVaEqWwEmX2EvqJMmq8MkrgM7EJYzHOAnaRIoeUYehdJWuqUo6YM5msM5R0cYoCM6dlI63vQSRnYnOKETPPFRDAEUQkEUFbcmSkFk9PQ4MHhXd0U5ODcndwaFa5IndfZ9gkM4VugfibM4yMcSDgEREkERFoERGsERHgESIkESw/cpAQEAIfkEBQQA3AAsDAAMALAAsABACP8AAQgcSLCgwYMIEypcqFAEDTo43hhR4ckZGDBDhlx05kmFkTc46NAQwbCkyZMoU6pcCUBEC0URYsqcSbNmzFlgbiG4UwbKDZIHRdyAUuYOgltgZtlculRRC6Aso0plaeAQ05lgMEzdOhUDmKsyDxngSnbhBhVXeywpy7YtwyU9rqrY4PYkDypLIzGpy7evSiaRllLhwbeDgqUx/CpePDXGUgUdpLZY6oMx1woCBATYzHlzZstcfSxtYVJEHJuCQJfFrLkz58+qyQqyGQdqQTg2LcRmy9r1awG72VqwCYfg5JpSgvPO7NszcOVlpdgk/cZmGeirmTeHjZ1rGZtvhtT/XNSdbO/tz8tvXVRzCA6bd9RPPe+bu3yWd2ziAADDZpf7AAbYhU0wEHSATWwEqCB0bNh0QEKO1UTJggvR51pmFVCoECU2JWZSBxLYtMgKGhJkYWcYljjQCuzVJEFkUqkRmE1rqWijQUvkpYZfMKSSlwk33mfCjDWlUmB3ETIVg21BkiVCkog1KVAHRhB5FRhASCkQEF+BFUEkRsCopVQ/NOjlmTQ58skii3ziCJpwxsTGD2NCl4MgT6AS5557ovKEIDnU6dcHiMRpig1FyFeEDabEicgHghYEA15XHXJFpCddYdVVVBwJIJQ1vYHpYtUpCZoBCSxFCF2jlrcBIUsl/zAWWW4sdQgIrdoIwqY1uaHSD0tp1eSJv2mJwVJ0KjRbTaYISqxzkZqBmkFo1VSjs9rVl56gOdakgkAi2ARGq88GYF+kXdIkgjM25VruuZHaxJFNTNb57raRhluTJwC0ONMs5GZ7Ib6CKkUTeQKJVhMWuTZ8EBY2VVZQDnrWRILDuZJgEyqBLgRTTeMOKzCKAmTYZLozKcJSoTbZgDGFNiyFSFvLEvdycLgtlZpq1S4FB6s3S7VBzkt9uyAP0l5VjBEkBr2CEcWAZQZhDrsRSpyRsGFBDcrVYAEbVnoZiq9Bk3XCAXCEyOfaLsJxwAlll2eADypUwXacVajgw6xxM/9GQgyn3S04n3HEcHHfKIGgh9pxJoLFEhkslsESWCTCpwR64Iq4GoedSYkg9SoogiAcnqnAjqOK0DNTi0iMsQ/+MqVC6Av6AVYohyNeEAlXX+VHgBvscBUhcOt+0gmwMrUD0LtdwJRexnMFGFMXgLY6TaJGX1epNhldlxFL9dCE9ow1EZdNRpT1gY9F5k4+aCSwT1MqkEalx1Lp2yjEyK/tEiT4NtGDSo5Tk+sE6V5S+s50TKIxm2RJSgjUEhCW4r6DJI8mHtJSBMcEqpgQAiEnqNhMIpEoe/EPWoIqQtgigIriDcQANkkEpjYoKMvVhG8hsAkmRkVDQWHCJiEQyAT/bNKxSPWwTjmwyQQAQAebICBgrdFWrhBgEzpcLyY3gGJzzEWwOt2geyiLySfcdUIuNuwTIAtjBBxBxigOrGFvogkYAEgTKGgRPbmCAvpoYJNb3FGKrbqFTWgAAIjVRAutwkEFFslIRhquVVqwCcMEYreaRO59UsqATapQEMbNhGuYvFENbCKBgzyhZaFUUcxq8oSEyMEmn6BdifbnRpLlT0oiQGNN5MAQM8lRg2VMkZTUGIEElaYZNjmEyGr5G5PdiFczaYYsEwKC3tGkGJdSEQt64IFuevObPUCBja4QtZqEQnNR2cJSQjHNVDrJmjTZAls6AM2ZVMGF7jRbJWty/wgxuUUESbOJF/IpFS8wxQztbIvt8jJQgjLECyuUye+wE7yrVGF8DgVAE/Zpk+Ut6ALys0kqbIBOxIHABiEtUvWkJIhUgeUQBmxVGeppkwTsLFcd2EJKmfKJRy7ob7r0Uiq24E/EdaAFyFwbJrogBS0UcSo50IIUuvDDtTWjBUXNaEvkQAgRDu6rNUEFIeSQUK2iJAQwaAEWJhA7ti1iAlhoAQyCaFbVoFWtbP3qW+M617ry5WxpA+vaJOA2fPq1JCLgqlcFK1ixkvWwBikTY2eiJja5abIymZNZj5pUPi21qU+VSlSnWlU+XTWrxrMa1rQGyt14DWxxGpvucrrTpf/0tIL3ASqahopaTFEpoiB7oJS4dCYw9ZalLq1UTEc1Uy/ZtE5IA8vSmnazp5XzoFSz0QVqcZWRlrRvJ62tTFKxUgp1EINlDdqTwJJB+VSUKRfV6kav4tHyXHEmPzvs0OSCnYXaJBINhexAIMqUiaoGBtz9L5AEfJAhLcVIlgEoUwLMYIQYdCkIVUzNalKcCpeEaDW5aVvouZR7evh4HJ1JP9sio6Vc68Qn6VZNIoE6rqjTJuyE8UpEAM+ZyHMrLKuJy3QclVXWZGZRqaZNsGkjFDjim1DOhPdKRE4cf/dDnpTJiG50RAqxiJTHRYgIOqviZW4RXiWiaQSkiZKP/dL/zHgcpk1UZhJfYgWYzEShnGtizIWcd0J4PnMXbVQ6DC7klTWJ5Zi6bKNc2oSXCKGYTXDL5WAO2kYNpAnHEHJKIWMrz2YUlJFn0kqDHIjPRrQ0puwskwd10iatXbSqIzVKFxVEYTSZ5KcFPSpD0sR1AEhxTC656zhHSpM14aRA+lOT/8xw1pgaUE2O5OuZIPLZoEazliK5MIG0NQIA4yG0MWWwmZCHjzXxo7izfWkpCbImNHhPTeKzbl63Kj81wQEdZ2LHehsbU3qsiRE8Qa8/vrFV+qKJJ9TIRoOTDI4gE8/B2mjvVn1bI4mm+L8xFVSZgIFdNdE4IFslr/tm0d8j/8fUF73FvZkst9gpj5QCsdfEmjwR5QcfFRVrQoeE3xnnD28VMUkyxJqEdkw4COYpWpXEmiwRAAScSXKIrBzp1IQ0AMhhTXZI9eCUdiZ0BcB9X9x1xsh4JlOGYU1kWHbQ2JAmfBMIiGWim7YvZjgcNkgIZ1xCu/NFhWE1rEA2LJNm+Z0vAZ2JiAtywZm0t0lOhjKUe8CCOp33gwkxzbQCjR5nNonwManNQjJNE+Ee0NKev9EEJ10SYNlEWKdnd+pVdCybJKskUXc5nLU1ew3NnCZYP0nuZQLsEt2r9wvCNfBXcj/03UgHltbBjfY9EwGypFbJvPLhEbKrpZAtKusTKf+lt0+Q+Im0flMxTJTIf5DzRgAybKG+TMTH/oGYD391QZWqmGf3V8Uq7m5xXzGRPXbXcjQxZX1xF3mxF103PTYxGKrhPAuoYw5oE+UVG+43gBVmgIZGUcLDFMRTV8hDX/wHHWeRFmQXSnAhFyWoHv61TuPXN7wDFgamIZPyUtnUN5oCFp2CSwJobsWXK7DjJbMTKVVxJlmBKV5xJmLhMJyDJp+TXtgxOoUGFqcTN4QSJ2aAKIpiA4nnJY+iPYqTZWfiOJAjOZTzdnCCOdqnPS7hZmyDEzrBEz5BO0JBFEaBFOXGNk4hheTzN4GDWYIYAYUTgwJ2J3kyiGvjJ4BSfy8fRDfCJoh5szeOuGMPERETUREXkREb0REfERIjgTEBAQAh+QQFBADcACwKAAoAtAC0AEAI/wABCBxIsKDBgwgTKlzI0OCJDwaSJClRQqKBDycaatzIsaPHjyAJrtiSAILJkyhTqlTpK1UiM4P6eCpQwFOfQWYSpfK1sqfPkwm2rAhJtKjREV1+orS1ZIPRpx03LLGl9GQXEVCzatyhlNEMrWDDHpzBSOkOsR/piPFJC63btxtp+RRDBy4AOj4R2N3LtyMCn3WNhpi0clKKvkWFCBAQoLHjxgJ2IS6agrDKSSE6mlkZx+lkoxUWP368+PPTDXFWmlmYRbXprKEZj4Ys4HXWzSqzGAyzUrdtqLFn0/6dtbXKMAOHrLxCHLho4aWbP72ycgiAJCs9SX8aHHrt7UY9rf9MAmBtylTgi3afHT19yFQqxQgMsXKZ+5A4Kujfvz8GifsgLbNSZgN1slIiACZoWyIrdZIQfCpVoOBCisnGngBGTKhQBSuhp5FxKl2gYUHrjbaYhCMOdEFPvoHkgi4rLRBYijQeRMcCK+niAlqF+KRKjQqq4lMhr21Qlk/Q8AAkXzxA8xMjnim4Qo9KTYJAB0s21AEClv1UyFBZNsSBDl1WZdICiVyCAZZ7dYDBJYngaOZJk+jAQZi23dAJIKnN6edPcQDSyQ14jrhBCVk4+eeic0KTRQlRFgqXDxDOKYYZdrDwGwt2mGHenKn4IClCNCxSFSCHjapQCoBUtQgNE/b/8ZMZGakq1gm49dSHaX74ZEaktpq2Qa4q+SGWIj3BEeyIcPSkSEgrlHkSJkuWSNp3QGJSGJgLadHTf2Fa61h7WZLQkxYItarSJaOKO9yol6wECEFErKSAre4GQK6kCqxEBAAnHBhsvvtKyqBKJ2Cn0q74PnfhsrKqRF4BKy3RsIUmYjvqEisVoOJKlCwr8kGUrCRiQSWsJEaqI9uawqcolbAQEz1ZXK3DGaMIJMcrMeGRDj3NmyILPXhg9NFI94ACjeqqpENWSeVYRsvNlQHjSl3wZaBPGVKNlhE/OQhevD8VM6PXCdFRjFLsFkpHD3PGgcYINI6ARp9V9XA22gmB/8CEGXIyKvjgKS1gBhMg8P1ZCheEwUZJhPeUABthXMCy4pPJEEalkXdeVSphyIB5SCFkkYzg0lCSRRqEgnVDGllQIo3gyWRB4OgCcQDH1VUtUwG4CZJQgYBm6gLHnSL7MUpVcZwc7AV4+zSKsVl2ArNKCxyPe+5wBK6y2AB2cGRPEUy9PUNlRPAkm8SR3ZMV5xNlxU9tI7aCqe/HD9b8PS3CLVojoAL5lKQ/t/BAfSuhAlbA0qyVoOIrBeTLDNa2EmUZhQOcQ8neItgXvHQIeR5JwelUEgf2jYhgGhtRB6J3kmRcjiEggFxKbJElFIaJKipJQOIYwhuVLINuNcTZtf/wNALipQQ5CdkABVNigULZsFAWWEkxgCWQG8RIU04U4rhSmCUWeO8krRtIClYiDROGS4vvklQHZqeSy8kQJWHMIsaGqCor5nAgeFgJ9dqFRn1xEU+9UgkeBBIJlgysjwUrFE9SEgkAGGAlgzjkHLe4rEGsxAApU4nHLiYcPy6LYiopwQdcw0nvLItYJxEd/lLyPzl2MpFhWsFKFiEQQaxEZ5J6oqo4pBJBDIQNK0kDB5eUhpWwoSAsNAkGhkkjDHDmIIpKiR2YqSE7rAQaCYlaSqpAzQRVAWsLkcEXTYKGM06SNrisERpiJLqGbKEnSLjZOf2YzhEhoSdb8AiIUhL/hRqhsJ4K+ktviOKDnvQAhN18CwfgthJRPWWhPWFEQtEyvpQcVCxJWN41azXRkJwgmikZBXnsQgNpoaRrHdUI2HoyCViZhis+omJHNyAkn5xlOxuIWE90oZduIoB3K+mDTNNDB5NadINee1uVkEqjJAiwKpiI56iQoK2qUGGkLXMBsvxUBQu8kDgpsMA3/aSIHUUwBVkwqp+WoYAK+GEJV2jlQlZwhSX4oQIKMKLgJpGFr6Z0IFrowhI9R1iTFKML6PorWkJABEHgoQBDWEQkrqeySCxiCAXAgyCIcDvFvoaxjoWsZCkbH8tiVrOc9exe9MSnwsZNUHFUbUcCO1jX/3busImVrUH8Bjjb+jZGh9vhX9Gq1jmx1a1wlatC6GpXvOqVUXz1a/zGVNyeoElNZnSLm+A0zirZKX5a/VNXpfuasI51TmVVnFLNJDcgjshuyTQoUwvlVDNFVVVUNdNVRzWlqkwiCtlVVQeiUF2TfClLRVWK3nC3Xp9MYr7ucV9PUAFhvqmNbQrK6U94mtCf/kSo6THST5L01yY9aaiTgWlPVIHibtL0Jzd9zdZ6glLdCmSlPQFfX0rKNRsjBMeXceleqLSSH/lYITVdCZHgktGeQIOjR07IR3siUrdoMyW6MF+UG2K1nmQNLBBdiUS33JGKouSiUHlRjCpMZoTcKP9HZi1KQVeC5jZ7JMwqcWhIgCYvGqHAEUgLdCZUUKOmpeRpINknSvpJI12mSKC5+YiiT+K8FDk6RSsaKEfeuRKp+hORf9TQPVeST43QrGJBnCcsNcQzlfiMIeJcSTlT/cpQj2id2GunQjJoEoBaGtRO7NBCrnwSbuLp0ks6L0q+fJBMpmRlrjRloV62EplBcyXTjPbDJGVNlWDTIDNGCYJyCexRHSwlOhZIfJdJblXbukbOJGFBMp2SkPHR3bYqWYgIAkyVCPPetbZVMVVyzPnUp5TbVtVzTUIgW0YI4Rkb2Ep8CQBQpsRmAJe2qlqNkk2uEiXKpbXG+TtLgVDWQ7v/LLeteC2fUapkNRCno61QaRIZKCwlDEs5voOlU5RMpGOSDHiwLB6zm6NEOzGnZLDEI7FHqiSSSU+jqiypEgMETCXj1rnQbXVulGSkkCnxRdBHPqpFoqSRAFCOSpijdbIXijoqsQ4A8lisqHvSVoFMySABUC+V3EtVOEDkKYLVL5X8SyBvBKOdTWPHlCSAID1MSYsW35dJQwCJAhmjSspI+b6scSUvNPRJ6td5uEj4JEIjSONRsgAslt4tXlxJbAVieZi/Hi00h8DkCaLElTTx9mGJokqmmBBvrQR4S/pzoAPdA9cvyVwryS1CIo+SH5qz1r7WUBFXgnmF5L4zIr9Q//YzHF/bLySGK6GhPLGfJRw6XrgMidZKqAWkfy6pqimZRMgTIkLOBDhB9kcjK7QSLvQRg1EY5OUeOgBqiDYilVEYndURGNQTbAZ8AuFBKpEKCAUSW6USFmSBCdFAKvEsUCGCKVEMEASCBDFBPZEHYIGBKtFTKggAkKYSFegRIvBUKhEBBAR8B9QTCvQWefdyLXZkw+ITe/QW9+MT8EN5/DNL+ycWasEWbSYXPUEXr3F6KdGENvaEK0F6r9FzLwdlHYUrHwYe4vMT5dNR6bM+AKJiEZWCBUQWZjEi1vMT2bOBiqM73XUSYpBuGlIqp5KAqsIqriJkWaI8zFNpqgI9VZQxPcEiAsTmE0xRhAAiFe6nFFdBNboDVD/hO8h3H8KzcDuVB3roNZTyJ5eSKZvSKaTlE6HCQaUzQouSOqsze0bxOrHDRotSOxHITCOReJHTEi8REzNREzeREzvhWkERhROlObz2W54DOrq2eIeSKNK4KI4CKTNoEIzjOMLoOZNTOYTYjRzxEBExERWRBAYgA2RINQEBACH5BAUEANwALAkACQC2ALYAQAj/ALkJHEiwoMGDCBMqXMjQYAoNMEyYYOLDBxOJMDSkaMixo8ePIEOKLOhiUCACKFOqXMmS5R5RCTCFMgNmzRowZkJhSiBqT8ufQFMGGuRipNGjSAWWgBQ0paQhWgBITUp1oVQAWoZIaooSUomqYBtiIBV0GIUNAMKqXSsQwAYKw4KSwsAWJAcqQEddSVu3r9+EAK6MAkqFw98VTFuKysD3r+PHDQFkEPUT0gqquH4KaQy5s+eOAIT8xAUyz8+on1Or/oj1Z56FNlruOcF5te3bCgGc8MnShsFGLRPVxk28uEEAiVo2GlilJZPhxqMbB8CkZRVuJlqagS69O24AZlqa/9DQMgF37+hTA0jQUgM3QS0lnE9P/y8ACS0FEUzO0sr8+gBWBYAVwSH0RktzfPBfgAx6BMAHc7T0RkMu/BTKgg1mWBAAofxUVEgZZPKTFBhqiB4AUvyUSQZhgYDXT3VMZaJ0UtVBGAieYSDiTx48V+KMR0nFhAdAZUKXdxyE1xQuCv44o1QfZNaUGYYBaVAHQuzIFQFzVNECbTKqdtUJLVQR4ZYEZCJEB1b2lcMbuJyB5px0AnUGLm/k0KZ0KNhgSit1BrplK6bYgMKejmVAyFZz7jFECzNc5aRRks7QwhC8oSkJISwiatAlZwLlwZphetoWAFgSGdQcl9RXRqYszf8R46SmWgVAHaG6VEZqH5CF4HO1rkZdriqR8sFaorXUygu0BvsYAC8A2pIQRmHyUxDNOmsbAEH8hAlHOcTFEhbZahsdAFi0NIyeB8HREhXlmnviiyvBQRAJLXETr7z0pdUSCdykoNi+/PZLGUspVMcSGAQXfCIYznETSUtJNOzwuUm0FMlAjLSkgsUXf6dCS4wYZEpLQ4Ac8mcADNGSKQpt4Mu7pa58IgD0quTLBh658VMsHahsc5AdxPKTG0mp8tMwJQg9tFUliMuSKn8p2RIpez2dVGC+akdcGVoq1rTTGUpVwsEq7pohCFbIyVUoFdcc4FVJdMjVGVbgaLMJ1gr/mhI3EgBCCxNJrCDp4YgDsEISTNACiATc+J0SJiZo/RcIJAhihCdVRAIBsUDNAUEkVXhihCAk6G15dCDA0AgjCcAq+Up7JMBIIzCovjpbG1wwhNSzB8/VMENcwPPuDLkxi98eJKLCEjck7iDiNyyhQiKqBjoL0lpjgMqcvmDRJNkjXfUBFjOjicqRwX6QM1C4YEt+Z1IFIWVTVBxrYgbvs9QKifOjEYqkRZhOoQcJslvJLBiDPIJIZnlA2QMSikOCrrEkF2NroK1KkAugkAJgn7kEUHKhhgAWDABq6OBPWvUXAv3kEXLToEik8gigWGEtGAAdSihgwgYCgAI/mQP7/45CiNHEUIZqkcr9VkIIo0CQJcBComeo85NZgGQQLZFExaQorCQwaiWD4MgFfnKHHnKRIQC4w08usJAlpqQKZjwjRwDQHJaQ5iAgIKBKWhBHOc6xBcrSHTdAkD2VEKGPfpwjEVriAd2xhyVLQGQi57iE8gzECC0BhCQnOUdAtMQIAoFASwzHye4oriUQ4AYMWoKJTZYyMn1bCQx80JI1uPKVVllDS3yQHZZcCJc0sttKKge6PdwSmAgBQALnIBBPtIQWx0SmA2nREk8IBAQJJED0pLmtIshGdatkSSOjCUwAELIlMCiIz1hyhkhxc4oz0CH3CoICt62Ej+98FiDZef+ohLiMJTsj5xndkr6VDKEhLzgJS1KWz7W0rCWBeIFHemnHIzZ0em5MSeVCcoQvqsQDCrpoSB5USKccASkd+F580CJSNG4APy1BBZvAUgJ7KhAEAg2WOZ+4kjN8pS8/0CEBPNA0kQKgBCVNyRx+4JkMJOZqJSynGiy4EkgYcDVIUOgLccpFc9YQKJyYoHdI8NSfSIBZOYWMVF4AU6BAAoQN+gFVWxILH+mUOkZrCimYaqoVqEKoLKHCHdCS1mS65Q79C6IqLrOyI2SUK3OgghWIgNOrJPEqICCCFagAWPid9IwvyENBhUdaNPkiDxJt6SDdAAfslRZNzYODGwSpWo//YE5znPNcZ1UiOtKZDnW0rS1HQMBa176WK7GdrXAJ8qY4Hbe0d8pTPkM72udaNyWnTW0i+RY8wAmOcIZLnHgX17jHRW52lEOiYwN1BslSVlKXlUpmN2tTNOHis0PDUtia0qUvWVZYUiGTmeakppnyy6+7TYlgCduvwyYWQYt1Ftvqa6G4FRY0UqnblvAWXA3JlSt1teiT8MqVvc4oSVxhkogRBaXHroRKDCJrU866Ymetta2Vgat3wBYUUWRwd2ZDW0syobboZDUoj+CqFL0alECIFTc6EpVd/SikpKbESLZxqgejiksUzjUlVk2N1ViCtQsziGtAMUNngsqjol70/6hW5hJf++IioMxKtTW6UV1qWkUlC3enP/HpWpSmLjcvdyBHBZ5KqFaVlJqVpYfe0Et/ItOkhGhEZuYXilR0VY56NCUgzfQJP2BlSeAXJOtkCdBE7TBU5ZUl85yoEVl9MSX+ZKMdqVBLfhlpkHDIQx1JKMpo/bSHsiSiDZEZzYg9NKkkdmcM+edKAtprSil7oQs5UKxCWm1KQUhCCalnS/DZ7SDts6f9NNmwy701aasEZgZJtUrayWwfxrMlsRYIf1biH3ZTZUAFIkg4VzJOf2/tnCxJJ8c8Vm8kAmBkLCnZNbO5TYNvzZsu0Rt8WCIfiwsIxynRDzecyRJoevzf1P9kiTUlRrGGLzljLNkYN4rp8q4ukxvkYYl5Ti6gR65EAxRVCa95jpRfs2QiLWEY0bcGMSjSkiW2XHrRdckSXmqn5kses0YHrpJWSj1IsVQJDATGElFg3eFCTslGRMkSUn59pCtApUDquJIovp01ClvJdbiBSZZo8u6+9iRLQMkNfLFEX4BnzXlXAlefqySSiaekJQcCHJYIJ/KR2bdKljMQhK/kkJjPzSLFKUh3BfbslsNZS+xVkDyOG/XNPrdKWhHc2LiENqHf0G5a4huEPBaOuXcg3VVyR4SEqyXkCr6+0sWSdS1kjC0pY+7TuMaGmKYlqIl8a1ryGo5gkSVahL3/jb3YkjB6JOwqwdbdueWtkPBUJXYnOhVbYkWRuHgzSw/NaIg4a4/buiVNhBTJ4j/MYnDQokcqQS1UkUM/wUPs9kNBNERJgRg/sRji1y+TURmMpRYu1BIwdIEC9FUtcUN90StBFH8NNSw/YSyPIUI/QUIguC0pBBQsBBl3kRdZg0yBMRg/URiqUUEj9GOJZDYqdDU6phqvEjp3NlC3Alh7UGTEgUBBsUAxKCAZ8H6082TSMRZlcRZVOENvoWgrMRcAwj9N8T81ZipSIQUIGFidBiCg0hSjEjRfuCGoIgRxplQ1OCPusyXxk4b1UT8uthL5UytLsSVPERWA+B1SkRWfhlYZP2Uu3gM+4vNfxWE+6DMn62MzivKIQeEokAJfjlEpl5JNQLEpbzg0ysM8zrMERSA9GHY4RWA9xqU9+SZDJaFVwvMSMTETNXETObETPfFaQ/Ehr9Q7v3Ndz0U8xqNaffInykgnhGIoFtc6rxM71lU7t5M7ykcQDxERE1ERF2ECGbERDhMQACH5BAUEANwALAgACAC4ALgAQAj/ALkJHEiwoMGDCBMqXMhQYQcUKD58gNihocWLGDNq3MhRYYYugR6IHEmypMmTIytxO5Mr1xlulVDKnEkyUJcMHXPq3EkQgyiaI1vpCAEAAM+jC4uG0NEKqEhRGJBKvbhkGk1GI4xO3cqVG4ARjGhOW9KVo4xXMp+p0Vq2rVuEANQ8k/lKxluBGPighMSB7d2/gBMC4AAJJZ+oRw3EPGnCb+DHkJOaQFnJgEYRIU22AhG5s2eMIJqaDCSCIVqTbBx/Xs0aLpuTrw6O0GsSiOrWuHMLBADkJJ8RA/2cbHZbt3HcAJqd9MOtw8lKxY9LXw1gccmKKDlP344bBEqBSE6O/4rOvfxbAKNOIiEY6SQW8ubjIwWA5WQkhM5OBqoov7/UDpmV5ExDXaDkBHz+JWgQAE6g1AVHY6AkRmkKVkiQCGKgNMZU9aE0BIIWfgbAEDJhEdgRVqF0BgwghigVADCcIdM0Rxx3xGkyiRJEiy4uGMRPM71SY48ddEEbUNw8QkNR3BVFwyPcOPUAH13w1+NOIkjRg5RcduklST1IQeGVq2GgQi3YfKmmTNjUogJiZL51whjWSbnHIDicUBSPOu15Ag6D7OFlJWOcEOdBeSgDlBk88OkfADyYAZQyecSHhqIywcHkoUcVBcdMykjh2QWYmoRMY5x2BoAJyKCkzAVlof+CkihZpSrdV0CahIpOJKRp0itj2tqfCDiShA0JF6mC0pLC9ggADSipkhAKvpaEg6PNlgcADidhg0JBEZx0YLbCMnhSBAOFa5IJ5JI7mUnofnBSLti22x8AuZz0ATeLnNRCvfZq28JJiww0wUm8ABzwrbycNIFBtZw0iMILtwbAICfVopAGKD1CccWPAfAIShpgROJJmoJ8HACfnjTETkocWRIjH6vMEQBh+aZEW3nMyKLNL8KQ4kmVfmZDqS73BbRgHJzsqg39XSAjTcDAIULNugEgAhzAAHUGrO0awEa1XPJBDBZAXL3pi0WJAAQWxMgsJTZsWLa0Tih4gUgkcq//6RQfkSDixbd3fzYCEDpMEEHXfpsETAQT6AAEcIW/pYEqsjSuOZeyqFJy5Q2RMATZXSJTCy9OwNDBnms3xDoAHcDgBC+1tKomNkMgu7QSsnJJRQurYz0f7C1Q0SUqOwv7wZZAvRLF6lfCHkWxMvWwr4UyTEITHztcvbDWO/Rd0iR2lYeG+CNB0oTw0TdRmEx8iJrbErafNA2qoEs2tKlkdYaLTGdYS/42EpepnQQXf9kA81DGvvyxrHob6EqBUOKDBg6QIADwgUwedJQTeAAlO7DgBeGyA5R4wFAd6dVJgNGoEQYGUowrybE0koE6jYQUVnIhZDpAiufgxCILJAk3/0KgQ9YQ8SQ9YEgZUPKvIlpsYCcpQ0JUcJI9aMeJ3RGUSVRwEESchBgixGKfiHESRBREBxkLoxj7FDGT6GAg8jLJMXK4xtx04Bj6EoikTBIDNdYxJwCIwUnMIBACnOQGf5TODU5CAG6g4CRn8GMiOwIAA5IEIifxyiSNY5STfAsCJ0nCJnWThJNAQCATLMkaJDnKiwBgDSfhIDdiSBIYtJI1MFghQXpjqmDd8jEiqB9JgFAQL/gGhb8MzAnE54WDYAAlF2BlMndzAZTA6SCZMwkVpPlLABjPJLJoiBRQogNuThIAaDyJ/CyCsZNEwZxiBEAUUDIIjrxmkPB0IQD2iP+anTTINzuaJkYAEAT0OeE/uSoJN9YnUME0IUonEQUdpfIBS5ZECvkkFwDGqaLr3SUE2kPJM0iQUTIBgARzQckkiOgZHKDvAcjAaDylIMyS8AEHx8FBTRVawZJmLYMQRQkycBqfEPyPJmJojE8BUxQTZIgmuGBpiDaAhZeShBROAMFSdwIAEDihh0DhAxYiSC4nfJBLgWDDBbS6Va909QJsCJBTPHBQ0JFgEDb80jFG0Yw1xKAFJkjCDdj6uq7eIAkmaEEM1tCMUeCxcZUYhO42WQZnUG9zmH2FM6TY0I18AAl+6IIZFhEBCBhSJgSAQAQWYYYu+AEJHu1sVz4b2tH/lva0KEntalv72tjKliN525tVMTsSwAmOcL8tSGUvS9zGaZazv8xSEJtLXSSKqY53zauX9trXvwZ2sIUtCggOm9jFNvaxfovsZPMnNtL97Wxp29NW9uQ2uA23W3W7m1m7lNa1tg4y4oWrXIFC14UV6b4iSdKS2soQJ0FJSlSaKJmoimCsatVCXf3q38YaJ6kBpWreO5TWuOY1sFXIqEBJ6n9T1dSnziSq/rkRTXTE4MgQNKGwGRJ3dDoTbvS0cEXxQVBPMtTpHG0mQ1DaBQfjtJMoA2q5calMYlrjJtEUfkT9DIoA+LM/wsiiJKFRZ0CaFpK28qQpPclKH9MzlEyj/8vdFJpMivaWispEpp3dKAB9u5UOuazKLG5ySUzElQ7geCQLBbStAPDQWUk4JzFDCc2SC5ecmYQPyePJPy8dUErDpaAG4kmETjIhTzMEQxrSyT1NYgZFq2yfKGFDRwQ9kpSZ2iIPdNlG2mmSd956oPOUWEZSWZJx/Xqgmy6JLBnCUTe6GnToRMk6N9axZztwZCf5nEKyWZJtHhuQ3yxJOBWSn9E8+tsXAdBJBoSQZ54kmugGZDVPck2CtLEkE4t3n3hNEo0ZxJiXRqa+O7LMkzSzIO0xyXsG3ic/k+Q+uySyLxm+kWCehJgGQ5i149kwkzxsILQciS0pvpNcOm4g4f8xyXhIztX0mGQ93CD2SFbJ8j7B0iQc7JdJmlhzSkKxJAXjBihNIsqe56SUJjnlkElyRaNvxDuZfKRJNOn0my1dJBGZ18a9nC+TTASSW69jJT3pHJNAp+o3025FcEsSRKJdI4s0SSO5oa6SsOvtGXlXSdDFDX6SpI94d6UgWS0Q4ZiEOIHHtXJMwhxuxLEkc0x8Q+6YR4HUnSTGljxckj0SvgsknSWpRdiLCIB7k+SNA5nNxUc/Qt74hnID8aJJwKj5gwCAjCYxY0GodZJr1R6D3DKJtw5CRZNY8fcDAYEWS8JFhDA3NcgHwKpJEpuELNFfrL8bAH5eEugiRFknYVb/4p8VrYZMN8FSxfsRTZLEhmDmJJsJfGj0M/GE1PAkOHw7D32YERX+qv4URyzdsl4X4X8lwULZ1ywwNIAdoRgogT8MtyqUYTcEd1YmEUIRWEIncUJH0TsmQSsJ6CwjcGgisStSIXMkUUHHlkEbxBV5sRdKllyD8T6XVm9SoUCZEoLykWtIRFZtQSpCBYHJtCo7JRKvEhhHBUkCdEsFJBMIBBlnkRZLmEhxkWa/Uj6dQT8zIoROtCr7UxLI0D+sIQVIYxKaooNMxYNONm24IQVWpT5o2BaMRoO+wYbGURVXUStA8xWW5mZiWB7Zsz3dE4eUJALhQxPkUyGJsigtVC6RnjIpdBYiy+MUzgM9ztIB0+MU1pMqPiElQkEUIagUTCElUNEuvNMlvxM8P9UBxXM8mbYwc6JdM3EneSJfd+EngLJ8UkIoArc0ouNeUmI6qKM6rzNQrBM7s1M7a4I7BHhBHzFgxKUSLOESMFFdImETPzRJl8Nt1thcnaNtnWUmaNKNXNImb0Jxh5M4i0NdjxM5k4N8BvEQETERKHBuwhIQACH5BAUEANwALAgACAC4ALgAQAj/ALkJHEiwoMGDCBMqXMhw4IgkSFoYKcWLDZtQVaqEssirlJEWSJKMaEiypMmTKFOqFBhkkyEHMGPKnElzZrZXkxYNcfYoDxYdOrDkeeRsyKJJr7LVXMoUpqFNQVZKnUpVoBIxTWUu8NMBQNWvJQF08LMga0wxSsCqbViDU9ZPN7yunUt3IIAbn7JyqlEX5YZFTKMhkNu3sGGFABBEY7pow+EOWGuuukD4sOXLJAFcWLVUTIevVJZKqIy5tGmTACQspYLS01I/pE/Lnp3Zz1JPC+HUjPaBtu/fKD8spgnH4JOaxWIDX878IIBiNZ8M/FXTRPPr2BGaqPmLG5uaj7KL/x/P7VFNNrxqOlNOvv1pAM5q8uIGqaYf9/hp26YJaeCXmgyAkN+AloHAQE1fGEQDLDVlwR6BEKYEQBY1wULDQjK8RNMCD0boIUIAlEWTITKgBIWGNOnR4Yf5AaDHUoZAAZYSB9Z0Sm8suvfBKUsxkJZlJyTTFAUr5lgXABQ0lcwJ190gZFPA+FCkkYj5AExWydxgZAdTMGMWTHOoEMKUywEQggpzfOkAM1N8RuVUMnhCnZp01mnnTL94UuKbtNEARwQo3iloU4ZEAMeFfBY2wxOBmhVNBBS8AACZc036AgURDKemIU/MkGhBToBilgQfUPohAB+olhUoTrh3BY9MUf/B5KdznRAaU6dcIRsKbi01gam0VjoBU5ygQBceTEkZLHkA+MAUHlIlsNQWwC5b5hZLJUCSDJrKNES11ooHwBC77WmQGTXpAm647gGgS01mEGRHTWesy26LZ9RkBzct1DSJvfe2OElNLVRRkw4BB6xDTVUgUdMrACfcHgCv1IQENyQs5anEtM6wFAkE9VvTCxy/+cJSLSRETE3chFByhC7XRExJ29G7wsvjrZBvdVNpshQwWuI82w1X1qRJXzCIulQpEQvtXBdMgQIDbTBU0tQopTq9EKqjNFXJ1PjB0GtToKiyQtPZAbCCKko3xQnY4UJxq526IPIDCJMeNikIPyD/8u6dVMiotUohtGDGHoMmHtMeZrTg8uCnFfHFE5DUqHhTDEDyxBdFQN4XCJ0Q0+3lpGcVDTGdCOi5QiVIKygDxQByxwyTos1N7TPcAUgxltuZQAlOK+GzmtwM4Ube4gLgxhDc0KnJj7SioM2XZ2yxge3AAbDBFjtnpY2xHp4AWFasjPmymayYtcis48EA61KnULY6QZq9byPcv90wdk1Mz98QAKVwW9BM44QhYc9pSGpKqw5jBKaMgn3+q8oJurYUI9BFCV6qyScOGMGCACAvNWEG9KZynJpI4nEdPEwIJLEU6azEdTRRBQdTyBAAqCJbKNnEUmwwQxpmxgZL2QRJ/zqxFBX00IeoUcFSOrGQgW3oiEhESYj8hZAQNAomRIpicxI4IhQKpAhL+YEWs/ODpXRuIL2LyR3GKJ47AGggmKgJIqDIxpUAABE1wQQ3klCTbNCxjnZUCk2SEECafAuQaSMXTUoRippgAZHiwUJNNlKTPEAyO3k4TwNpsog/XhI145uJEUZgxk8yB4w1GckNaRIHT5pya3GoiSoGUh+aAMKVr3QOIGrSH4IgjiZzzKVp7liTPRwkAjWJAC6FCQBk0iQCCYnBUtwgzMO4YSkxWAgI5jSTObipmmvpQJpo8gvVMSQIS8mEY8BZlQ1kYilROUkJlgIKHLEzJR9o20yAt/+SGVitJqxY5vwAkL6aVGJjVZkCU+AgUKEBQDdLmUJfprcac7ITBHOjiTYwU8KlDOaViWmKC2VTAwI0ZQIWRSIIhsUUAvClOVcwKVNWwVD/PZQzLdWVezbQUaZIQkUccxELs/KEdbLICGlMJw8bupZJ2eCdZmGABdmFh3+qaQFZKBVTQYSqLIhITZWAFuRMAMNBnSEOiPCDCYpQu9pxta1FMIEfEBGH7g0qAdYBpAxiMAkGle6vMoHFJGJgrnsqhAR2UAUmIMFNQf0CEphQhR1AZtivIFaxjFXcYyM72cqepHCHA6ydGOc4z3Jjr30VrWgFS1hTxqmxqo0tnvSkRbL/Xu6saV1rW5FnkN0CIK5zrevl8Oo/uQmqbnfjbV/21re/2SlwTqtqnbCqVeZM6gNerVNYE8alDJolTOZr0ZnGaRY2ffNTSP1SJpZqJKdCNStS5ZPYzFK2sy1LbWwzy9s+xFOzSMILW5WNUM1S1AE5KStRCnD2rISlAYonpk2hqYKxc9OmEECn16na1bKWQq55DX++KelJU+rDlVr4pbMJkgEhycWlLEk2PaXJR00ZUqaM1DJJY0r/qgkAqNETxHWhaE2oQGJhYpQpG+0LjeBnT8/uqEcjBItCl1JT09oFojWRqFqGRxOgWfkgRFvK0ariz6UE9MsgKihNDjqVEy0F/8BoToiLYCS4lMyzJvWMM0PyuRR+nqRmNDnDzfTMEJ0tJa8lQWdN1ElokrgTniXJUE041OiwfFUmJGrINmvizUqbRJzcKXJBVkaTlnn6s82jycwUIs2aUPPUJ7lmTbKJkAU1aMJsnFCFEGUQZ85EmbCWkK9lAk2DiIwmJAt2Sk5GMIP8cibBVLYU8UgTYxLkPzQJkLRVYiAEEaSWM7nltiW0S/4MJGM1Qei4T+KxmlB2lTNp5bolFMsYCgTcMrnPvFOyn5n0h5Q1OeO+T4JKmozAYTSB2MClWDGaIGGTM+nkwk8CgFDKxAjpocl6Jo6a+NCkIpXk+EkySRM2GIwmCP8TeUkWRhONOFLlJZEkTShJk/DAvCHmKXkhZ3LImyNGkTMpxbFl8i+fI8aJM2kBH2niR6PLWZAzSQI3YAsTRDu9IICWSXe4EUdg4prG1J6JHrkxr0B//ZMAsGtM9iWQpDpgjVcniBuzTZAYwyQ5cRfIc6JDkILPRIx5L2PAC4Iumqgr7u6Cl0GsWJMsGr3FmPbiQLAsE944XTg1KQ5CkK6Vs0dxijSZhEK4VZOei3xckinsQYhYEyOeXok1YSJDXGMfz9u03zPBDUl0WBMeDhwAQKyJEE1SVplQa94AwFZNtIWS4sdEhuO2IQ5VklGZjEbaqVkNCZdywmCvsIVVQdb/UpTV6GY9a0benckGCf3BpYgwnJGhyWRsHyzN4JQmnqkLxGnyQNNOkClT1Re8whS/ck8AwFI1USyXUUBM4XgglSRMsUCY8ReBMWMsphiMYVSmoT9N0QX0NzE+thSc4GCz8SpNIStaZCtNkSsZZj80ET8f+Bv1s4JAxhxt8RZxATl3AULEgmLkIT5mUT4xWBjooz4QlB+hMiocFi6ooipkI4EfIj3UYz1DKCHbo3ZL8T2fchVXxRVViBhjcWlNgRbsIjx0UjzHU4WTsjyp9iXPUzKLckVN8SiRolylYSmYMjpZwSnqJjStMyiwIzu0Y4d2NCm5sztu9yW/Q0MtIYeCTHITObETPfETQTEURXEUSfFXTxFPbAQ6oiNbsrUKqCNqkOQngAKKd1Ioh9JokkM5ifhXmbM5AjdxDxERE1ERF5ERG4EeHgESIsEuAQEAIfkEBQQA3AAsCAAIALgAuABACP8AuQkcSLCgwYMIEypcyJBbBjc2Sq2p4mjUK0nAKjFjVgmYpFejHFVZU8qGmwwNU6pcybKlS5c3ED0YQLOmzZs4bRp6lcDMoxhvmLQpcYQEiSMl2jB5E+ORmQSvDOWcSnXAA0Q3XmrdypXghjG7qtZcRYgHgK5oXQLgQWiVWJq7xmxISzdlDLHU6pyty7cvQgB1qImN4delC1BUCdAozLgxSxoEqIJy4ZhbmbA5OYWozLmzyxycpu4qg/aG1JxOPKtevdXJVENZV4bGyY0H69u4tdrOvFBazlZ7cwsfvhJAq5zSDJ7JOYW48+cqp+Q8I9BNTkPBoWvfXhDA6ZtuJOX/bMO9vHlubXJ+zMnkvHvoTHK+yjAV5fv7uOnntG8rp6Ps+AXIGACO5GSLQXlMBYWADPIFxVR5LHTJVIQ0aKFLhEx1SUs7TIVNCheGWFAK2Ey1A11jUPUJgCJyB8AnVI3R2RINUGWNEi3ipoQ1VDWwhHZR1FjVIiDmuFUKi4jVQBQtlpHJWzRxs4kLLLoHgAubcAPlAJmQZqRWK1wy25ZklmkmTpxcssKXt/GQhzSunCknma5Ik4dtbBYmRWRltrJDE1WuBkATOxxXJgFS5DlQBhG8hY0TgSoKgBMlihWBfeal2OMWkSqqFQBbCDmVjKzZ0WMang6Xhqg42eFXLFNZ/1NkqualwGNOsWh1gwM5cfMBrRf+mpMDsS0UxlSuAvulqTmFgRAfORWiLK2F5MQHQYrkRMm001KSkyLcVJHTI9xy+0hOVTCTEwnlTktCTsyskZMZ7SprRk5rcKNCTrp0Wq+FAOiSkwoE9YdTLv7+ex8AuRiI0AzR5IRKwgprBwAqOUUzQ0qsTEUJxRWzBoC3ObGyVRKs2rQIyCH3BUCSOTWQRGF9SAZDy37BgNhUfeRWbVUFsFwxAAWIJe17INT8VjIlCM0gACUkA2UfIAA7wg7fkZlLIWmA4DRXAICQRiENm2nIDiPg7FIKNtgC7Zxw28SHLTbMqnZnLuhgy3Jxk/95hi06UHa3Xz9gEnHfiJcZDSY/DK7QDWu4deY1jkyBhAhfpwSACEhM4cg1cq6yRrH1djBGylQJg4odHdzXgR2oCLNlA2O0rqgdoIvlCiUfZH4eAB9QEqdY1yTb4BI728iE7y0CwMStkv143s8qbuZ4QTnAWNXRxEVRVSU3X58SDJVUxeRqIDQ6VSU4iq+VEuVPFUHVjW0g9VRBu08X0VQlMxdfmspJHfTXmDrECC0j4BNOFME8AhYnWzkhQNpcUgTJ3cQVJXAga0owvJusoggrWcFMcLIK0mlwNTewoE0esCaGYCInwhDcCYXjAtnhBBMK4UEHbdKzGT5HaRfEU0H/bDCVJvhQO02Yig0KooOcXIN+R4QOCHJ3Ex0MhAsxE0EUuSMC1A2ACwLJWk2kt8XtLOE63ChFThJQRvMkICelGEVO3tDG8rwhJ6OI302OUEfuHCEnHclJBvuonRLkBBgFwglhCAmdu+DEEUTEySsayMj9vSInS5RFTrBQSeJgISeyEIh+cIKETuYGCfUZiAumgipTriYNU5GhQFKww5qcyJWd6RBOXGE3gkzCWrbDZWE68LabTGIhP5jKJigpTIMAYBNTaVxDEDGVNTCzmQCQV04Q0RJt4iQZ1+wkAO6Hk3xpRQpUaU8zVRKfqSQKLR14Uk6oIct1FsQFgslJJoJZ/5caUBEnnLInqKhyjRpwJgMKxIk1FtNJGkAPJwTA1GocORVQpCGc0wJAGpKXk0U+J4BT4UQ9B+eCMY3qPi5I6FQU0UtupQCCVSHASAVUA3JWhRujYxPktLQ0g9IqCbAiEx/6AAWM7g8KfSgmlGIxM5wVgRW8mlMDdEEJLCwhAwDwXVYzsAQsUEIXXtySA1gBwijOIAyTqGXi1koTV0wiDBuz50EywAUVKEIWYoSbIWShCBVwQaJyZQld7YrXte61r38NLEPY5ja2ymludbPnWdPq2MoOwK1w7WOYTGrZzt4kTS104FOjKqepVvWqWX3JVrv61bBCaaxlvdvV8vqWrf91zagMCdvYylams03wX0At01CL6iKkKvUtTOWWk7YkJSo9DUs8fUuXPFVTKOHUhCLaKZSS4VMRJW27TQMW1GxKFapZKKVvYanCXvoWmQYoSGIh0t2QpKTzZUosItVfScVCKu1QD3+4zRP/tvcciubEogFOlUY5qkjh0MhG7avjjnpERs8g1EYMraRDEwPYxgARJ6AIHy51Vt7K+JMqAV3nQKdSUMaA9CYrUiw3XnRAvsRzKvSUMUHwOZV90gVlU1mZjrsDM5zIDC3onIo6h2yQdubknVrRJU4+xOSEkMhEWvHmTcBZZYWMs5ou6Zi2EtzHkU3FZCuhJr7ITMhsToX/mymZUE4q1OWVZCgnG2JIMnOyzDoXB5o5kWZCICYxNrvyYhmLK0J+iRM+8NPPKiFmTo6JkATlZEGQdsmDchIhg9AyJ7fMtEukbBNeGsRgN0GYqFXLW5scaMesXLVWYJkTWaLaJv+RtWoTeZNXO2QqpdT1S1C5H4HsCyf9ErZqBYYTgnFDkzjhpLJf8kmchHKUN+nwtFOCbZtkIJI3meS21XJJnNhAyzWh17hdcq9y8tomHl33SgxcE0eU+yZLljc75QMMQeqbJYbECTDUhRN2/Vsl78IJR3LCx4On5I84qYR4cEIehzckPTiRhBxxQkeLM+SOOBmFuHBCLo8v5Fw4/6mCGnHCRpMr5I04KYV1cIIdl/+Ftm7gBm0rbPOBnJHmAoGpTbbV84KQ7Cbg4gYWjazFogukizkBo0D4dpPmOJ0b0sEJdQbSRJw80elTzIkVCXJcmnDP5v+tybWGWMSeJxGTB/ENToDjcuMgByE6zEkPPf7hmrhCiAY5Vk6Md3Bm4cRZCnkhTmLo8BrmBIcM4WyUAD/u3aApJSLMSQnlncKcsFAlu+rVr7YtLJwQiyUVzAkGp81Bzcd2JaaZSmp07ZrrYFclCVypoU8IAKHbRIJdCapCWzpkW00lV2l5sU0G2GUDnrQulwlpDoYMGtF4iS/2o0r+5DrgnPivMYY3cv8rm7kqqhCeMemjCvtwCT+qzE81h0lMhvsIGcnMlDPeU7+It0g+8xFH+TbRACnGe6FSFf3lHGmHE58wfQSUPUZjHvSGE3mxe/gBGPlEFfFmHsgjFtawPCHjPA91YDz3HoziKJBSLpNSKVVxKSKCO2+xO70jKcGjVl53fiLyFZghFmRhFiGyFm0BJXHxP55iOq51E6rDOq4DOzb0FrTzaMqyJ2biJ4BCHINSKGaCKGoDOSpEJpRjOZhTGJvTOZ8TOjnlPjExQn2zEz3xE0ExFEVxFEmxFE3xFFGROFdxew5UOIfjWZa1OIJWSW4CJ3woJ3VyJ0yWN3sziDbxN4Ejbw8WERETUREXkREb0REfERIjURInQSsBAQA7");
    std::string pageData = std::string("<html><head><body style=\"margin: 0; padding: 0\"><img src=\"data:image/jpeg;base64,") + LogoBase64 + std::string("\" width=\"") + std::string("120dp") + std::string("\" height=\"") + std::string("120dp") + std::string("\"</body></html>");

    jobject webView = WebView.WebView(env,ctx);
    LinearLayout.setLayoutParams(env,webView, LinearLayout.LayoutParams(env,ConvertDP(env,ctx,130),ConvertDP(env,ctx,130)));
    WebView.loadData(env,webView,pageData.c_str(),"text/html","utf-8");

    jobject textAcima = TextView.TextView(env,ctx);
    TextView.setLayoutParams(env,textAcima,LinearLayout.LayoutParams(env,LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
    TextView.setText(env,textAcima, OBFUSCATE("Aviso"));
    TextView.setTextSize(env,textAcima, TypedValue.COMPLEX_UNIT_SP, 18.0f);
    TextView.setTextColor(env,textAcima, Color.GRAY);
    TextView.setTypeface(env,textAcima,TypeFace.BOLD);

    jobject params = LinearLayout.LayoutParams(env,LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
    ViewGroup.setMargins(env,params,ConvertDP(env,ctx,0),ConvertDP(env,ctx,10),ConvertDP(env,ctx,0),ConvertDP(env,ctx,40));
    jobject textAbaixo = TextView.TextView(env,ctx);
    TextView.setLayoutParams(env,textAbaixo, params);
    TextView.setText(env,textAbaixo, msg);
    TextView.setTextColor(env,textAbaixo, Color.GRAY);
    TextView.setTextSize(env,textAbaixo, TypedValue.COMPLEX_UNIT_SP, 14.0f);

    OnClickListener.setOnClickListener(ctx,LinearMsg,99);

    AlertDialog.setView(env,dialog,LinearMsg);
    ViewGroup.addView2(env,LinearMsg,webView);
    ViewGroup.addView2(env,LinearMsg,textAcima);
    ViewGroup.addView2(env,LinearMsg,textAbaixo);

    Dialog.setCancelable(env,dialog,false);
    Dialog.show(env,dialog);
}

jbyteArray loaderDecrypt(JNIEnv* env, jbyteArray srcdata) {
    jbyteArray keyData = env->NewByteArray(16);

    jbyte* keyDataElements = env->GetByteArrayElements(keyData, nullptr);
    const char* keyString = "22P9ULFDKPJ70G46";
    for (int i = 0; i < 16; i++) {
        keyDataElements[i] = (jbyte)keyString[i];
    }
    env->ReleaseByteArrayElements(keyData, keyDataElements, 0);

    jclass secretKeySpecClass = env->FindClass("javax/crypto/spec/SecretKeySpec");
    jmethodID secretKeySpecConstructor = env->GetMethodID(secretKeySpecClass, "<init>", "([BLjava/lang/String;)V");
    jobject secretKey = env->NewObject(secretKeySpecClass, secretKeySpecConstructor, keyData, env->NewStringUTF("AES"));

    jclass cipherClass = env->FindClass("javax/crypto/Cipher");
    jmethodID getInstanceMethod = env->GetStaticMethodID(cipherClass, "getInstance", "(Ljava/lang/String;)Ljavax/crypto/Cipher;");
    jobject cipher = env->CallStaticObjectMethod(cipherClass, getInstanceMethod, env->NewStringUTF("AES/ECB/PKCS5Padding"));

    jmethodID initMethod = env->GetMethodID(cipherClass, "init", "(ILjava/security/Key;)V");
    env->CallVoidMethod(cipher, initMethod, jint(2), secretKey);

    jmethodID doFinalMethod = env->GetMethodID(cipherClass, "doFinal", "([B)[B");

    jobject result = env->CallObjectMethod(cipher, doFinalMethod, srcdata);
    jclass byteArrayClass = env->FindClass("[B");
    if (env->IsInstanceOf(result, byteArrayClass)) {
        jbyteArray byteArrayResult = static_cast<jbyteArray>(env->NewGlobalRef(result));
        return byteArrayResult;
    } else {
        return nullptr;
    }
}

jboolean IsVpnActive(jobject ctx) {
    if(Build.VERSION.SDK_INT() < Build.VERSION_CODES.LOLLIPOP) {
        return JNI_FALSE;
    }

    jboolean vpnInUse = JNI_FALSE;

    jobject connectivityManager = Context.getSystemService(ctx,Context.CONNECTIVITY_SERVICE);

    if (Build.VERSION.SDK_INT() >= Build.VERSION_CODES.M) {
        jobject activeNetwork = ConnectivityManager.getActiveNetwork(connectivityManager);
        jobject caps = ConnectivityManager.getNetworkCapabilities(connectivityManager,activeNetwork);

        return NetworkCapabilities.hasTransport(caps,NetworkCapabilities.TRANSPORT_VPN);
    }
}

jboolean isConnected(jobject ctx, bool isStatus) {
    if(!isStatus) {
        int *p = 0;
        *p = 0;
        return JNI_FALSE;
    }
    return isStatus;
}

void isIP() {
    char *hostIP = GetIPFromUrl(OBFUSCATE("https://infinityofc.net/"));
    std::string ip = (hostIP);

    //LOGI("IP : %s",hostIP);

    char *ip1 = OBFUSCATE("45.132.157.35");
    if (ip != ip1) {
        int *p = 0;
        *p = 0;
        return;
    }
}

size_t write_data(void *ptr, size_t size, size_t nmemb, std::string *data) {
    data->append((char*) ptr, size * nmemb);
    return size * nmemb;
}
