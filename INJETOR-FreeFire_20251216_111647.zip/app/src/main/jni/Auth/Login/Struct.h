struct {
    const char *USER = "USER";
    const char *PASS = "PASS";
    const char *UID = "UID";
    const char *PRODUCT = "PRODUCT";

    jobject Dialog;
    jbyteArray DecryptLoader;

    jobject PrincipalLayout, TableLayout2,TableLayout, LineView, FormLayout, UsuarioLayout, SenhaLayout, EntrarLayout; /**LinearLayout**/
    jobject TituloText, AvisoText;      /**TextView**/
    jobject UsuarioImagem, SenhaImagem; /**ImageView**/
    jobject UsuarioPNG, SenhaPNG;       /**Bitmap**/
    jobject UsuarioEdit, SenhaEdit;     /**EditText**/
    jobject EntrarButton;               /**Button**/
    jobject TableBackground, LineBackground, LogoEditBackground, EditBackground, EntrarButtonBackground; /**GradientDrawable**/
    jbyteArray DecodeUser, DecodeSenha; /**Decode Base64 Image**/
    bool isStatusFloating = true; // false

}Login;