#include <jni.h>
#include <string>
#include <sstream>

jbyteArray puk(JNIEnv *env) {
    jbyte a[] = {48, -127, -97, 48, 13, 6, 9, 42, -122, 72, -122, -9, 13, 1, 1, 1, 5, 0, 3, -127, -115, 0, 48, -127, -119, 2, -127, -127, 0, -41, 36, -11, -27, -61, 32, 124, 58, 39, -94, -13, 7, 48, -104, -109, 106, -75, -8, -128, -92, -89, -125, -49, -83, 75, 12, -26, 90, 56, 35, 52, -116, 30, 40, -69, -70, 86, 14, -80, -20, 55, -89, 104, -46, -17, -80, -119, 83, -14, 116, -66, 11, -108, 5, 76, 12, -43, -89, -49, 11, 38, -124, 71, 45, 65, -103, 10, 99, 33, 79, 21, -16, -38, -60, 24, -108, 101, -89, -18, 48, -37, -78, 59, 10, 89, 42, 51, -43, 9, -33, -68, 61, -45, 94, -49, 83, 52, 56, 105, -123, 18, 89, 3, 54, -48, -63, -61, -103, -9, 79, -36, 18, 119, 11, -35, 82, 73, -66, 12, 123, -38, 97, 121, -30, 31, -50, -106, 127, 2, 3, 1, 0, 1};
    jbyteArray ret = env->NewByteArray(162);
    env->SetByteArrayRegion (ret, 0, 162, a);
    return ret;
}

static void TrySetupLoader(JNIEnv *env, jobject ctx, jstring DexPath, jbyteArray dexdata) {
    // Clear any pending exceptions
    env->ExceptionClear();
    
    jobject fo = FileOutputStream.FileOutputStream(env,DexPath);
    
    // Check for exception
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return;
    }
    
    FileOutputStream.write(env,fo,dexdata);
    OutputStream.flush(env,fo);
    FileOutputStream.close(env,fo);

    jobject dexLoader = BaseDexClassLoader.BaseDexClassLoader(env,DexPath,Context.getCacheDir(env,ctx),nativeLibraryDir(env,ctx).c_str(),Context.getClassLoader(env,ctx));
    
    // Check for exception
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return;
    }
    
    jobject tmpClass = ClassLoader.loadClass(env,dexLoader,"com.brmods.loader.Loader");
    
    // Check for exception (ClassNotFoundException)
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return;
    }

    Java.LoadBaseDex(env,tmpClass);
}

static void Setup(JNIEnv *env, jobject ctx, jbyteArray dexdata) {
    env->ExceptionClear();
    
    std::string CachePackage = String.valueOf(env,Context.getCacheDir(env,ctx)) + "/CacheLoader";
    jstring DexPatch = env->NewStringUTF(CachePackage.c_str());
    TrySetupLoader(env,ctx,DexPatch,dexdata);
}

void onPreExecute(JNIEnv *env, jobject ctx) {
    env->ExceptionClear();
    
    Login.Dialog = ProgressDialog.ProgressDialog(env,ctx,AlertDialog.THEME_HOLO_LIGHT);
    
    // Check for exception
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        Login.Dialog = nullptr;
        return;
    }
    
    Dialog.setCancelable(env,Login.Dialog,false);
    ProgressDialog.setMessage(env,Login.Dialog,"Autenticando sua conexão..");
    Dialog.show(env,Login.Dialog);
}

jstring doInBackground(JNIEnv *env, jobject ctx) {
    jstring username = JSONObject.getText(env,Login.UsuarioEdit);
    jstring password = JSONObject.getText(env,Login.SenhaEdit);
    
    // Clear any pending exceptions at start
    env->ExceptionClear();
    
    // Check if username/password are valid
    if (username == nullptr || password == nullptr) {
        return env->NewStringUTF("No internet connection");
    }
    
    try {
        jobject token = JSONObject.JSONObject(env);
        jobject data = JSONObject.JSONObject(env);

        JSONObject.put(env,data,"app_Us",username);
        JSONObject.put(env,data,"app_Pa",password);
        JSONObject.put(env,data,"app_Version",env->NewStringUTF("v1"));
        JSONObject.put(env,data,"app_ID", getUniqueId(env,ctx));
        JSONObject.put(env,data,"app_To",env->NewStringUTF(""));

        JSONObject.put(env,token,"Data", Utils.encrypt(env,JSONObject.toString(env,data),puk(env)));
        JSONObject.put(env,token,"Hash", Utils.SHA256(env,JSONObject.toString(env,data)));

        const char* url = "https://www.hgcheats.myvippanel.fun/api/loginMod.php";
        jobject urlConnection = URL.openConnection(env,URL.HttpURLConnection(env,url));
        
        // Check for exception during URL creation
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return env->NewStringUTF("No internet connection");
        }
        
        HttpURLConnection.setRequestMethod(env,urlConnection,"POST");
        HttpURLConnection.setDoOutput(env,urlConnection,true);
        HttpURLConnection.setRequestProperty(env,urlConnection,"Content-Type","application/x-www-form-urlencoded");
        HttpURLConnection.setRequestProperty(env,urlConnection,"User-Agent",
            "BADOFTRUE/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T)/537.36 (KHTML, like Bad)");
        
        // Set timeouts to prevent hanging
        HttpURLConnection.setConnectTimeout(env,urlConnection,15000);
        HttpURLConnection.setReadTimeout(env,urlConnection,15000);

        std::stringstream txt;
        txt << "token=";
        jstring tokenString = JSONObject.toString(env,token);
        jstring tokenBase64 = toBase64(env,tokenString);
        const char* tokenChars = env->GetStringUTFChars(tokenBase64, nullptr);
        txt << tokenChars;
        env->ReleaseStringUTFChars(tokenBase64, tokenChars);
        
        std::string zax = txt.str();
        jstring postParameters = env->NewStringUTF(zax.c_str());

        HttpURLConnection.setFixedLengthStreamingMode(env,urlConnection,String.length(env,postParameters));
        
        // Check for exception before getting output stream
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return env->NewStringUTF("No internet connection");
        }
        
        jobject out = PrintWriter.PrintWriter(env,URLConnection.getOutputStream(env,urlConnection));
        
        // Check for exception after getting output stream
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return env->NewStringUTF("No internet connection");
        }
        
        PrintWriter.print(env,out,postParameters);
        PrintWriter.close(env,out);

        // Check for exception before getting input stream
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return env->NewStringUTF("No internet connection");
        }
        
        jobject inputStream = HttpURLConnection.getInputStream(env,urlConnection);
        
        // Check for exception after getting input stream (FileNotFoundException)
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return env->NewStringUTF("No internet connection");
        }
        
        jstring response = Utils.readStream(env,inputStream);
        
        // Clear any pending exceptions before returning
        env->ExceptionClear();
        
        return fromBase64String(env,response);
        
    } catch (const std::exception& e) {
        // Clear exception before returning
        env->ExceptionClear();
        return env->NewStringUTF("No internet connection");
    }
}

void mostrarAlerta(JNIEnv *env, jobject activity, jstring mensagem) {
    if (mensagem == nullptr) return;
    
    env->ExceptionClear();
    
    const char *mensagemStr = env->GetStringUTFChars(mensagem, NULL);

    jclass activityClass = env->GetObjectClass(activity);
    
    // Check for exception
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        env->ReleaseStringUTFChars(mensagem, mensagemStr);
        return;
    }
    
    jmethodID mostrarAlertaMethodID = env->GetMethodID(activityClass, "loginSucesso", "(Ljava/lang/String;)V");
    
    // Check for exception
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        env->ReleaseStringUTFChars(mensagem, mensagemStr);
        return;
    }
    
    env->CallVoidMethod(activity, mostrarAlertaMethodID, mensagem);
    
    // Check for exception
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
    }

    env->ReleaseStringUTFChars(mensagem, mensagemStr);
}

void onPostExecute(JNIEnv *env, jobject activity, jstring s) {
    if (activity == nullptr) {
        return;
    }
    
    // Clear any pending exceptions at start
    env->ExceptionClear();
    
    if(Login.Dialog != nullptr) {
        Dialog.dismiss(env,Login.Dialog);
    }
    
    if(s == nullptr) {
        CustomToast(env,"404 : Erro desconhecido",activity);
        return;
    }
    
    // Check if string is empty
    if(String.isEmpty(env,s)) {
        CustomToast(env,"404 : Erro desconhecido",activity);
        return;
    }
    
    if(String.equals(env,s,"No internet connection")) {
        CustomToast(env,"Sem acesso a internet", activity);
        return;
    } 
    
    try {
        jobject ack = JSONObject.JSONObject(env,s);
        
        // Check for exception after JSON parsing
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            CustomToast(env,"Dados do servidor inválidos",activity);
            return;
        }

        jstring Dados = Object.toString(env,JSONObject.get(env,ack,"Data"));
        jstring Hash = Object.toString(env,JSONObject.get(env,ack,"Hash"));
        jstring Sign = Object.toString(env,JSONObject.get(env,ack,"Sign"));

        // Check for null values
        if(Dados == nullptr || Hash == nullptr || Sign == nullptr) {
            CustomToast(env,"Resposta do servidor incompleta",activity);
            return;
        }

        jstring decdata = Utils.profileDecrypt(env,Dados,Hash);
        
        // Check for exception after decryption
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            CustomToast(env,"Erro ao decriptar dados",activity);
            return;
        }

        if(!Utils.verifysignature(env,decdata,Sign,puk(env))) {
            CustomToast(env,"Os dados de login estão errados!...",activity);
            return;
        }
        
        jobject data = JSONObject.JSONObject(env,decdata);
        
        // Check for exception after JSON parsing
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            CustomToast(env,"Dados do login inválidos",activity);
            return;
        }

        if(String.equals(env,Object.toString(env,JSONObject.get(env,data,"Status")),"Success")) {
            CustomToast(env,"Conectado, Bem-vindo - divirta-se!",activity);

            jstring messageString = Object.toString(env, JSONObject.get(env, data, "MessageString"));
            
            // Check for null message
            if(messageString != nullptr) {
                mostrarAlerta(env, activity, messageString);
            }

            jstring loaderBase64 = Object.toString(env,JSONObject.get(env,data,"Loader"));
            
            // Check if loader exists
            if(loaderBase64 == nullptr || String.isEmpty(env,loaderBase64)) {
                CustomToast(env,"Erro: Loader não recebido do servidor",activity);
                return;
            }
            
            jbyteArray bdata = Utils.fromBase64(env, loaderBase64);
            
            // Check for exception after base64 decoding
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                CustomToast(env,"Erro no formato do loader",activity);
                return;
            }
            
            Login.DecryptLoader = loaderDecrypt(env,bdata);
            
            // Check if decryption succeeded
            if(Login.DecryptLoader == nullptr) {
                CustomToast(env,"Erro ao decriptar loader",activity);
                return;
            }
            
            Setup(env,activity,Login.DecryptLoader);
            
            // Check for exception after setup
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                CustomToast(env,"Erro ao configurar loader",activity);
                return;
            }
            
            ContextWrapper.startService(env,activity,Intent.Intent(env,activity,env->FindClass("com/lskhjfgd/jklsfdg/Floater")));
        } else {
            jstring errorMsg = Object.toString(env,JSONObject.get(env,data,"MessageString"));
            if(errorMsg != nullptr) {
                const char* errorChars = env->GetStringUTFChars(errorMsg,nullptr);
                CustomToast(env,errorChars,activity);
                env->ReleaseStringUTFChars(errorMsg, errorChars);
            } else {
                CustomToast(env,"Login falhou",activity);
            }
        }
    } catch (const std::exception& e) {
        env->ExceptionClear();
        CustomToast(env,"Os dados de login estão errados!...",activity);
    }
}