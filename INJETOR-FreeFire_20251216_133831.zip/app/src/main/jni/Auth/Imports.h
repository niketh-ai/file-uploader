#include <jni.h>
#include <sstream>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>

#include "Utils/obfuscate.h"
#include "Utils/RGB.h"
#include "Utils/Logger.h"
#include "Utils/Request.h"
#include "Utils/SdkCall.h"

#include "Login/Struct.h"
#include "Login/Login.h"
#include "Login/Auth.h"

