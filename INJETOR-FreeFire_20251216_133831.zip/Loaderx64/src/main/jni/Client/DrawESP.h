bool isValidPlayer(PlayerData data){
    return (data.LocationHead != Vector3::Zero());
}

void DrawESP(class Canvas *m_Canvas, int screenWidth, int screenHeight)
{
    Funcoes funcoes = {
            pAIM.AimbotAim,
            pAIM.AimbotShot,
            pAIM.AimFov,
    };

    if(!strcmp(Logger.paramsSTS, Logger.SucessoEnd))
    {
        float linesize = 1.0f;

        Response response = getData(screenWidth, screenHeight, funcoes);
        if (response.Success) {

            int count = response.PlayerCount;
            if (count > 0) {
                for (int i = 0; i < count; i++) {
                    PlayerData player = response.Players[i];
                    if(!isValidPlayer(player)){ continue; }

                    Vector3 Head = player.LocationHeadBox;
                    Vector3 Toe = player.LocationToeBox;

                    float boxHeight = (player.LocationToeBox.Y + 1.0f) - Head.Y;
                    float boxWidth = boxHeight * 0.55f;

                    Rect PlayerRect(Head.X - (boxWidth / 2),Head.Y - 1.0f, boxWidth, boxHeight);

                    char buffer[30];
                    sprintf(buffer, "%.2fm", player.Distance);

                    if (Head.Z != 1) {

                        if((int)pAIM.AimFov){
                            m_Canvas->drawCircle(screenWidth / 2, screenHeight / 2, (int)pAIM.AimFov * 7, 1.0, false,pESP.ESPColor);
                        }

                        if(pESP.esp_line) {
                            if(pESP.esp_line_pos == pESP.PositionLine::top) {
                                if(!player.PlayerState){
                                    m_Canvas->drawLine(Vector3(screenWidth / 2, 0), Vector3(Head.X, Head.Y - (pESP.esp_name ? 38.0f : 1.0f)) ,linesize, pESP.ESPColor); //Top
                                }else{
                                    m_Canvas->drawLine(Vector3(screenWidth / 2, 0), Vector3(Head.X, Head.Y - (pESP.esp_name ? 38.0f : 1.0f)) ,linesize, pESP.ESPDieingColor); //Top
                                }
                            } else if (pESP.esp_line_pos == pESP.PositionLine::Center) {
                                if(!player.PlayerState){
                                    m_Canvas->drawLine(Vector3(screenWidth / 2, screenHeight / 2), Vector3(Head.X, Head.Y - 1.0f) ,linesize, pESP.ESPColor); //Center
                                }else{
                                    m_Canvas->drawLine(Vector3(screenWidth / 2, screenHeight / 2), Vector3(Head.X, Head.Y - 1.0f) ,linesize, pESP.ESPDieingColor); //Center
                                }
                            } else if (pESP.esp_line_pos == pESP.PositionLine::Down) {
                                if(!player.PlayerState){
                                    m_Canvas->drawLine(Vector3(screenWidth / 2, screenHeight / 1), Vector3(Toe.X, Toe.Y + (pESP.esp_distance ? 22.0f : 0.0f)),linesize, pESP.ESPColor); //Down
                                }else{
                                    m_Canvas->drawLine(Vector3(screenWidth / 2, screenHeight / 1), Vector3(Toe.X, Toe.Y + (pESP.esp_distance ? 22.0f : 0.0f)),linesize, pESP.ESPDieingColor); //Down
                                }
                            }
                        }

                        if(pESP.esp_skeleton) {
                            if(!player.PlayerState){
                                m_Canvas->drawLine(Vector3(((player.LocationHead.X)),(player.LocationHead.Y)), Vector3(((player.LocationChest.X)),(player.LocationChest.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationChest.X)),(player.LocationChest.Y)), Vector3(((player.LocationStomach.X)),(player.LocationStomach.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationStomach.X)),(player.LocationStomach.Y)), Vector3(((player.LocationHip.X)),(player.LocationHip.Y)),linesize, pESP.ESPColor);

                                m_Canvas->drawLine(Vector3(((player.LocationChest.X)),(player.LocationChest.Y)), Vector3(((player.LocationLeftShoulder.X)),(player.LocationLeftShoulder.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftShoulder.X)),(player.LocationLeftShoulder.Y)), Vector3(((player.LocationLeftArm.X)),(player.LocationLeftArm.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftArm.X)),(player.LocationLeftArm.Y)), Vector3(((player.LocationLeftForearm.X)),(player.LocationLeftForearm.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftForearm.X)),(player.LocationLeftForearm.Y)), Vector3(((player.LocationLeftHand.X)),(player.LocationLeftHand.Y)),linesize, pESP.ESPColor);

                                m_Canvas->drawLine(Vector3(((player.LocationChest.X)),(player.LocationChest.Y)), Vector3(((player.LocationRightShoulder.X)),(player.LocationRightShoulder.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightShoulder.X)),(player.LocationRightShoulder.Y)), Vector3(((player.LocationRightArm.X)),(player.LocationRightArm.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightArm.X)),(player.LocationRightArm.Y)), Vector3(((player.LocationRightForearm.X)),(player.LocationRightForearm.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightForearm.X)),(player.LocationRightForearm.Y)), Vector3(((player.LocationRightHand.X)),(player.LocationRightHand.Y)),linesize, pESP.ESPColor);

                                m_Canvas->drawLine(Vector3(((player.LocationHip.X)),(player.LocationHip.Y)), Vector3(((player.LocationLeftThigh.X)),(player.LocationLeftThigh.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftThigh.X)),(player.LocationLeftThigh.Y)), Vector3(((player.LocationLeftShin.X)),(player.LocationLeftShin.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftShin.X)),(player.LocationLeftShin.Y)), Vector3(((player.LocationLeftFoot.X)),(player.LocationLeftFoot.Y)),linesize, pESP.ESPColor);

                                m_Canvas->drawLine(Vector3(((player.LocationHip.X)),(player.LocationHip.Y)), Vector3(((player.LocationRightThigh.X)),(player.LocationRightThigh.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightThigh.X)),(player.LocationRightThigh.Y)), Vector3(((player.LocationRightShin.X)),(player.LocationRightShin.Y)),linesize, pESP.ESPColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightShin.X)),(player.LocationRightShin.Y)), Vector3(((player.LocationRightFoot.X)),(player.LocationRightFoot.Y)),linesize, pESP.ESPColor);
                            }else{
                                m_Canvas->drawLine(Vector3(((player.LocationHead.X)),(player.LocationHead.Y)), Vector3(((player.LocationChest.X)),(player.LocationChest.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationChest.X)),(player.LocationChest.Y)), Vector3(((player.LocationStomach.X)),(player.LocationStomach.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationStomach.X)),(player.LocationStomach.Y)), Vector3(((player.LocationHip.X)),(player.LocationHip.Y)),linesize, pESP.ESPDieingColor);

                                m_Canvas->drawLine(Vector3(((player.LocationChest.X)),(player.LocationChest.Y)), Vector3(((player.LocationLeftShoulder.X)),(player.LocationLeftShoulder.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftShoulder.X)),(player.LocationLeftShoulder.Y)), Vector3(((player.LocationLeftArm.X)),(player.LocationLeftArm.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftArm.X)),(player.LocationLeftArm.Y)), Vector3(((player.LocationLeftForearm.X)),(player.LocationLeftForearm.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftForearm.X)),(player.LocationLeftForearm.Y)), Vector3(((player.LocationLeftHand.X)),(player.LocationLeftHand.Y)),linesize, pESP.ESPDieingColor);

                                m_Canvas->drawLine(Vector3(((player.LocationChest.X)),(player.LocationChest.Y)), Vector3(((player.LocationRightShoulder.X)),(player.LocationRightShoulder.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightShoulder.X)),(player.LocationRightShoulder.Y)), Vector3(((player.LocationRightArm.X)),(player.LocationRightArm.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightArm.X)),(player.LocationRightArm.Y)), Vector3(((player.LocationRightForearm.X)),(player.LocationRightForearm.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightForearm.X)),(player.LocationRightForearm.Y)), Vector3(((player.LocationRightHand.X)),(player.LocationRightHand.Y)),linesize, pESP.ESPDieingColor);

                                m_Canvas->drawLine(Vector3(((player.LocationHip.X)),(player.LocationHip.Y)), Vector3(((player.LocationLeftThigh.X)),(player.LocationLeftThigh.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftThigh.X)),(player.LocationLeftThigh.Y)), Vector3(((player.LocationLeftShin.X)),(player.LocationLeftShin.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationLeftShin.X)),(player.LocationLeftShin.Y)), Vector3(((player.LocationLeftFoot.X)),(player.LocationLeftFoot.Y)),linesize, pESP.ESPDieingColor);

                                m_Canvas->drawLine(Vector3(((player.LocationHip.X)),(player.LocationHip.Y)), Vector3(((player.LocationRightThigh.X)),(player.LocationRightThigh.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightThigh.X)),(player.LocationRightThigh.Y)), Vector3(((player.LocationRightShin.X)),(player.LocationRightShin.Y)),linesize, pESP.ESPDieingColor);
                                m_Canvas->drawLine(Vector3(((player.LocationRightShin.X)),(player.LocationRightShin.Y)), Vector3(((player.LocationRightFoot.X)),(player.LocationRightFoot.Y)),linesize, pESP.ESPDieingColor);
                            }
                        }

                        if(pESP.esp_box) {
                            if(pESP.esp_box_pos == pESP.TypeBox::Stroke) {
                                if(!player.PlayerState){
                                    m_Canvas->DrawBox(PlayerRect,linesize,pESP.ESPColor);
                                }else{
                                    m_Canvas->DrawBox(PlayerRect,linesize,pESP.ESPDieingColor);
                                }

                            } else if (pESP.esp_box_pos == pESP.TypeBox::Filled) {
                                if(!player.PlayerState){
                                    m_Canvas->DrawRectGradient(pESP.ESPColor,linesize,PlayerRect);
                                }else{
                                    m_Canvas->DrawRectGradient(pESP.ESPDieingColor,linesize,PlayerRect);
                                }

                            } else if (pESP.esp_box_pos == pESP.TypeBox::Corner) {
                                if(!player.PlayerState){
                                    m_Canvas->DrawCornerBox(pESP.ESPColor, linesize, PlayerRect, 5, 5);
                                }else{
                                    m_Canvas->DrawCornerBox(pESP.ESPDieingColor, linesize, PlayerRect, 5, 5);
                                }

                            } else if (pESP.esp_box_pos == pESP.TypeBox::Rounded) {
                                if(!player.PlayerState){
                                    m_Canvas->drawRoundRect(PlayerRect.x,PlayerRect.y,PlayerRect.width,PlayerRect.height,5,5,pESP.ESPColor,linesize);
                                }else{
                                    m_Canvas->drawRoundRect(PlayerRect.x,PlayerRect.y,PlayerRect.width,PlayerRect.height,5,5,pESP.ESPDieingColor,linesize);
                                }
                            }
                        }
                        if(pESP.esp_distance) {
                            if(!player.PlayerState){
                                m_Canvas->drawText(pESP.ESPColor, Color.BLACK, buffer,Vector2(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height + 16.0f), pESP.distanceSize);
                            }else{
                                m_Canvas->drawText(pESP.ESPDieingColor, Color.BLACK, buffer,Vector2(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height + 16.0f), pESP.distanceSize);
                            }
                        }

                        if(pESP.esp_health) {
                            m_Canvas->DrawRoundHealthBar(PlayerRect,200,player.Life);
                        }

                    }
                }
            }
        }
    }
}