struct {
    SocketClient client;
}pSOCKEt;

struct {
    bool AimbotShot;
    bool AimbotAim;
    float AimFov;
    bool Ghost;
}pAIM;

struct {
    enum PositionLine {
        top = 1,
        Center = 2,
        Down = 3
    };
    enum TypeBox {
        Filled = 1,
        Stroke = 2,
        Corner = 3,
        Rounded = 4
    };
    bool esp_name;
    bool esp_line;
    bool esp_skeleton;
    bool esp_box;
    bool esp_distance;
    bool esp_health;

    float nameSize = 15.0f;
    float distanceSize = 15.0f;
    int EspFix = 0;

    int esp_line_pos = PositionLine::top;
    int esp_box_pos = TypeBox::Stroke;

    int ESPColor = Color.CYAN;
    int ESPDieingColor = Color.RED;
}pESP;

struct {
    bool SendStatus = false;

    char paramsSTS[1024];
    const char *isStatus = OBFUSCATE("Status:%s");
    const char *isSucesso = OBFUSCATE("Sucesso");
    const char *isFailed = OBFUSCATE("Fail");
    const char *SucessoEnd = OBFUSCATE("Status:Sucesso");
    const char *FailedEnd = OBFUSCATE("Status:Fail");
}Logger;

uint64_t GetTickCount() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

class Interval {
private:
    int initial_;

public:
    inline Interval() : initial_(GetTickCount()) {}
    virtual ~Interval() {}
    inline unsigned int value() const {
        return GetTickCount() - initial_;
    }
};

class FPS {
protected:
    int32_t m_fps;
    int32_t m_fpscount;
    Interval m_fpsinterval;

public:
    FPS() : m_fps(0), m_fpscount(0) {}


    void Update() {
        m_fpscount++;
        if (m_fpsinterval.value() > 1000) {
            m_fps = m_fpscount;
            m_fpscount = 0;
            m_fpsinterval = Interval();
        }
    }

    int32_t get() const {
        return m_fps;
    }
};

FPS Frames;