struct {
    SocketServer server;
}pSOCKEt;

struct {
    bool AimbotShot;
    bool AimbotAim;
    float AimFov;
    bool Ghost;
}pAIM;

struct {
    int g_screenWidth, g_screenHeight;
    bool esp;
}pESP;