struct {
    JNIEnv *EnvGlobal;
}JNI;

struct {
    const char *DrawESP = AY_OBFUSCATE("com/purpou/patcher/DrawESP");
    const char *Floater = AY_OBFUSCATE("com/purpou/patcher/Floater");
    const char *Native  = AY_OBFUSCATE("com/purpou/patcher/Native");
}ClassJNI;

namespace ToastLength {
    inline const int LENGTH_LONG = 1;
    inline const int LENGTH_SHORT = 0;
}

struct {
    int FILL_PARENT = -1;
    int MATCH_PARENT = -1;
    int WRAP_CONTENT = -2;
}LayoutParams;

struct {
    int HORIZONTAL = 0;
    int VERTICAL = 1;
}Orientation;

struct {
    int CENTER = 17;
    int START = 8388611;
    int END = 8388613;
    int LEFT = 3;
    int RIGHT = 5;
    int TOP = 48;
    int BOTTOM = 80;
}Gravity;

struct {
    int SCREEN_ORIENTATION_LANDSCAPE = 0;
}ActivityInfo;

struct {
    int FLAG_FULLSCREEN = 1024;
}Flags;

struct {
    int LINE = 2;
    int OVAL = 1;
    int RECTANGLE = 0;
}Shape;

struct {
    int BOLD = 1;
    int BOLD_ITALIC = 3;
    int ITALIC = 2;
    int NORMAL = 0;
}TypeFace;

struct {
    jobject AsyncTaskRunner(JNIEnv *env, jobject ctx) {
        jclass Floater$FreeFireTask = env->FindClass("com/brmods/loader/Native$FreeFireTask");
        jmethodID AuthID = env->GetMethodID(Floater$FreeFireTask, "<init>","(Landroid/content/Context;)V");
        return env->NewGlobalRef(env->NewObject(Floater$FreeFireTask, AuthID,ctx));
    }
    void StartFeatureLIst(jobject LinearView) {
        jclass listener_clazz = JNI.EnvGlobal->FindClass("com/brmods/loader/Loader");
        jmethodID addCheckBoxID = JNI.EnvGlobal->GetStaticMethodID(listener_clazz, "StartFeatureLIst","(Landroid/widget/LinearLayout;)V");
        JNI.EnvGlobal->CallStaticVoidMethod(listener_clazz,addCheckBoxID,LinearView);
        JNI.EnvGlobal->DeleteLocalRef(listener_clazz);
    }
    void ComandeSu(const char *comande) {
        jclass listener_clazz = JNI.EnvGlobal->FindClass("com/brmods/loader/Native");
        jmethodID addCheckBoxID = JNI.EnvGlobal->GetStaticMethodID(listener_clazz, "ComandeSu","(Ljava/lang/String;)V");
        JNI.EnvGlobal->CallStaticVoidMethod(listener_clazz,addCheckBoxID,JNI.EnvGlobal->NewStringUTF(comande));
        JNI.EnvGlobal->DeleteLocalRef(listener_clazz);
    }
}JavaJNI;

struct {
    const char *WINDOW_SERVICE = "window";
    const char *CONNECTIVITY_SERVICE = "connectivity";

    jobject getSystemService(jobject ctx, const char * Context) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass("android/content/Context");
        jmethodID getSystemServiceID = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getSystemServiceID, JNI.EnvGlobal->NewStringUTF(Context)));
    }

    jobject getCacheDir(jobject ctx) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass("android/content/Context");
        jmethodID getCacheDirID = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, "getCacheDir","()Ljava/io/File;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getCacheDirID));
    }
}Context;

struct {
    int COMPLEX_UNIT_DIP = 1;
    int COMPLEX_UNIT_SP = 2;

    jfloat applyDimension(int unit, float value, jobject metrics) {
        jclass TypedValueClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/util/TypedValue"));
        jmethodID applyDimensionID = JNI.EnvGlobal->GetStaticMethodID(TypedValueClass, AY_OBFUSCATE("applyDimension"), AY_OBFUSCATE("(IFLandroid/util/DisplayMetrics;)F"));
        return JNI.EnvGlobal->CallStaticFloatMethod(TypedValueClass, applyDimensionID, unit, value, metrics);
    }
}TypedValue;

struct {
    jobject FrameLayout(jobject ctx) {
        jclass FrameLayoutClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/FrameLayout"));
        jmethodID FrameLayoutID = JNI.EnvGlobal->GetMethodID(FrameLayoutClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(FrameLayoutClass, FrameLayoutID, ctx));
    }
}FrameLayout;

struct {
    jobject LinearLayout(JNIEnv *env, jobject ctx) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID linearLayoutID = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return env->NewGlobalRef(env->NewObject(linearLayoutClass, linearLayoutID, ctx));
    }
    jobject LayoutParams(JNIEnv *env, int width, int height) {
        jclass LayoutPramsClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout$LayoutParams"));
        jmethodID LayoutPramsID = env->GetMethodID(LayoutPramsClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(II)V"));
        return env->NewGlobalRef(env->NewObject(LayoutPramsClass, LayoutPramsID, width,height));
    }
    void setLayoutParams(JNIEnv *env, jobject LinearLayout, jobject MainParams) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID setLayoutParams = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setLayoutParams"), AY_OBFUSCATE("(Landroid/view/ViewGroup$LayoutParams;)V"));
        env->CallVoidMethod(LinearLayout, setLayoutParams, MainParams);
        env->DeleteLocalRef(linearLayoutClass);
    }
    void setOrientation(JNIEnv *env, jobject LinearLayout, int orientation) {
        jclass linearLayoutClass = env->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID setOrientation = env->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setOrientation"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(LinearLayout, setOrientation, orientation);
        env->DeleteLocalRef(linearLayoutClass);
    }
    void setGravity(jobject thiz, int Gravity) {
        jclass LinearLayoutClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID setGravity = JNI.EnvGlobal->GetMethodID(LinearLayoutClass, AY_OBFUSCATE("setGravity"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz,setGravity,Gravity);
        JNI.EnvGlobal->DeleteLocalRef(LinearLayoutClass);
    }
    void setBackground(jobject LinearLayout, jobject GradientDrawable) {
        jclass linearLayoutClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/LinearLayout"));
        jmethodID setBackground = JNI.EnvGlobal->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setBackground"), AY_OBFUSCATE("(Landroid/graphics/drawable/Drawable;)V"));
        JNI.EnvGlobal->CallVoidMethod(LinearLayout, setBackground, GradientDrawable);
        JNI.EnvGlobal->DeleteLocalRef(linearLayoutClass);
    }
    void topMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID topMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("topMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,topMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
}LinearLayout;

struct {
    jobject RelativeLayout(jobject ctx) {
        jclass RelativeLayoutClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/RelativeLayout"));
        jmethodID RelativeLayoutID = JNI.EnvGlobal->GetMethodID(RelativeLayoutClass, AY_OBFUSCATE("<init>"),  AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(RelativeLayoutClass, RelativeLayoutID, ctx));
    }
    void setGravity(jobject thiz, int Gravity) {
        jclass RelativeLayoutClass = JNI.EnvGlobal->FindClass( AY_OBFUSCATE("android/widget/RelativeLayout"));
        jmethodID setGravity = JNI.EnvGlobal->GetMethodID(RelativeLayoutClass,  AY_OBFUSCATE("setGravity"),  AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz,setGravity,Gravity);
        JNI.EnvGlobal->DeleteLocalRef(RelativeLayoutClass);
    }
}RelativeLayout;

struct {
    int VISIBLE = 0;
    int GONE = 8;
    int INVISIBLE = 4;
    int SYSTEM_UI_FLAG_LAYOUT_STABLE = 256;
    int SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION = 512;
    int SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN = 1024;
    int SYSTEM_UI_FLAG_HIDE_NAVIGATION = 2;
    int SYSTEM_UI_FLAG_FULLSCREEN = 4;
    int SYSTEM_UI_FLAG_IMMERSIVE_STICKY = 4096;

    jobject View(jobject ctx) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass( AY_OBFUSCATE("android/view/View"));
        jmethodID TextViewID = JNI.EnvGlobal->GetMethodID(TextViewClass,  AY_OBFUSCATE("<init>"),  AY_OBFUSCATE("(Landroid/content/Context;)V"));
        jobject ViewObj = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(TextViewClass, TextViewID, ctx));
        return ViewObj;
    }
    void setVisibility(jobject view, int visibility) {
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setAlphaID = JNI.EnvGlobal->GetMethodID(ViewClass,AY_OBFUSCATE("setVisibility"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(view,setAlphaID,visibility);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
    void setBackgroundColor(jobject TexttView, int Color) {
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setBackgroundColor = JNI.EnvGlobal->GetMethodID(ViewClass, AY_OBFUSCATE("setBackgroundColor"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView, setBackgroundColor, Color);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
    void setLayoutParams(jobject View, jobject MainParams) {
        jclass linearLayoutClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setLayoutParams = JNI.EnvGlobal->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setLayoutParams"), AY_OBFUSCATE("(Landroid/view/ViewGroup$LayoutParams;)V"));
        JNI.EnvGlobal->CallVoidMethod(View, setLayoutParams, MainParams);
        JNI.EnvGlobal->DeleteLocalRef(linearLayoutClass);
    }
    void setBackground(jobject thiz, jobject Drawable) {
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setBackground = JNI.EnvGlobal->GetMethodID(ViewClass, AY_OBFUSCATE("setBackground"), AY_OBFUSCATE("(Landroid/graphics/drawable/Drawable;)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setBackground,Drawable);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
    void setElevation(jobject thiz, float elevation) {
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setElevation = JNI.EnvGlobal->GetMethodID(ViewClass, AY_OBFUSCATE("setElevation"), AY_OBFUSCATE("(F)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setElevation, elevation);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
    void setPadding(jobject thiz, int left, int top, int right, int bottom) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setPadding = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setPadding"), AY_OBFUSCATE("(IIII)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setPadding,left,top,right,bottom);
        JNI.EnvGlobal->DeleteLocalRef(TextViewClass);
    }
    void setAlpha(jobject webview, float alpha) {
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID setAlphaID = JNI.EnvGlobal->GetMethodID(ViewClass,AY_OBFUSCATE("setAlpha"), AY_OBFUSCATE("(F)V"));
        JNI.EnvGlobal->CallVoidMethod(webview,setAlphaID,alpha);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
}View;

struct {
    jobject GradientDrawable(jobject ctx) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID GradientDrawableID = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("()V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(GradientDrawableClass, GradientDrawableID));
    }
    void setShape(jobject thiz, int shape) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setShape = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setShape"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setShape,shape);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    void setColor(jobject GradientDrawable, int Color) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setColor = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setColor"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(GradientDrawable, setColor, Color);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    void setCornerRadii(jobject gradientDrawable, float f1, float f2, float f3, float f4) {
        jfloat radii[] = {f1, f1, f2, f2, f3, f3, f4, f4};
        jfloatArray teste = JNI.EnvGlobal->NewFloatArray(8);
        JNI.EnvGlobal->SetFloatArrayRegion(teste, 0, 8, radii);
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setCornerRadii = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setCornerRadii"),AY_OBFUSCATE("([F)V"));
        JNI.EnvGlobal->CallVoidMethod(gradientDrawable,setCornerRadii,teste);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    void setCornerRadius(jobject GradientDrawable, float radius){
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setCornerRadius = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setCornerRadius"),AY_OBFUSCATE("(F)V"));
        JNI.EnvGlobal->CallVoidMethod(GradientDrawable, setCornerRadius, radius);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    void setStroke(jobject GradientDrawable, int X_Pos, int Y_Pos) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID setStroke = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("setStroke"), AY_OBFUSCATE("(II)V"));
        JNI.EnvGlobal->CallVoidMethod(GradientDrawable, setStroke, X_Pos, Y_Pos);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    jobject Gradient(jobject orientation, jintArray colors) {
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable"));
        jmethodID GradientDrawableID = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(GradientDrawableClass, GradientDrawableID, orientation,colors));
    }
    void setSize(jobject GradientDrawable, int width, int height){
        jclass GradientDrawableClass = JNI.EnvGlobal->FindClass("android/graphics/drawable/GradientDrawable");
        jmethodID setSizeID = JNI.EnvGlobal->GetMethodID(GradientDrawableClass, "setSize", "(II)V");
        JNI.EnvGlobal->CallVoidMethod(GradientDrawable, setSizeID, width,height);
        JNI.EnvGlobal->DeleteLocalRef(GradientDrawableClass);
    }
    struct {
        jobject LEFT_RIGHT() {
            jclass OrientationClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/drawable/GradientDrawable$Orientation"));
            jfieldID LEFT_RIGHT = JNI.EnvGlobal->GetStaticFieldID(OrientationClass, AY_OBFUSCATE("LEFT_RIGHT"),AY_OBFUSCATE("Landroid/graphics/drawable/GradientDrawable$Orientation;"));
            return JNI.EnvGlobal->GetStaticObjectField(OrientationClass, LEFT_RIGHT);
        }
    }Orientation;
}GradientDrawable;

struct{

}Math;

struct {
    struct {
        void topMargin(jobject params, int value) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
            jfieldID topMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams,AY_OBFUSCATE("topMargin"), AY_OBFUSCATE("I"));
            JNI.EnvGlobal->SetIntField(params,topMargin,value);
            JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
        }
    }MarginLayoutParams;

    jmethodID addView() {
        jclass ViewGroupClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup"));
        return JNI.EnvGlobal->GetMethodID(ViewGroupClass, AY_OBFUSCATE("addView"), AY_OBFUSCATE("(Landroid/view/View;)V"));
    }
    void topMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID topMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("topMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,topMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
    void leftMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID leftMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("leftMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,leftMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
    void rightMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID rightMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("rightMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,rightMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
    void bottomMargin(jobject params, int value) {
        jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewGroup$MarginLayoutParams"));
        jfieldID bottomMargin = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("bottomMargin"), AY_OBFUSCATE("I"));
        JNI.EnvGlobal->SetIntField(params,bottomMargin,value);
        JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
    }
    void addView(JNIEnv *env, jobject linear, jobject child){
        jclass ViewGroupClass = env->FindClass(AY_OBFUSCATE("android/view/ViewGroup"));
        jmethodID addView = env->GetMethodID(ViewGroupClass, AY_OBFUSCATE("addView"), AY_OBFUSCATE("(Landroid/view/View;)V"));
        env->CallVoidMethod(linear,addView,child);
        JNI.EnvGlobal->DeleteLocalRef(ViewGroupClass);
    }
}ViewGroup;

struct {
    struct {
        jobject WindowParams(int w, int h, int _type, int _flags, int _format) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jmethodID WindowManagerParamsID = JNI.EnvGlobal->GetMethodID(WindowManager$LayoutParams, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(IIIII)V"));
            return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(WindowManager$LayoutParams,WindowManagerParamsID,w,h,_type,_flags,_format));
        }
        jint FLAG_NOT_FOCUSABLE() {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID FLAG_NOT_FOCUSABLEID = JNI.EnvGlobal->GetStaticFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("FLAG_NOT_FOCUSABLE"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetStaticIntField(WindowManager$LayoutParams,FLAG_NOT_FOCUSABLEID);
        }
        jint TYPE_PHONE() {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID SDK_INTID = JNI.EnvGlobal->GetStaticFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("TYPE_PHONE"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetStaticIntField(WindowManager$LayoutParams,SDK_INTID);
        }
        void gravity(jobject params, int value) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID GravityID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("gravity"), AY_OBFUSCATE("I"));
            JNI.EnvGlobal->SetIntField(params,GravityID,value);
            JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
        }
        void x(jobject params, int value) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID xID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("x"), AY_OBFUSCATE("I"));
            JNI.EnvGlobal->SetIntField(params,xID,value);
            JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
        }

        void y(jobject params, int value) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID yID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("y"), AY_OBFUSCATE("I"));
            JNI.EnvGlobal->SetIntField(params,yID,value);
            JNI.EnvGlobal->DeleteLocalRef(WindowManager$LayoutParams);
        }
        jint GetX(jobject params) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID xID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("x"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetIntField(params,xID);
        }
        jint GetY(jobject params) {
            jclass WindowManager$LayoutParams = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/WindowManager$LayoutParams"));
            jfieldID yID = JNI.EnvGlobal->GetFieldID(WindowManager$LayoutParams, AY_OBFUSCATE("y"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetIntField(params,yID);
        }
    }LayoutParams;
}WindowManager;

struct {
    jint TRANSLUCENT() {
        jclass PixelFormat = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/PixelFormat"));
        jfieldID TRANSLUCENTID = JNI.EnvGlobal->GetStaticFieldID(PixelFormat, AY_OBFUSCATE("TRANSLUCENT"), AY_OBFUSCATE("I"));
        return JNI.EnvGlobal->GetStaticIntField(PixelFormat,TRANSLUCENTID);
    }
}PixelFormat;

struct {
    jobject getSystemService(jobject ctx, const char * Context) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jmethodID getSystemServiceID = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, AY_OBFUSCATE("getSystemService"), AY_OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getSystemServiceID, JNI.EnvGlobal->NewStringUTF(Context)));
    }
    const char *getPackageName(jobject ctx) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jmethodID getPackageNameID = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, AY_OBFUSCATE("getPackageName"), AY_OBFUSCATE("()Ljava/lang/String;"));
        jstring getPackageName = (jstring)(JNI.EnvGlobal->CallObjectMethod(ctx, getPackageNameID));
        return JNI.EnvGlobal->GetStringUTFChars(getPackageName, 0);
    }
    jobject startService(jobject ctx, jobject service) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jmethodID startActivityMethodId = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, AY_OBFUSCATE("startService"), AY_OBFUSCATE("(Landroid/content/Intent;)Landroid/content/ComponentName;"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, startActivityMethodId,service));
    }
    jobject getResources(jobject ctx) {
        jclass ContextWrapperClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jmethodID getResourcesID = JNI.EnvGlobal->GetMethodID(ContextWrapperClass, AY_OBFUSCATE("getResources"), AY_OBFUSCATE("()Landroid/content/res/Resources;"));
        return JNI.EnvGlobal->CallObjectMethod(ctx, getResourcesID);
    }
}ContextWrapper;

struct {
    jobject getDisplayMetrics(jobject ctx) {
        jclass ResourcesClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/res/Resources"));
        jmethodID getDisplayMetricsID = JNI.EnvGlobal->GetMethodID(ResourcesClass, AY_OBFUSCATE("getDisplayMetrics"), AY_OBFUSCATE("()Landroid/util/DisplayMetrics;"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ContextWrapper.getResources(ctx),getDisplayMetricsID));
    }
}Resources;

jfloat ConvertDP(jobject ctx, jfloat value) {
    return TypedValue.applyDimension( TypedValue.COMPLEX_UNIT_DIP,value,Resources.getDisplayMetrics(ctx));
}

struct {
    int BLACK = -16777216;
    int BLUE = -16776961;
    int CYAN = -16711681;
    int DKGRAY = -12303292;
    int GRAY = -7829368;
    int GREEN = -16711936;
    int LTGRAY = -3355444;
    int MAGENTA = -65281;
    int RED = -65536;
    int TRANSPARENT = 0;
    int WHITE = -1;
    int YELLOW = -256;
    int ORANGE = -256;

    jint parseColor(JNIEnv *env, const char *colorString) {
        jclass ColorClass = env->FindClass(AY_OBFUSCATE("android/graphics/Color"));
        jmethodID startActivity = env->GetStaticMethodID(ColorClass, AY_OBFUSCATE("parseColor"), AY_OBFUSCATE("(Ljava/lang/String;)I"));
        return env->CallStaticIntMethod(ColorClass,startActivity, env->NewStringUTF(colorString));
    }

    jint rgb(int red, int green, int blue) {
        jclass ColorClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/Color"));
        jmethodID startActivity = JNI.EnvGlobal->GetStaticMethodID(ColorClass, AY_OBFUSCATE("rgb"), AY_OBFUSCATE("(III)I"));
        return JNI.EnvGlobal->CallStaticIntMethod(ColorClass,startActivity,red,green,blue);
    }
    jint argb(int alpha, int red, int green, int blue) {
        jclass ColorClass = JNI.EnvGlobal->FindClass("android/graphics/Color");
        jmethodID startActivity = JNI.EnvGlobal->GetStaticMethodID(ColorClass, "argb", "(IIII)I");
        return JNI.EnvGlobal->CallStaticIntMethod(ColorClass,startActivity,alpha,red,green,blue);
    }
} Color;

struct {
    struct {
        jint SDK_INT() {
            jclass VERSION = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/os/Build$VERSION"));
            jfieldID SDK_INTID = JNI.EnvGlobal->GetStaticFieldID(VERSION, AY_OBFUSCATE("SDK_INT"), AY_OBFUSCATE("I"));
            return JNI.EnvGlobal->GetStaticIntField(VERSION,SDK_INTID);
        }
    }VERSION;
    struct {
        int M = 23;
        int LOLLIPOP = 21;
    }VERSION_CODES;
    jstring MANUFACTURER() {
        jclass BuildClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/os/Build"));
        jfieldID MANUFACTURERID = JNI.EnvGlobal->GetStaticFieldID(BuildClass, AY_OBFUSCATE("MANUFACTURER"), AY_OBFUSCATE("Ljava/lang/String;"));
        return (jstring)JNI.EnvGlobal->GetStaticObjectField(BuildClass, MANUFACTURERID);
    }
    jstring MODEL() {
        jclass BuildClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/os/Build"));
        jfieldID MODELID = JNI.EnvGlobal->GetStaticFieldID(BuildClass, AY_OBFUSCATE("MODEL"), AY_OBFUSCATE("Ljava/lang/String;"));
        return (jstring)JNI.EnvGlobal->GetStaticObjectField(BuildClass, MODELID);
    }
}Build;

struct {
    void addView(jobject Manager, jobject var1, jobject var2) {
        jclass ViewManagerClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewManager"));
        jmethodID addViewID = JNI.EnvGlobal->GetMethodID(ViewManagerClass, AY_OBFUSCATE("addView"), AY_OBFUSCATE("(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V"));
        JNI.EnvGlobal->CallVoidMethod(Manager,addViewID,var1,var2);
        JNI.EnvGlobal->DeleteLocalRef(ViewManagerClass);
    }
    void updateViewLayout(jobject Params, jobject var1, jobject var2){
        jclass ViewManagerClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/ViewManager"));
        jmethodID updateViewLayoutID = JNI.EnvGlobal->GetMethodID(ViewManagerClass, AY_OBFUSCATE("updateViewLayout"), AY_OBFUSCATE("(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V"));
        JNI.EnvGlobal->CallVoidMethod(Params, updateViewLayoutID,var1, var2);
        JNI.EnvGlobal->DeleteLocalRef(ViewManagerClass);
    }
}ViewManager;

struct {
    jbyteArray Decode(const char *str) {
        jclass base64class = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/util/Base64"));
        jmethodID base64constr = JNI.EnvGlobal->GetStaticMethodID(base64class, AY_OBFUSCATE("decode"), AY_OBFUSCATE("(Ljava/lang/String;I)[B"));
        jstring string = JNI.EnvGlobal->NewStringUTF(str);
        return (jbyteArray)(JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallStaticObjectMethod(base64class, base64constr,string, 0)));
    }
    jstring toBase64(jbyteArray puk) {
        jclass Base64Class = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/util/Base64"));
        jmethodID encodeToStringID = JNI.EnvGlobal->GetStaticMethodID(Base64Class, AY_OBFUSCATE("encodeToString"),AY_OBFUSCATE("([BI)Ljava/lang/String;"));
        return (jstring)JNI.EnvGlobal->CallStaticObjectMethod(Base64Class,encodeToStringID,puk,2);
    }
}Base64;

struct {
    jobject decodeByteArray(jbyteArray decode) {
        jclass BitmapFactoryClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/graphics/BitmapFactory"));
        jmethodID decodeByteArrayID = JNI.EnvGlobal->GetStaticMethodID(BitmapFactoryClass, AY_OBFUSCATE("decodeByteArray"), AY_OBFUSCATE("([BII)Landroid/graphics/Bitmap;"));
        int lengthImagem = JNI.EnvGlobal->GetArrayLength(decode);
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallStaticObjectMethod(BitmapFactoryClass, decodeByteArrayID,decode, 0, lengthImagem));
    }
}BitmapFactory;

struct {
    jobject ImageView(jobject ctx) {
        jclass ImageViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/ImageView"));
        jmethodID ImageViewID = JNI.EnvGlobal->GetMethodID(ImageViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ImageViewClass, ImageViewID, ctx));
    }
    void setImageBitmap(jobject thiz, jobject bm) {
        jclass ImageViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/ImageView"));
        jmethodID setImageBitmap = JNI.EnvGlobal->GetMethodID(ImageViewClass, AY_OBFUSCATE("setImageBitmap"), AY_OBFUSCATE("(Landroid/graphics/Bitmap;)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz,setImageBitmap,bm);
        JNI.EnvGlobal->DeleteLocalRef(ImageViewClass);
    }
    void setBackground(jobject imagemView, jobject GradientDrawable) {
        jclass ImageViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/ImageView"));
        jmethodID setBackground = JNI.EnvGlobal->GetMethodID(ImageViewClass, AY_OBFUSCATE("setBackground"),AY_OBFUSCATE("(Landroid/graphics/drawable/Drawable;)V"));
        JNI.EnvGlobal->CallVoidMethod(imagemView, setBackground, GradientDrawable);
        JNI.EnvGlobal->DeleteLocalRef(ImageViewClass);
    }
}ImageView;

struct {
    jobject ScrollView(jobject ctx) {
        jclass ScrollViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/ScrollView"));
        jmethodID ScrollViewClassID = JNI.EnvGlobal->GetMethodID(ScrollViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ScrollViewClass, ScrollViewClassID, ctx));
    }
}ScrollView;

struct {
    jobject TextView(JNIEnv *env, jobject ctx) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID TextViewID = env->GetMethodID(TextViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return env->NewGlobalRef(env->NewObject(TextViewClass, TextViewID, ctx));
    }
    void setText(JNIEnv *env, jobject TexttView, const char* Text) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setText = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setText"), AY_OBFUSCATE("(Ljava/lang/CharSequence;)V"));
        env->CallVoidMethod(TexttView, setText, JNI.EnvGlobal->NewStringUTF(Text));
        env->DeleteLocalRef(TextViewClass);
    }
    void setText(jobject TexttView, jstring Text) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setText = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setText"), AY_OBFUSCATE("(Ljava/lang/CharSequence;)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView, setText, Text);
    }
    void setTextColor(JNIEnv *env, jobject TexttView, int color) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setTextColor = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setTextColor"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(TexttView, setTextColor, color);
        env->DeleteLocalRef(TextViewClass);
    }
    void setGravity(jobject TexttView, int Gravidade) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setGravity = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setGravity"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView, setGravity, Gravidade);
        JNI.EnvGlobal->DeleteLocalRef(TextViewClass);
    }
    void setTextSize(JNIEnv *env, jobject TexttView, jint typevalue, float size) {
        jclass TextViewClass = env->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setTextSize = env->GetMethodID(TextViewClass, AY_OBFUSCATE("setTextSize"), AY_OBFUSCATE("(IF)V"));
        env->CallVoidMethod(TexttView,setTextSize, typevalue, size);
        env->DeleteLocalRef(TextViewClass);
    }
    void setAllCaps(jobject thiz, bool allCaps) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setAllCaps = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setAllCaps"), AY_OBFUSCATE("(Z)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setAllCaps,allCaps);
        JNI.EnvGlobal->DeleteLocalRef(TextViewClass);
    }
    void setPadding(jobject thiz, int left, int top, int right, int bottom) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setPadding = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setPadding"), AY_OBFUSCATE("(IIII)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setPadding,left,top,right,bottom);
        JNI.EnvGlobal->DeleteLocalRef(TextViewClass);
    }
    void setLayoutParams(jobject TextView, jobject MainParams) {
        jclass linearLayoutClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setLayoutParams = JNI.EnvGlobal->GetMethodID(linearLayoutClass, AY_OBFUSCATE("setLayoutParams"), AY_OBFUSCATE("(Landroid/view/ViewGroup$LayoutParams;)V"));
        JNI.EnvGlobal->CallVoidMethod(TextView, setLayoutParams, MainParams);
        JNI.EnvGlobal->DeleteLocalRef(linearLayoutClass);
    }
    void fromHtml(jobject thiz, const char* text) {
        jclass html2 = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/text/Html"));
        jmethodID fromHtml2 = JNI.EnvGlobal->GetStaticMethodID(html2, AY_OBFUSCATE("fromHtml"), AY_OBFUSCATE("(Ljava/lang/String;)Landroid/text/Spanned;"));
        jclass textView2 = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setText2 = JNI.EnvGlobal->GetMethodID(textView2, AY_OBFUSCATE("setText"), AY_OBFUSCATE("(Ljava/lang/CharSequence;)V"));
        jstring jstr2 = JNI.EnvGlobal->NewStringUTF(text);
        JNI.EnvGlobal->CallVoidMethod(thiz, setText2,  JNI.EnvGlobal->CallStaticObjectMethod(html2, fromHtml2, jstr2));
        JNI.EnvGlobal->DeleteLocalRef(html2);
        JNI.EnvGlobal->DeleteLocalRef(textView2);
    }
    void setTypeface(jobject thiz, int Typeface) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setTypeface = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setTypeface"), AY_OBFUSCATE("(Landroid/graphics/Typeface;I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setTypeface, static_cast<jobject>(NULL),Typeface);
        JNI.EnvGlobal->DeleteLocalRef(TextViewClass);
    }
    void setHintColor(jobject TexttView, int Color) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setTextColor = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setHintTextColor"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView, setTextColor, Color);
    }
    void setShadowLayer(jobject thiz, float radius, float dx, float dy, int color) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/TextView"));
        jmethodID setShadowLayer = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setShadowLayer"), AY_OBFUSCATE("(FFFI)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz,setShadowLayer,radius,dx,dy,color);
        JNI.EnvGlobal->DeleteLocalRef(TextViewClass);
    }
}TextView;

struct {
    jobject Button(jobject ctx) {
        jclass ButtonClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/Button"));
        jmethodID ButtonID = JNI.EnvGlobal->GetMethodID(ButtonClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ButtonClass, ButtonID, ctx));
    }

    void setTypeface(jobject thiz, int Typeface) {
        jclass TextViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/Button"));
        jmethodID setTypeface = JNI.EnvGlobal->GetMethodID(TextViewClass, AY_OBFUSCATE("setTypeface"), AY_OBFUSCATE("(Landroid/graphics/Typeface;I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setTypeface, static_cast<jobject>(NULL),Typeface);
    }
}Button;

struct {
    enum {
        ACTION_DOWN = 0,
        ACTION_UP = 1,
        ACTION_MOVE = 2
    };

    jint getAction(jobject motionEvent) {
        jclass motionEventClass= JNI.EnvGlobal->GetObjectClass(motionEvent);
        jmethodID getActionID = JNI.EnvGlobal->GetMethodID(motionEventClass, AY_OBFUSCATE("getAction"), AY_OBFUSCATE("()I"));
        return JNI.EnvGlobal->CallIntMethod(motionEvent, getActionID,motionEvent);
    }

    jmethodID getRawX(jobject motionEvent) {
        jclass motionEventClass= JNI.EnvGlobal->GetObjectClass(motionEvent);
        return JNI.EnvGlobal->GetMethodID(motionEventClass, AY_OBFUSCATE("getRawX"), AY_OBFUSCATE("()F"));
    }
    jmethodID getRawY(jobject motionEvent) {
        jclass motionEventClass= JNI.EnvGlobal->GetObjectClass(motionEvent);
        return JNI.EnvGlobal->GetMethodID(motionEventClass, AY_OBFUSCATE("getRawY"), AY_OBFUSCATE("()F"));
    }
} MotionEvent;

struct {
    void setOnTouchListener(jobject rootFrame) {
        jclass cls = JNI.EnvGlobal->FindClass("com/brmods/loader/Native");
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID onTouchListenerID = JNI.EnvGlobal->GetStaticMethodID(cls, AY_OBFUSCATE("onTouchListener"),AY_OBFUSCATE("()Landroid/view/View$OnTouchListener;"));
        jmethodID setOnTouchListenerID = JNI.EnvGlobal->GetMethodID(ViewClass, AY_OBFUSCATE("setOnTouchListener"), AY_OBFUSCATE("(Landroid/view/View$OnTouchListener;)V"));
        jobject onTouchListener = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallStaticObjectMethod(cls, onTouchListenerID));
        JNI.EnvGlobal->CallVoidMethod(rootFrame, setOnTouchListenerID, onTouchListener);
        JNI.EnvGlobal->DeleteLocalRef(cls);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
}OnTouchListener;

struct {
    jobject Handler() {
        jclass Handler = JNI.EnvGlobal->FindClass("android/os/Handler");
        jmethodID HandlerID = JNI.EnvGlobal->GetMethodID(Handler, "<init>", "()V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(Handler, HandlerID));
    }
    void StartHandler() {
        jclass ClassNative = JNI.EnvGlobal->FindClass("com/brmods/loader/Native");
        jmethodID onHandlerID = JNI.EnvGlobal->GetStaticMethodID(ClassNative, "onHandler", "()V");
        JNI.EnvGlobal->CallStaticVoidMethod(ClassNative,onHandlerID);
        JNI.EnvGlobal->DeleteLocalRef(ClassNative);
    }
    jboolean postDelayed(jobject handler, jobject ctx, jlong delayMillis) {
        jlong teste = 1;
        jclass HandlerClass = JNI.EnvGlobal->FindClass("android/os/Handler");
        jmethodID postDelayedID = JNI.EnvGlobal->GetMethodID(HandlerClass, "postDelayed", "(Ljava/lang/Runnable;J)Z");
        return JNI.EnvGlobal->CallBooleanMethod(handler,postDelayedID,ctx,delayMillis);
        //  JNI.EnvGlobal->CallVoidMethod(thiz, setTypeface, static_cast<jobject>(NULL),Typeface);
    }
}Handler;

struct {
    jobject SeekBar(jobject ctx) {
        jclass SeekBarClass = JNI.EnvGlobal->FindClass("android/widget/SeekBar");
        jmethodID SeekbarID = JNI.EnvGlobal->GetMethodID(SeekBarClass, "<init>", "(Landroid/content/Context;)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(SeekBarClass, SeekbarID, ctx));
    }
    void setMax(jobject Seekbar, int max)
    {
        jclass AbsSeekBarClass = JNI.EnvGlobal->FindClass("android/widget/AbsSeekBar");
        jmethodID setMax = JNI.EnvGlobal->GetMethodID(AbsSeekBarClass, "setMax", "(I)V");
        JNI.EnvGlobal->CallVoidMethod(Seekbar, setMax, max);
        JNI.EnvGlobal->DeleteLocalRef(AbsSeekBarClass);
    }
    void setThumb(jobject seekbar, jobject Drawable) {
        jclass AbsSeekBarClass = JNI.EnvGlobal->FindClass("android/widget/AbsSeekBar");
        jmethodID setThumbID = JNI.EnvGlobal->GetMethodID(AbsSeekBarClass, "setThumb","(Landroid/graphics/drawable/Drawable;)V");
        JNI.EnvGlobal->CallVoidMethod(seekbar, setThumbID,Drawable);
        JNI.EnvGlobal->DeleteLocalRef(AbsSeekBarClass);
    }
    void setColorFilter(jobject ctx, jobject seekbar, int color, jobject mode) {
        jclass ProgressBarClass = JNI.EnvGlobal->FindClass("android/widget/ProgressBar");
        jclass DrawableClass = JNI.EnvGlobal->FindClass("android/graphics/drawable/Drawable");
        jmethodID getProgressDrawableID = JNI.EnvGlobal->GetMethodID(ProgressBarClass, "getProgressDrawable","()Landroid/graphics/drawable/Drawable;");
        jmethodID setColorFilterID = JNI.EnvGlobal->GetMethodID(DrawableClass, "setColorFilter", "(ILandroid/graphics/PorterDuff$Mode;)V");
        jobject teste1 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(seekbar, getProgressDrawableID));
        JNI.EnvGlobal->CallVoidMethod(teste1,setColorFilterID, color,mode);
        JNI.EnvGlobal->DeleteLocalRef(ProgressBarClass);
        JNI.EnvGlobal->DeleteLocalRef(DrawableClass);
    }
    jint getProgress(jobject seek)
    {
        jclass ProgressBarClass = JNI.EnvGlobal->FindClass("android/widget/ProgressBar");
        jmethodID getProgressID = JNI.EnvGlobal->GetMethodID(ProgressBarClass, "getProgress", "()I");
        return JNI.EnvGlobal->CallIntMethod(seek,getProgressID);
    }
    void setProgress(jobject seekbar, int progress) {
        jclass ProgressBarClass = JNI.EnvGlobal->FindClass("android/widget/ProgressBar");
        jmethodID setProgress = JNI.EnvGlobal->GetMethodID(ProgressBarClass, "setProgress","(I)V");
        JNI.EnvGlobal->CallVoidMethod(seekbar, setProgress,progress);
        JNI.EnvGlobal->DeleteLocalRef(ProgressBarClass);
    }
}SeekBar;

struct {
    void setOnClickListener(jobject ctx, jobject obj, int id) {
        jclass Viewclass = JNI.EnvGlobal->FindClass("android/view/View");
        jclass listener_clazz = JNI.EnvGlobal->FindClass("com/brmods/loader/Native");
        jmethodID new_listener = JNI.EnvGlobal->GetStaticMethodID(listener_clazz, "onClickListener","(Landroid/content/Context;I)Landroid/view/View$OnClickListener;");
        jobject listener = JNI.EnvGlobal->CallStaticObjectMethod(listener_clazz, new_listener, ctx, id);
        jmethodID set_onclicklistener = JNI.EnvGlobal->GetMethodID(Viewclass, "setOnClickListener", "(Landroid/view/View$OnClickListener;)V");
        JNI.EnvGlobal->CallVoidMethod(obj, set_onclicklistener, listener);
        JNI.EnvGlobal->DeleteLocalRef(Viewclass);
        JNI.EnvGlobal->DeleteLocalRef(listener_clazz);
    }
}OnClickListener;

struct {
    void OnCheckedChangeListener(jobject ctx, jobject obj, int id) {
        jclass CompoundButtonClass = JNI.EnvGlobal->FindClass("android/widget/CompoundButton");
        jclass listener_clazz = JNI.EnvGlobal->FindClass("com/brmods/loader/Native");
        jmethodID new_listener = JNI.EnvGlobal->GetStaticMethodID(listener_clazz, "OnCheckedChangeListener",
                                                                  "(Landroid/content/Context;Landroid/widget/CheckBox;I)Landroid/widget/CompoundButton$OnCheckedChangeListener;");
        jobject listener = JNI.EnvGlobal->CallStaticObjectMethod(listener_clazz, new_listener,ctx,obj, id);
        jmethodID set_onclicklistener = JNI.EnvGlobal->GetMethodID(CompoundButtonClass, "setOnCheckedChangeListener","(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V");
        JNI.EnvGlobal->CallVoidMethod(obj, set_onclicklistener, listener);
        JNI.EnvGlobal->DeleteLocalRef(CompoundButtonClass);
        JNI.EnvGlobal->DeleteLocalRef(listener_clazz);
    }
}OnCheckedChangeListener;

struct {
    struct {
        jobject SRC_ATOP() {
            jclass PorterDuffClass = JNI.EnvGlobal->FindClass("android/graphics/PorterDuff$Mode");
            jfieldID SRC_ATOPID = JNI.EnvGlobal->GetStaticFieldID(PorterDuffClass, "SRC_ATOP","Landroid/graphics/PorterDuff$Mode;");
            return JNI.EnvGlobal->GetStaticObjectField(PorterDuffClass,SRC_ATOPID);
        }
        jobject MULTIPLY(){
            jclass PorterDuffClass = JNI.EnvGlobal->FindClass("android/graphics/PorterDuff$Mode");
            jfieldID MULTIPLYID = JNI.EnvGlobal->GetStaticFieldID(PorterDuffClass, "MULTIPLY","Landroid/graphics/PorterDuff$Mode;");
            return JNI.EnvGlobal->GetStaticObjectField(PorterDuffClass,MULTIPLYID);
        }
    }Mode;
}PorterDuff;

struct {
    jobject getButtonDrawable(jobject obj) {
        jclass CompoundButtonClass = JNI.EnvGlobal->FindClass("android/widget/CompoundButton");
        jmethodID getButtonDrawableID = JNI.EnvGlobal->GetMethodID(CompoundButtonClass, "getButtonDrawable","()Landroid/graphics/drawable/Drawable;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(obj, getButtonDrawableID));
    }
}CompoundButton;

struct {
    void setColorFilter(jobject Drawable, int color, jobject mode) {
        jclass DrawableClass = JNI.EnvGlobal->FindClass("android/graphics/drawable/Drawable");
        jmethodID setColorFilterID = JNI.EnvGlobal->GetMethodID(DrawableClass, "setColorFilter","(ILandroid/graphics/PorterDuff$Mode;)V");
        JNI.EnvGlobal->CallVoidMethod(Drawable,setColorFilterID,color,mode);
        JNI.EnvGlobal->DeleteLocalRef(DrawableClass);
    }
}Drawable;

struct {
    jobject CheckBox(JNIEnv *env, jobject ctx) {
        jclass CheckBoxClass = env->FindClass("android/widget/CheckBox");
        jmethodID TextViewID = env->GetMethodID(CheckBoxClass, "<init>", "(Landroid/content/Context;)V");
        return env->NewGlobalRef(env->NewObject(CheckBoxClass, TextViewID, ctx));
    }
}CheckBox;

struct {
    jboolean canDrawOverlays(jobject ctx) {
        jclass Settigs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/provider/Settings"));
        jmethodID canDrawOverlaysID = JNI.EnvGlobal->GetStaticMethodID(Settigs, AY_OBFUSCATE("canDrawOverlays"), AY_OBFUSCATE("(Landroid/content/Context;)Z"));
        return JNI.EnvGlobal->CallStaticBooleanMethod(Settigs, canDrawOverlaysID, ctx);
    }
}Settings;

struct {
    void startActivityForResult(jobject ctx, jobject intent, jint requestCode) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jmethodID startActivityForResultID = JNI.EnvGlobal->GetMethodID(ActivityClass,AY_OBFUSCATE("startActivityForResult"),AY_OBFUSCATE("(Landroid/content/Intent;I)V"));
        JNI.EnvGlobal->CallVoidMethod(ctx,startActivityForResultID,intent,requestCode);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
    void startActivity(jobject ctx, jobject intent) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jmethodID startActivity = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("startActivity"), AY_OBFUSCATE("(Landroid/content/Intent;)V"));
        JNI.EnvGlobal->CallVoidMethod(ctx, startActivity, intent);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
    void setRequestedOrientation(jobject thiz, int view) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jmethodID setContentView = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("setRequestedOrientation"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setContentView, view);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
    void setActivityFlags(jobject ctx, int flags, int mask) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jclass WindowClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/Window"));
        jmethodID getWindow = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("getWindow"), AY_OBFUSCATE("()Landroid/view/Window;"));
        jmethodID setFlags = JNI.EnvGlobal->GetMethodID(WindowClass, AY_OBFUSCATE("setFlags"), AY_OBFUSCATE("(II)V"));
        jobject teste2 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getWindow));
        JNI.EnvGlobal->CallVoidMethod(teste2, setFlags, flags, mask);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
        JNI.EnvGlobal->DeleteLocalRef(WindowClass);
    }
    void setContentView(jobject thiz, jobject view) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jmethodID setContentView = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("setContentView"), AY_OBFUSCATE("(Landroid/view/View;)V"));
        JNI.EnvGlobal->CallVoidMethod(thiz, setContentView, view);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
    void setSystemUiVisibility(jobject ctx, int flags) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/app/Activity"));
        jclass WindowClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/Window"));
        jclass ViewClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/view/View"));
        jmethodID getWindow = JNI.EnvGlobal->GetMethodID(ActivityClass, AY_OBFUSCATE("getWindow"), AY_OBFUSCATE("()Landroid/view/Window;"));
        jmethodID getDecorView = JNI.EnvGlobal->GetMethodID(WindowClass, AY_OBFUSCATE("getDecorView"), AY_OBFUSCATE("()Landroid/view/View;"));
        jmethodID setSystemUiVisibility = JNI.EnvGlobal->GetMethodID(ViewClass, AY_OBFUSCATE("setSystemUiVisibility"), AY_OBFUSCATE("(I)V"));
        jobject teste1 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(ctx, getWindow));
        jobject teste2 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(teste1, getDecorView));
        JNI.EnvGlobal->CallVoidMethod(teste2,setSystemUiVisibility, flags);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
        JNI.EnvGlobal->DeleteLocalRef(WindowClass);
        JNI.EnvGlobal->DeleteLocalRef(ViewClass);
    }
    void requestWindowFeature(jobject ctx, jint id) {
        jclass ActivityClass = JNI.EnvGlobal->FindClass("android/app/Activity");
        jmethodID requestWindowFeatureID = JNI.EnvGlobal->GetMethodID(ActivityClass, "requestWindowFeature","(I)Z");
        JNI.EnvGlobal->CallBooleanMethod(ctx, requestWindowFeatureID, id);
        JNI.EnvGlobal->DeleteLocalRef(ActivityClass);
    }
}Activity;

struct {
    jobject Intent(const char *action, jobject uri) {
        jclass intentclass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/Intent"));
        jmethodID newIntent = JNI.EnvGlobal->GetMethodID(intentclass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Ljava/lang/String;Landroid/net/Uri;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(intentclass, newIntent, JNI.EnvGlobal->NewStringUTF(action),uri));
    }
    jobject Intent(jobject packageContext, jclass StartClass) {
        jclass intentclass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/Intent"));
        jmethodID newIntent = JNI.EnvGlobal->GetMethodID(intentclass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;Ljava/lang/Class;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(intentclass, newIntent,packageContext,StartClass));
    }
}Intent;

struct {
    jobject parse(const char *uriString) {
        jclass UriClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/net/Uri"));
        jmethodID Parce = JNI.EnvGlobal->GetStaticMethodID(UriClass, AY_OBFUSCATE("parse"), AY_OBFUSCATE("(Ljava/lang/String;)Landroid/net/Uri;"));
        return JNI.EnvGlobal->CallStaticObjectMethod(UriClass, Parce, JNI.EnvGlobal->NewStringUTF(uriString));
    }
}Uri;

struct {
    jobject EditText(jobject ctx) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID EditTextID = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(EditTextClass, EditTextID, ctx));
    }

    void setLayoutParams(jobject LinearLayout, jobject MainParams) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID setLayoutParams = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("setLayoutParams") ,AY_OBFUSCATE("(Landroid/view/ViewGroup$LayoutParams;)V"));
        JNI.EnvGlobal->CallVoidMethod(LinearLayout, setLayoutParams, MainParams);
        JNI.EnvGlobal->DeleteLocalRef(EditTextClass);
    }

    void setHint(jobject EditText, const char* Text) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID setHint = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("setHint"), AY_OBFUSCATE("(Ljava/lang/CharSequence;)V"));
        JNI.EnvGlobal->CallVoidMethod(EditText, setHint, JNI.EnvGlobal->NewStringUTF(Text));
        JNI.EnvGlobal->DeleteLocalRef(EditTextClass);
    }

    void setTextColor(jobject TexttView, int Color) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID setTextColor = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("setTextColor"), AY_OBFUSCATE("(I)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView, setTextColor, Color);
        JNI.EnvGlobal->DeleteLocalRef(EditTextClass);
    }

    void setTextSize(jobject TexttView, int TypedValue, float size) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID setTextSize = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("setTextSize"), AY_OBFUSCATE("(IF)V"));
        JNI.EnvGlobal->CallVoidMethod(TexttView,setTextSize, TypedValue, size);
        JNI.EnvGlobal->DeleteLocalRef(EditTextClass);
    }
    jobject toString(jobject text) {
        jclass Object = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/Object"));
        jmethodID toString = JNI.EnvGlobal->GetMethodID(Object,AY_OBFUSCATE("toString"), AY_OBFUSCATE("()Ljava/lang/String;"));
        return JNI.EnvGlobal->CallObjectMethod(text, toString);
    }
    jstring getText(jobject ctx) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID getTextID = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("getText"), AY_OBFUSCATE("()Landroid/text/Editable;"));
        jobject teste1 = JNI.EnvGlobal->CallObjectMethod(ctx, getTextID);
        return (jstring)toString(teste1);
    }
    jstring getText2(jobject editText)
    {
        // Obtém a classe EditText
        jclass editTextClass = JNI.EnvGlobal->FindClass(OBFUSCATE("android/widget/EditText")); //Jni::env->GetObjectClass(editText);
        // Obtém o método getText da classe EditText
        jmethodID getTextMethod = JNI.EnvGlobal->GetMethodID(editTextClass, "getText", "()Ljava/lang/CharSequence;");
        // Chama o método getText e armazena o resultado em uma variável
        jobject text = JNI.EnvGlobal->CallObjectMethod(editText, getTextMethod);
        // Converte o resultado para uma string e retorna o resultado
        return (jstring) JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(text, JNI.EnvGlobal->GetMethodID(JNI.EnvGlobal->GetObjectClass(text), "toString", "()Ljava/lang/String;")));
    }

    jstring getText3(jobject Textview)
    {
        jclass TextViewClass = JNI.EnvGlobal->FindClass("android/widget/TextView");
        jmethodID getTextMethod = JNI.EnvGlobal->GetMethodID(TextViewClass, "getText", "()Ljava/lang/CharSequence;");
        jobject text = JNI.EnvGlobal->CallObjectMethod(Textview, getTextMethod);
        return (jstring) JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(text, JNI.EnvGlobal->GetMethodID(JNI.EnvGlobal->GetObjectClass(text), "toString", "()Ljava/lang/String;")));
    }
    std::string getTextstd(jobject ctx) {
        jclass EditTextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/EditText"));
        jmethodID getTextID = JNI.EnvGlobal->GetMethodID(EditTextClass, AY_OBFUSCATE("getText"), AY_OBFUSCATE("()Landroid/text/Editable;"));
        jclass Object = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/Object"));
        jmethodID toString = JNI.EnvGlobal->GetMethodID(Object,AY_OBFUSCATE("toString"), AY_OBFUSCATE("()Ljava/lang/String;"));
        jobject teste1 = JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod((jobject)ctx, getTextID));
        jstring teste2 = (jstring)JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(teste1, toString));
        return JNI.EnvGlobal->GetStringUTFChars(teste2,0);
    }
}EditText;

void startPatcher(jobject ctx, bool isStatus){
    if (Build.VERSION.SDK_INT() < 23 || Settings.canDrawOverlays(ctx)) {
        if(isStatus) {
            ContextWrapper.startService(ctx,Intent.Intent(ctx,JNI.EnvGlobal->FindClass("com/purpou/patcher/Floater")));
            return;
        } else {
            exit(0);
            return;
        }
    } else {
        std::stringstream pkgg;
        pkgg << AY_OBFUSCATE("package:");
        pkgg << ContextWrapper.getPackageName(ctx);
        std::string pakg = pkgg.str();
        Activity.startActivityForResult(ctx,Intent.Intent(AY_OBFUSCATE("android.settings.action.MANAGE_OVERLAY_PERMISSION"),Uri.parse(pakg.c_str())),123);
    }
}

jobjectArray teste2(jstring user, jstring pass) {
    jobjectArray result;

    const char *suCmd[] = {JNI.EnvGlobal->GetStringUTFChars(user,0),JNI.EnvGlobal->GetStringUTFChars(pass,0)};

    size_t LenghtArray = sizeof(suCmd) / sizeof(suCmd[0]);
    result = (jobjectArray) JNI.EnvGlobal->NewObjectArray(LenghtArray, JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/String")),JNI.EnvGlobal->NewStringUTF(""));

    for (int i = 0; i < LenghtArray; i++) {
        JNI.EnvGlobal->SetObjectArrayElement(result, i, JNI.EnvGlobal->NewStringUTF(suCmd[i]));
    }
    return (result);
}

struct {
    jobject execute(jobject TaskRunner) {
        jclass AsyncTaskClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/os/AsyncTask"));
        jmethodID executeID = JNI.EnvGlobal->GetMethodID(AsyncTaskClass, AY_OBFUSCATE("execute"), AY_OBFUSCATE("([Ljava/lang/Object;)Landroid/os/AsyncTask;"));
        return JNI.EnvGlobal->CallObjectMethod(TaskRunner,executeID,static_cast<jobject>(NULL));
    }
}AsyncTask;

struct {
    jobject JSONObject() {
        jclass dataobjs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID datacons = JNI.EnvGlobal->GetMethodID(dataobjs, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("()V"));
        return JNI.EnvGlobal->NewObject(dataobjs, datacons);
    }
    jobject JSONObject(jstring str) {
        jclass dataobjs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID datacons = JNI.EnvGlobal->GetMethodID(dataobjs, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Ljava/lang/String;)V"));
        return JNI.EnvGlobal->NewObject(dataobjs, datacons, str);
    }
    jobject put(jobject data, const char *name, jstring value) {
        jclass dataobjs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID put1data = JNI.EnvGlobal->GetMethodID(dataobjs, AY_OBFUSCATE("put"),AY_OBFUSCATE("(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;"));
        return JNI.EnvGlobal->CallObjectMethod(data, put1data, JNI.EnvGlobal->NewStringUTF(name), value);
    }
    jstring toString(jobject json) {
        jclass dataobjs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID tostringdata = JNI.EnvGlobal->GetMethodID(dataobjs, AY_OBFUSCATE("toString"), AY_OBFUSCATE("()Ljava/lang/String;"));
        jstring datastring = (jstring) JNI.EnvGlobal->CallObjectMethod(json, tostringdata);
        return datastring;
    }
    jobject get(jobject data, const char *name) {
        jclass dataobjs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("org/json/JSONObject"));
        jmethodID getID = JNI.EnvGlobal->GetMethodID(dataobjs, AY_OBFUSCATE("get"),AY_OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
        return JNI.EnvGlobal->CallObjectMethod(data, getID, JNI.EnvGlobal->NewStringUTF(name));
    }
}JSONObject;

struct {
    jstring toString(jobjectArray List) {
        jclass ArraysClass = JNI.EnvGlobal->FindClass("java/util/Arrays");
        jmethodID tostringdata = JNI.EnvGlobal->GetStaticMethodID(ArraysClass, "toString", "([Ljava/lang/Object;)Ljava/lang/String;");
        return (jstring) JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallStaticObjectMethod(ArraysClass, tostringdata, List));
    }
}Arrays;

struct {
    jstring toString(jobject obj) {
        jclass Object = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/Object"));
        jmethodID toString = JNI.EnvGlobal->GetMethodID(Object,AY_OBFUSCATE("toString"), AY_OBFUSCATE("()Ljava/lang/String;"));
        jstring datastring = (jstring) JNI.EnvGlobal->CallObjectMethod(obj, toString);
        return datastring;
    }
}Object;

struct {
    jboolean startsWith(jstring obj, jstring prefix) {
        jclass StringClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/String"));
        jmethodID startsWithID = JNI.EnvGlobal->GetMethodID(StringClass, AY_OBFUSCATE("startsWith"),AY_OBFUSCATE("(Ljava/lang/String;)Z"));
        return JNI.EnvGlobal->CallBooleanMethod(obj,startsWithID,prefix);
    }
    jbyteArray getBytes(jstring plainText, jobject charset) {
        jclass AuthClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/String"));
        jmethodID getBytesID = JNI.EnvGlobal->GetMethodID(AuthClass, AY_OBFUSCATE("getBytes"),AY_OBFUSCATE("(Ljava/nio/charset/Charset;)[B"));
        return (jbyteArray)JNI.EnvGlobal->CallObjectMethod(plainText,getBytesID,charset);
    }
    jboolean isEmpty(jobject obj) {
        jclass StringClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/String"));
        jmethodID isEmpty = JNI.EnvGlobal->GetMethodID(StringClass,AY_OBFUSCATE("isEmpty"), AY_OBFUSCATE("()Z"));
        jboolean status = JNI.EnvGlobal->CallBooleanMethod(obj, isEmpty);
        return status;
    }
    jboolean equals(jobject obj, const char *str) {
        jclass StringClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/lang/String"));
        jmethodID equals = JNI.EnvGlobal->GetMethodID(StringClass,AY_OBFUSCATE("equals"), AY_OBFUSCATE("(Ljava/lang/Object;)Z"));
        jboolean status = JNI.EnvGlobal->CallBooleanMethod(obj, equals, JNI.EnvGlobal->NewStringUTF(str));
        return status;
    }
    jboolean contains(jstring obj, const char *str) {
        jclass StringClass = JNI.EnvGlobal->FindClass("java/lang/String");
        jmethodID containsID = JNI.EnvGlobal->GetMethodID(StringClass,"contains","(Ljava/lang/CharSequence;)Z");
        jboolean contains = JNI.EnvGlobal->CallBooleanMethod(obj, containsID, JNI.EnvGlobal->NewStringUTF(str));
        return contains;
    }
}String;


struct {
    jobject getInstance(const char *transformation) {
        jclass Cipher = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("javax/crypto/Cipher"));
        jmethodID getInstanceID = JNI.EnvGlobal->GetStaticMethodID(Cipher, AY_OBFUSCATE("getInstance"), AY_OBFUSCATE("(Ljava/lang/String;)Ljavax/crypto/Cipher;"));
        return JNI.EnvGlobal->CallStaticObjectMethod(Cipher,getInstanceID,JNI.EnvGlobal->NewStringUTF(transformation));
    }
    void init(jobject cipher, jint opmode, jobject key) {
        jclass Cipher = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("javax/crypto/Cipher"));
        jmethodID initID = JNI.EnvGlobal->GetMethodID(Cipher, AY_OBFUSCATE("init"), AY_OBFUSCATE("(ILjava/security/Key;)V"));
        JNI.EnvGlobal->CallVoidMethod(cipher,initID,opmode,key);
    }
    jbyteArray doFinal(jobject encryptCipher, jbyteArray byte) {
        jclass Cipher = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("javax/crypto/Cipher"));
        jmethodID doFinalID = JNI.EnvGlobal->GetMethodID(Cipher, AY_OBFUSCATE("doFinal"),AY_OBFUSCATE("([B)[B"));
        return (jbyteArray)JNI.EnvGlobal->CallObjectMethod(encryptCipher,doFinalID,byte);
    }
}Cipher;

struct {
    jobject UTF_8() {
        jclass StandardCharsets = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/nio/charset/StandardCharsets"));
        jfieldID UTF_8 = JNI.EnvGlobal->GetStaticFieldID(StandardCharsets, AY_OBFUSCATE("UTF_8"), AY_OBFUSCATE("Ljava/nio/charset/Charset;"));
        return JNI.EnvGlobal->GetStaticObjectField(StandardCharsets,UTF_8);
    }
}StandardCharsets;

struct {
    jobject X509EncodedKeySpec(jbyteArray keyBytes) {
        jclass EncodedKeySpecClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/spec/X509EncodedKeySpec"));
        jmethodID newX509EncodedKeySpec = JNI.EnvGlobal->GetMethodID(EncodedKeySpecClass, AY_OBFUSCATE("<init>"),AY_OBFUSCATE("([B)V"));
        return JNI.EnvGlobal->NewObject(EncodedKeySpecClass,newX509EncodedKeySpec,keyBytes);
    }
}X509EncodedKeySpec;

struct {
    jobject getInstance(const char *algorithm) {
        jclass KeyFactoryClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/KeyFactory"));
        jmethodID getInstanceID = JNI.EnvGlobal->GetStaticMethodID(KeyFactoryClass, AY_OBFUSCATE("getInstance"),AY_OBFUSCATE("(Ljava/lang/String;)Ljava/security/KeyFactory;"));
        return JNI.EnvGlobal->CallStaticObjectMethod(KeyFactoryClass,getInstanceID,JNI.EnvGlobal->NewStringUTF(algorithm));
    }
    jobject generatePublic(jobject KeyFactory, jobject keySpec) {
        jclass KeyFactoryClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/KeyFactory"));
        jmethodID generatePublicID = JNI.EnvGlobal->GetMethodID(KeyFactoryClass, AY_OBFUSCATE("generatePublic"),AY_OBFUSCATE("(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;"));
        return JNI.EnvGlobal->CallObjectMethod(KeyFactory,generatePublicID,keySpec);
    }
}KeyFactory;

struct {
    jobject getInstance(const char *algorithm) {
        jclass MessageDigest = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/MessageDigest"));
        jmethodID getInstance = JNI.EnvGlobal->GetStaticMethodID(MessageDigest, AY_OBFUSCATE("getInstance"), AY_OBFUSCATE("(Ljava/lang/String;)Ljava/security/MessageDigest;"));
        return JNI.EnvGlobal->CallStaticObjectMethod(MessageDigest,getInstance,JNI.EnvGlobal->NewStringUTF(algorithm));
    }
    void reset(jobject md) {
        jclass MessageDigest = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/MessageDigest"));
        jmethodID reset = JNI.EnvGlobal->GetMethodID(MessageDigest, AY_OBFUSCATE("reset"), AY_OBFUSCATE("()V"));
        JNI.EnvGlobal->CallVoidMethod(md,reset);
        JNI.EnvGlobal->DeleteLocalRef(MessageDigest);
    }
    void update(jobject md, jbyteArray input) {
        jclass MessageDigest = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/MessageDigest"));
        jmethodID update = JNI.EnvGlobal->GetMethodID(MessageDigest, AY_OBFUSCATE("update"), AY_OBFUSCATE("([B)V"));
        JNI.EnvGlobal->CallVoidMethod(md,update,input);
        JNI.EnvGlobal->DeleteLocalRef(MessageDigest);
    }
    jobject digest(jobject data) {
        jclass MessageDigest = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/MessageDigest"));
        jmethodID getBytes = JNI.EnvGlobal->GetMethodID(MessageDigest, AY_OBFUSCATE("digest"), AY_OBFUSCATE("()[B"));
        return JNI.EnvGlobal->CallObjectMethod(data,getBytes);
    }
}MessageDigest;

struct {
    jobject GetSharedPreferences(jobject ctx) {
        jclass cls_ContextWrapper = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/ContextWrapper"));
        jclass cls_Context = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/Context"));
        jmethodID mid_getSharedPreferences = JNI.EnvGlobal->GetMethodID(cls_ContextWrapper,AY_OBFUSCATE("getSharedPreferences"), AY_OBFUSCATE("(Ljava/lang/String;I)Landroid/content/SharedPreferences;"));
        jfieldID fid_MODE_PRIVATE = JNI.EnvGlobal->GetStaticFieldID(cls_Context, AY_OBFUSCATE("MODE_PRIVATE"), AY_OBFUSCATE("I"));
        jint int_MODE_PRIVATE = JNI.EnvGlobal->GetStaticIntField(cls_Context, fid_MODE_PRIVATE);
        jobject obj_sharedPreferences = JNI.EnvGlobal->CallObjectMethod(ctx,mid_getSharedPreferences, JNI.EnvGlobal->NewStringUTF(AY_OBFUSCATE("com.brmods.login_preferences")), int_MODE_PRIVATE);
        return obj_sharedPreferences;
    }

    jstring read(jobject ctx, const char *what, const char *defaultString) {
        jclass SharedPrefs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/SharedPreferences"));
        jmethodID getStringID = JNI.EnvGlobal->GetMethodID(SharedPrefs,AY_OBFUSCATE("getString"), AY_OBFUSCATE("(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;"));
        return (jstring)JNI.EnvGlobal->CallObjectMethod(GetSharedPreferences(ctx),getStringID,JNI.EnvGlobal->NewStringUTF(what),JNI.EnvGlobal->NewStringUTF(defaultString));
    }

    void write(jobject ctx,const char *where, jstring what) {
        jclass SharedPrefs = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/SharedPreferences"));
        jclass Editor = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/SharedPreferences$Editor"));
        jmethodID editID = JNI.EnvGlobal->GetMethodID(SharedPrefs,AY_OBFUSCATE("edit"),AY_OBFUSCATE("()Landroid/content/SharedPreferences$Editor;"));
        jmethodID apply = JNI.EnvGlobal->GetMethodID(Editor,AY_OBFUSCATE("apply"), AY_OBFUSCATE("()V"));
        jobject edit = JNI.EnvGlobal->CallObjectMethod(GetSharedPreferences(ctx),editID);
        jmethodID putStringID = JNI.EnvGlobal->GetMethodID(Editor,AY_OBFUSCATE("putString"),AY_OBFUSCATE("(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;"));
        jobject putString = JNI.EnvGlobal->CallObjectMethod(edit,putStringID,JNI.EnvGlobal->NewStringUTF(where),what);
        JNI.EnvGlobal->CallVoidMethod(putString,apply);
        JNI.EnvGlobal->DeleteLocalRef(SharedPrefs);
        JNI.EnvGlobal->DeleteLocalRef(Editor);
    }
}Prefs;

struct {
    jobject getPublicKey(jbyteArray keyBytes) {
        jobject spec = X509EncodedKeySpec.X509EncodedKeySpec(keyBytes);
        jobject kf = KeyFactory.getInstance(AY_OBFUSCATE("RSA"));
        return KeyFactory.generatePublic(kf,spec);
    }

    jstring encrypt(jstring plainText, jbyteArray keyBytes) {
        jobject encryptCipher = Cipher.getInstance(AY_OBFUSCATE("RSA/ECB/PKCS1Padding"));
        Cipher.init(encryptCipher,1,getPublicKey(keyBytes));
        return Base64.toBase64(Cipher.doFinal(encryptCipher, String.getBytes(plainText, StandardCharsets.UTF_8())));
    }
    jobject getInstance(const char *algorithm) {
        jclass SignatureClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/Signature"));
        jmethodID AuthID = JNI.EnvGlobal->GetStaticMethodID(SignatureClass, AY_OBFUSCATE("getInstance"), AY_OBFUSCATE("(Ljava/lang/String;)Ljava/security/Signature;"));
        return JNI.EnvGlobal->CallStaticObjectMethod(SignatureClass,AuthID,JNI.EnvGlobal->NewStringUTF(algorithm));
    }

    void update(jobject sign, jobject bytes) {
        jclass SignatureClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/Signature"));
        jmethodID updateID = JNI.EnvGlobal->GetMethodID(SignatureClass, AY_OBFUSCATE("update"), AY_OBFUSCATE("([B)V"));
        JNI.EnvGlobal->CallVoidMethod(sign,updateID,bytes);
        JNI.EnvGlobal->DeleteLocalRef(SignatureClass);
    }

    void initVerify(jobject sign, jobject publickey) {
        jclass SignatureClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/Signature"));
        jmethodID initVerifyID = JNI.EnvGlobal->GetMethodID(SignatureClass, AY_OBFUSCATE("initVerify"), AY_OBFUSCATE("(Ljava/security/PublicKey;)V"));
        JNI.EnvGlobal->CallVoidMethod(sign,initVerifyID,publickey);
        JNI.EnvGlobal->DeleteLocalRef(SignatureClass);
    }

    jbyteArray decode(jstring str, int frags) {
        jclass Base64class = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/util/Base64"));
        jmethodID decodeID = JNI.EnvGlobal->GetStaticMethodID(Base64class,AY_OBFUSCATE("decode"), AY_OBFUSCATE("(Ljava/lang/String;I)[B"));
        return (jbyteArray)JNI.EnvGlobal->CallStaticObjectMethod(Base64class,decodeID,str,frags);
    }

    jbyteArray fromBase64(jstring s) {
        return decode(s,2);
    }

    jboolean verify(jobject sign, jbyteArray signature) {
        jclass SignatureClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("java/security/Signature"));
        jmethodID verifyID = JNI.EnvGlobal->GetMethodID(SignatureClass, AY_OBFUSCATE("verify"), AY_OBFUSCATE("([B)Z"));
        return JNI.EnvGlobal->CallBooleanMethod(sign,verifyID,signature);
    }

    jboolean verifySign(jstring plainText, jstring signature, jbyteArray keyBytes) {
        jobject publicSignature = getInstance(AY_OBFUSCATE("SHA256withRSA"));
        jobject PublicKey = getPublicKey(keyBytes);
        initVerify(publicSignature,PublicKey);
        jbyteArray GetBytes = String.getBytes(plainText,StandardCharsets.UTF_8());
        update(publicSignature,GetBytes);
        return verify(publicSignature,fromBase64(signature));
    }


    jobject getSystemService(jobject ctx, const char * Context) {
        jclass ContextClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/content/Context"));
        jmethodID getSystemServiceID = JNI.EnvGlobal->GetMethodID(ContextClass, AY_OBFUSCATE("getSystemService"), AY_OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
        return JNI.EnvGlobal->CallObjectMethod(ctx,getSystemServiceID,JNI.EnvGlobal->NewStringUTF(Context));
    }
    jmethodID getActiveNetworkInfo() {
        jclass ConnectivityManagerClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/net/ConnectivityManager"));
        return JNI.EnvGlobal->GetMethodID(ConnectivityManagerClass, AY_OBFUSCATE("getActiveNetworkInfo"),AY_OBFUSCATE("()Landroid/net/NetworkInfo;"));
    }

    jboolean isConnected(jobject obj) {
        jclass NetworkInfoClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/net/NetworkInfo"));
        jmethodID isConnectedID = JNI.EnvGlobal->GetMethodID(NetworkInfoClass, AY_OBFUSCATE("isConnected"), AY_OBFUSCATE("()Z"));
        return JNI.EnvGlobal->CallBooleanMethod(obj,isConnectedID);
    }
    jboolean isInternetAvailable(jobject ctx) {
        jobject activeNetworkInfoID = getSystemService(ctx,AY_OBFUSCATE("connectivity"));
        jobject activeNetworkInfo = JNI.EnvGlobal->CallObjectMethod(activeNetworkInfoID,getActiveNetworkInfo());
        return activeNetworkInfo != nullptr && isConnected(activeNetworkInfo);
    }
}Utils;

/*jstring getDeviceName() {
    jstring manufacturer = Build.MANUFACTURER();
    jstring model = Build.MODEL();

    if(String.startsWith(model,manufacturer)) {
        return model;
    }
    std::stringstream zx;
    zx << JNI.EnvGlobal->GetStringUTFChars(manufacturer, 0);
    zx << (" ");
    zx << JNI.EnvGlobal->GetStringUTFChars(model, 0);
    std::string zax = zx.str();
    return JNI.EnvGlobal->NewStringUTF(zax.c_str());
};*/

jstring getDeviceName(JNIEnv *env);
jstring getDeviceName(JNIEnv *env){
    jclass BuILDOS = env->FindClass(("android/os/Build"));
    jfieldID manofacturerid = env->GetStaticFieldID(BuILDOS, ("MANUFACTURER"), ("Ljava/lang/String;"));
    jstring MANUFACTURERSTRING = (jstring)env->GetStaticObjectField(BuILDOS, manofacturerid);

    jfieldID modelid = env->GetStaticFieldID(BuILDOS, ("MODEL"), ("Ljava/lang/String;"));
    jstring MODELSTRING = (jstring)env->GetStaticObjectField(BuILDOS, modelid);

    jclass stringclass = env->FindClass(("java/lang/String"));
    jmethodID stringconstr = env->GetMethodID(stringclass, ("<init>"), ("(Ljava/lang/String;)V"));
    jobject mainstring =  env->NewObject(stringclass, stringconstr, MODELSTRING);

    jmethodID startwhisid = env->GetMethodID(stringclass, ("startsWith"), ("(Ljava/lang/String;)Z"));

    jboolean jboolean1 = env->CallBooleanMethod(mainstring, startwhisid, MANUFACTURERSTRING);

    if (jboolean1){
        return MODELSTRING;
    } else {
        std::stringstream zx;
        zx << env->GetStringUTFChars(MANUFACTURERSTRING, 0);
        zx << (" ");
        zx << env->GetStringUTFChars(MODELSTRING, 0);
        std::string zax = zx.str();
        return env->NewStringUTF(zax.c_str());
    }
}

jstring getUniqueId(jobject ctx);
jstring getUniqueId(jobject ctx){

    jclass Secureclass = JNI.EnvGlobal->FindClass("android/provider/Settings$Secure");
    jclass ctxclass = JNI.EnvGlobal->FindClass(("android/content/Context"));
    jmethodID getmetodouiie = JNI.EnvGlobal->GetMethodID(ctxclass, ("getContentResolver"), ("()Landroid/content/ContentResolver;"));
    jobject getContentResolver = JNI.EnvGlobal->CallObjectMethod(ctx, getmetodouiie);

    jmethodID getstringid = JNI.EnvGlobal->GetStaticMethodID(Secureclass, ("getString"), ("(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;"));

    jclass BuILDOS = JNI.EnvGlobal->FindClass(("android/os/Build"));
    jfieldID harid = JNI.EnvGlobal->GetStaticFieldID(BuILDOS, ("HARDWARE"), ("Ljava/lang/String;"));
    jstring HARDWARESTRING = (jstring)JNI.EnvGlobal->GetStaticObjectField(BuILDOS, harid);

    jfieldID androidididi = JNI.EnvGlobal->GetStaticFieldID(Secureclass, ("ANDROID_ID"), ("Ljava/lang/String;"));

    jstring android_id = (jstring) JNI.EnvGlobal->GetStaticObjectField(Secureclass, androidididi);

    jstring getStrigSecure = (jstring) JNI.EnvGlobal->CallStaticObjectMethod(Secureclass, getstringid, getContentResolver, android_id);

    std::stringstream zx;
    zx << JNI.EnvGlobal->GetStringUTFChars(getDeviceName(JNI.EnvGlobal), 0);
    zx << JNI.EnvGlobal->GetStringUTFChars(getStrigSecure, 0);
    zx << JNI.EnvGlobal->GetStringUTFChars(HARDWARESTRING, 0);
    std::string zax = zx.str();

    jclass stringclass = JNI.EnvGlobal->FindClass(("java/lang/String"));
    jmethodID stringconstr = JNI.EnvGlobal->GetMethodID(stringclass, ("<init>"), ("(Ljava/lang/String;)V"));
    jobject mainstring =  JNI.EnvGlobal->NewObject(stringclass, stringconstr, JNI.EnvGlobal->NewStringUTF(zax.c_str()));

    jmethodID replace = JNI.EnvGlobal->GetMethodID(stringclass, ("replace"), ("(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;"));
    JNI.EnvGlobal->CallObjectMethod(mainstring, replace, JNI.EnvGlobal->NewStringUTF((" ")),JNI.EnvGlobal->NewStringUTF(("")));

    jmethodID jbytessss = JNI.EnvGlobal->GetMethodID(stringclass, ("getBytes"), ("()[B"));
    jbyteArray bytesstruing = (jbyteArray)JNI.EnvGlobal->CallObjectMethod(mainstring, jbytessss);

    jclass UIDDDDCLASS = JNI.EnvGlobal->FindClass(("java/util/UUID"));
    jmethodID nameUIDDDD = JNI.EnvGlobal->GetStaticMethodID(UIDDDDCLASS, ("nameUUIDFromBytes"), ("([B)Ljava/util/UUID;"));
    jobject uidstring = JNI.EnvGlobal->CallStaticObjectMethod(UIDDDDCLASS, nameUIDDDD, bytesstruing);

    jmethodID ofvalueid = JNI.EnvGlobal->GetStaticMethodID(stringclass, ("valueOf"), ("(Ljava/lang/Object;)Ljava/lang/String;"));

    jmethodID stringconstr2 = JNI.EnvGlobal->GetMethodID(stringclass, ("<init>"), ("(Ljava/lang/String;)V"));
    jobject mainstring2 =  JNI.EnvGlobal->NewObject(stringclass, stringconstr2, JNI.EnvGlobal->CallStaticObjectMethod(stringclass, ofvalueid, uidstring));

    jmethodID replaceeee = JNI.EnvGlobal->GetMethodID(stringclass, ("replace"), ("(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;"));

    return (jstring)JNI.EnvGlobal->CallObjectMethod(mainstring2, replaceeee, JNI.EnvGlobal->NewStringUTF(("-")),JNI.EnvGlobal->NewStringUTF(("")));
}

struct {
    void Toast(jobject thiz, const char *text, int length) {
        jstring jstr = JNI.EnvGlobal->NewStringUTF(text);
        jclass toast = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID methodMakeText =JNI.EnvGlobal->GetStaticMethodID(toast,AY_OBFUSCATE("makeText"),AY_OBFUSCATE("(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;"));
        jobject toastobj = JNI.EnvGlobal->CallStaticObjectMethod(toast, methodMakeText,thiz, jstr, length);
        jmethodID methodShow = JNI.EnvGlobal->GetMethodID(toast, AY_OBFUSCATE("show"), AY_OBFUSCATE("()V"));
        JNI.EnvGlobal->CallVoidMethod(toastobj, methodShow);
        JNI.EnvGlobal->DeleteLocalRef(toast);
    }
    jobject Toast(jobject ctx){
        jclass ToastClass = JNI.EnvGlobal->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID ToastID = JNI.EnvGlobal->GetMethodID(ToastClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(ToastClass, ToastID, ctx));
    }
    void setDuration(JNIEnv *env, jobject toast, int duration)
    {
        jclass ToastClass = env->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID setGravity = env->GetMethodID(ToastClass, AY_OBFUSCATE("setDuration"), AY_OBFUSCATE("(I)V"));
        env->CallVoidMethod(toast, setGravity, duration);
        JNI.EnvGlobal->DeleteLocalRef(ToastClass);
    }

    void setView(JNIEnv *env, jobject toast, jobject view)
    {
        jclass ToastClass = env->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID setGravity = env->GetMethodID(ToastClass, AY_OBFUSCATE("setView"), AY_OBFUSCATE("(Landroid/view/View;)V"));
        env->CallVoidMethod(toast, setGravity, view);
        JNI.EnvGlobal->DeleteLocalRef(ToastClass);
    }

    void show(JNIEnv *env, jobject toast) {
        jclass ToastClass = env->FindClass(AY_OBFUSCATE("android/widget/Toast"));
        jmethodID setGravity = env->GetMethodID(ToastClass, AY_OBFUSCATE("show"), AY_OBFUSCATE("()V"));
        env->CallVoidMethod(toast, setGravity);
        JNI.EnvGlobal->DeleteLocalRef(ToastClass);
    }
}Toast;

struct {
    jobject DrawESP(jobject ctx) {
        jclass ESPViewClass = JNI.EnvGlobal->FindClass("com/brmods/loader/DrawESP");
        jmethodID ESPViewInit = JNI.EnvGlobal->GetMethodID(ESPViewClass, AY_OBFUSCATE("<init>"), AY_OBFUSCATE("(Landroid/content/Context;)V"));
        return JNI.EnvGlobal->NewObject(ESPViewClass, ESPViewInit, ctx);
    }
}Java;

void CustomToast(JNIEnv *env, const char *name, jobject ctx) {
    jobject ln = LinearLayout.LinearLayout(env,ctx);
    View.setPadding(ln, ConvertDP(ctx,12), ConvertDP(ctx,12),  ConvertDP(ctx,12),  ConvertDP(ctx,12));
    View.setAlpha(ln,0.9f);

    jobject mGrad = GradientDrawable.GradientDrawable(ctx);
    GradientDrawable.setColor(mGrad,Color.parseColor(env,AY_OBFUSCATE("#FFFFFF")));
    GradientDrawable.setCornerRadii(mGrad, ConvertDP(ctx,5),ConvertDP(ctx,5),ConvertDP(ctx,5),ConvertDP(ctx,5));
    LinearLayout.setBackground(ln,mGrad);

    jobject tv = TextView.TextView(env,ctx);
    jobject params = LinearLayout.LayoutParams(env,LayoutParams.WRAP_CONTENT,LayoutParams.MATCH_PARENT);
    LinearLayout.setLayoutParams(env,tv,params);
    TextView.setText(env,tv,name);
    TextView.setTextColor(env,tv,Color.parseColor(env,AY_OBFUSCATE("#000000")));

    ViewGroup.addView(JNI.EnvGlobal,ln,tv);

    jobject toast = Toast.Toast(ctx);
    Toast.setDuration(JNI.EnvGlobal,toast,ToastLength::LENGTH_LONG);
    Toast.setView(JNI.EnvGlobal,toast,ln);
    Toast.show(JNI.EnvGlobal,toast);
}

jint getLayoutType() {
    if (Build.VERSION.SDK_INT() >= 26)
    {
        return 2038;
    }
    if (Build.VERSION.SDK_INT() >= 24)
    {
        return 2002;
    }
    if (Build.VERSION.SDK_INT() >= 23)
    {
        return 2005;
    }
    return 2003;
}

struct {
    struct {
        struct {
            jobject Builder() {
                jclass BuilderClass = JNI.EnvGlobal->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
                jmethodID BuilderID = JNI.EnvGlobal->GetMethodID(BuilderClass,"<init>", "()V");
                return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(BuilderClass, BuilderID));
            }
            jobject permitAll(jobject builder) {
                jclass BuilderClass = JNI.EnvGlobal->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
                jmethodID permitAllID = JNI.EnvGlobal->GetMethodID(BuilderClass,"permitAll","()Landroid/os/StrictMode$ThreadPolicy$Builder;");
                return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(builder, permitAllID));;
            }
            jobject build(jobject permitAll) {
                jclass BuilderClass = JNI.EnvGlobal->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
                jmethodID buildID = JNI.EnvGlobal->GetMethodID(BuilderClass,"build","()Landroid/os/StrictMode$ThreadPolicy;");
                return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(permitAll, buildID));;
            }
        }Builder;
    }ThreadPolicy;

    void setThreadPolicy(jobject policy) {
        jclass StrictModeclass = JNI.EnvGlobal->FindClass("android/os/StrictMode");
        jmethodID setThreadPolicy = JNI.EnvGlobal->GetStaticMethodID(StrictModeclass,"setThreadPolicy","(Landroid/os/StrictMode$ThreadPolicy;)V");
        JNI.EnvGlobal->CallStaticVoidMethod(StrictModeclass,setThreadPolicy, policy);
        JNI.EnvGlobal->DeleteLocalRef(StrictModeclass);
    }
}StrictMode;

struct {
    jobject getInputStream(jobject urlConnection) {
        jclass httpcon = JNI.EnvGlobal->FindClass("java/net/HttpURLConnection");
        jmethodID impu = JNI.EnvGlobal->GetMethodID(httpcon, "getInputStream", "()Ljava/io/InputStream;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(urlConnection, impu));;
    }
}HttpURLConnection;

struct {
    jobject HttpURLConnection(const char *url) {
        jclass urlclass = JNI.EnvGlobal->FindClass("java/net/URL");
        jmethodID urlcontruc = JNI.EnvGlobal->GetMethodID(urlclass, "<init>", "(Ljava/lang/String;)V");
        jobject mainurl = JNI.EnvGlobal->NewObject(urlclass, urlcontruc, JNI.EnvGlobal->NewStringUTF(url));
        jmethodID teste = JNI.EnvGlobal->GetMethodID(urlclass,"openConnection","()Ljava/net/URLConnection;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(mainurl, teste));;
    }
}URL;

struct {
    jobject BufferedInputStream(jobject in) {
        jclass BufferedInputStreamClass = JNI.EnvGlobal->FindClass("java/io/BufferedInputStream");
        jmethodID BufferedInputStreamID = JNI.EnvGlobal->GetMethodID(BufferedInputStreamClass, "<init>", "(Ljava/io/InputStream;)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(BufferedInputStreamClass, BufferedInputStreamID,in));
    }
}BufferedInputStream;

struct {
    jobject InputStreamReader(jobject in, const char* utf) {
        jclass InputStreamReaderClass = JNI.EnvGlobal->FindClass("java/io/InputStreamReader");
        jmethodID InputStreamReaderID = JNI.EnvGlobal->GetMethodID(InputStreamReaderClass, "<init>", "(Ljava/io/InputStream;Ljava/lang/String;)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(InputStreamReaderClass, InputStreamReaderID,in, JNI.EnvGlobal->NewStringUTF(utf)));
    }
}InputStreamReader;

struct {
    jobject BufferedReader(jobject in, int sz) {
        jclass BufferedReaderClass = JNI.EnvGlobal->FindClass("java/io/BufferedReader");
        jmethodID BufferedReaderID = JNI.EnvGlobal->GetMethodID(BufferedReaderClass, "<init>", "(Ljava/io/Reader;I)V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(BufferedReaderClass, BufferedReaderID,in,sz));
    }
    jstring readLine(jobject in) {
        jclass BufferedReaderClass = JNI.EnvGlobal->FindClass("java/io/BufferedReader");
        jmethodID readLineID = JNI.EnvGlobal->GetMethodID(BufferedReaderClass, "readLine", "()Ljava/lang/String;");
        return (jstring)JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(in, readLineID));;
    }
}BufferedReader;

struct {
    jobject StringBuilder() {
        jclass StringBuilderClass = JNI.EnvGlobal->FindClass("java/lang/StringBuilder");
        jmethodID StringBuilderID = JNI.EnvGlobal->GetMethodID(StringBuilderClass, "<init>", "()V");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->NewObject(StringBuilderClass, StringBuilderID));
    }
    jobject append(jobject obj, jstring str) {
        jclass StringBuilderClass = JNI.EnvGlobal->FindClass("java/lang/StringBuilder");
        jmethodID appendID = JNI.EnvGlobal->GetMethodID(StringBuilderClass,"append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(obj, appendID,str));;
    }
    jstring toString(jobject obj) {
        jclass Object = JNI.EnvGlobal->FindClass("java/lang/StringBuilder");
        jmethodID toString = JNI.EnvGlobal->GetMethodID(Object,"toString", "()Ljava/lang/String;");
        return (jstring) JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(obj, toString));;
    }
}StringBuilder;

std::string jstringTostring(jstring jStr) {
    if (!jStr)
        return "";
    const jclass stringClass = JNI.EnvGlobal->GetObjectClass(jStr);
    const jmethodID getBytes = JNI.EnvGlobal->GetMethodID(stringClass, OBFUSCATE("getBytes"), OBFUSCATE("(Ljava/lang/String;)[B"));
    const jbyteArray stringJbytes = (jbyteArray) JNI.EnvGlobal->CallObjectMethod(jStr, getBytes, JNI.EnvGlobal->NewStringUTF(OBFUSCATE("UTF-8")));

    size_t length = (size_t) JNI.EnvGlobal->GetArrayLength(stringJbytes);
    jbyte* pBytes = JNI.EnvGlobal->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    JNI.EnvGlobal->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    JNI.EnvGlobal->DeleteLocalRef(stringJbytes);
    JNI.EnvGlobal->DeleteLocalRef(stringClass);
    return ret;
}
const char *getRequestURL(const char *url) {
    jobject policy = StrictMode.ThreadPolicy.Builder.build(StrictMode.ThreadPolicy.Builder.permitAll(StrictMode.ThreadPolicy.Builder.Builder()));
    StrictMode.setThreadPolicy(policy);

    jobject urlConnection = URL.HttpURLConnection(url);
    jobject in = BufferedInputStream.BufferedInputStream(HttpURLConnection.getInputStream(urlConnection));
    jobject reader = BufferedReader.BufferedReader(InputStreamReader.InputStreamReader(in,"UTF-8"),8);
    jobject sb = StringBuilder.StringBuilder();

    jstring line;
    while((line = BufferedReader.readLine(reader)) != nullptr) {
        StringBuilder.append(sb,line);
    }
    jstring str = StringBuilder.toString(sb);
    return JNI.EnvGlobal->GetStringUTFChars(str,0);
}

jboolean isSafeConnection() {
    jclass java_util_ArrayList  = JNI.EnvGlobal->FindClass(OBFUSCATE("java/util/ArrayList"));
    jmethodID java_util_ArrayList_size = JNI.EnvGlobal->GetMethodID (java_util_ArrayList, OBFUSCATE("size"), OBFUSCATE("()I"));
    jmethodID java_util_ArrayList_get  = JNI.EnvGlobal->GetMethodID(java_util_ArrayList, OBFUSCATE("get"), OBFUSCATE("(I)Ljava/lang/Object;"));
    jclass Collections = JNI.EnvGlobal->FindClass(OBFUSCATE("java/util/Collections"));
    jclass NetworkInterface = JNI.EnvGlobal->FindClass(OBFUSCATE("java/net/NetworkInterface"));

    jmethodID _getNetworkInterfaces = JNI.EnvGlobal->GetStaticMethodID(NetworkInterface, OBFUSCATE("getNetworkInterfaces"), OBFUSCATE("()Ljava/util/Enumeration;"));
    jobject interfaces = JNI.EnvGlobal->CallStaticObjectMethod(NetworkInterface, _getNetworkInterfaces);
    jmethodID _list = JNI.EnvGlobal->GetStaticMethodID(Collections, OBFUSCATE("list"), OBFUSCATE("(Ljava/util/Enumeration;)Ljava/util/ArrayList;"));
    jmethodID _isUp = JNI.EnvGlobal->GetMethodID(NetworkInterface, OBFUSCATE("isUp"), OBFUSCATE("()Z"));
    jmethodID _getName = JNI.EnvGlobal->GetMethodID(NetworkInterface, OBFUSCATE("getName"), OBFUSCATE("()Ljava/lang/String;"));

    jobject interfaces_asList = JNI.EnvGlobal->CallStaticObjectMethod(Collections, _list, interfaces);

    jint len = JNI.EnvGlobal->CallIntMethod(interfaces_asList,java_util_ArrayList_size );
    std::string name = "";
    for (jint i = 0; i < len; i++) {
        jobject network = JNI.EnvGlobal->CallObjectMethod(interfaces_asList, java_util_ArrayList_get, i);
        jboolean isUpped = JNI.EnvGlobal->CallBooleanMethod(network, _isUp);
        if (isUpped){
            jstring jname = reinterpret_cast<jstring>(JNI.EnvGlobal->CallObjectMethod(network, _getName));
            name = jstringTostring(jname);

        }
        if (name.find(OBFUSCATE("tun")) != std::string::npos || name.find(OBFUSCATE("ppp"))  != std::string::npos || name.find(OBFUSCATE("pptp"))  != std::string::npos){
            return JNI_FALSE;
        }
    }
    return JNI_TRUE;
}

struct {
    jobject getActiveNetwork(jobject connectivityManager) {
        jclass ConnectivityManager = JNI.EnvGlobal->FindClass("android/net/ConnectivityManager");
        jmethodID getActiveNetworkID = JNI.EnvGlobal->GetMethodID(ConnectivityManager, "getActiveNetwork","()Landroid/net/Network;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(connectivityManager,getActiveNetworkID));
    }
    jobject getNetworkCapabilities(jobject activeNetwork, jobject network) {
        jclass ConnectivityManager = JNI.EnvGlobal->FindClass("android/net/ConnectivityManager");
        jmethodID getNetworkCapabilitiesID = JNI.EnvGlobal->GetMethodID(ConnectivityManager, "getNetworkCapabilities","(Landroid/net/Network;)Landroid/net/NetworkCapabilities;");
        return JNI.EnvGlobal->NewGlobalRef(JNI.EnvGlobal->CallObjectMethod(activeNetwork,getNetworkCapabilitiesID,network));
    }
}ConnectivityManager;

struct {
    int TRANSPORT_VPN = 4;

    jboolean hasTransport(jobject caps, int transportType) {
        jclass NetworkCapabilities = JNI.EnvGlobal->FindClass("android/net/NetworkCapabilities");
        jmethodID NetworkCapabilitiesID = JNI.EnvGlobal->GetMethodID(NetworkCapabilities, "hasTransport","(I)Z");
        return JNI.EnvGlobal->CallBooleanMethod(caps,NetworkCapabilitiesID,transportType);

    }
}NetworkCapabilities;

jboolean IsVpnActive(jobject ctx) {
    if(Build.VERSION.SDK_INT() < Build.VERSION_CODES.LOLLIPOP) {
        return JNI_FALSE;
    }

    jboolean vpnInUse = JNI_FALSE;

    jobject connectivityManager = Context.getSystemService(ctx,Context.CONNECTIVITY_SERVICE);

    if (Build.VERSION.SDK_INT() >= Build.VERSION_CODES.M) {
        jobject activeNetwork = ConnectivityManager.getActiveNetwork(connectivityManager);
        jobject caps = ConnectivityManager.getNetworkCapabilities(connectivityManager,activeNetwork);

        return NetworkCapabilities.hasTransport(caps,NetworkCapabilities.TRANSPORT_VPN);
    }
}

struct {
    void exit(int status) {
        jclass SystemClass = JNI.EnvGlobal->FindClass("java/lang/System");
        jmethodID exit = JNI.EnvGlobal->GetStaticMethodID(SystemClass, "exit","(I)V");
        return JNI.EnvGlobal->CallStaticVoidMethod(SystemClass, exit,status);
    }
}System;

struct {
    void su(jobjectArray ret) {
        jclass ShellClass = JNI.EnvGlobal->FindClass("com/topjohnwu/superuser/Shell");
        jmethodID suID = JNI.EnvGlobal->GetStaticMethodID(ShellClass,"su","([Ljava/lang/String;)Lcom/topjohnwu/superuser/Shell$Job;");
        jobject su = JNI.EnvGlobal->CallStaticObjectMethod(ShellClass,suID,ret);

        jclass JobClass = JNI.EnvGlobal->FindClass("com/topjohnwu/superuser/Shell$Job");
        jmethodID execID = JNI.EnvGlobal->GetMethodID(JobClass,"exec","()Lcom/topjohnwu/superuser/Shell$Result;");

        JNI.EnvGlobal->CallObjectMethod(su,execID);
    }

    jobjectArray LibsInject(JNIEnv *env, std::string inject, std::string pid, std::string diretorioCustom) {
        jobjectArray result;

        const char *suCmd[] = {inject.c_str(),pid.c_str(),diretorioCustom.c_str()};

        size_t LenghtArray = sizeof(suCmd) / sizeof(suCmd[0]);
        result = (jobjectArray) env->NewObjectArray(LenghtArray, env->FindClass("java/lang/String"),env->NewStringUTF(""));

        for (int i = 0; i < LenghtArray; i++) {
            env->SetObjectArrayElement(result, i, env->NewStringUTF(suCmd[i]));
        }
        return (result);
    }

    std::string valueOf(JNIEnv *env, int a1) {
        jclass StringClass = env->FindClass("java/lang/String");
        jmethodID formatID = env->GetStaticMethodID(StringClass,"valueOf", "(I)Ljava/lang/String;");
        jstring teste = (jstring)env->CallStaticObjectMethod(StringClass,formatID,a1);
        return std::string(env->GetStringUTFChars(teste,0));
    }

    std::string formatID(JNIEnv *env,const char *format,std::string inject, int pid, std::string diretorio) {
        jclass FloaterMenu_clazz = env->FindClass("com/brmods/loader/Native");
        jmethodID StartID = env->GetStaticMethodID(FloaterMenu_clazz, "format", "(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;");
        jstring teste2 = (jstring)env->CallStaticObjectMethod(FloaterMenu_clazz,StartID,env->NewStringUTF(format),env->NewStringUTF(inject.c_str()),pid,env->NewStringUTF(diretorio.c_str()));
        return env->GetStringUTFChars(teste2,0);
    }

    jobjectArray formatLibs(std::string inject, int pid, std::string diretorioCustom) {
        jobjectArray result;

        const char *suCmd[] = {formatID(JNI.EnvGlobal,"%s %d %s",inject,pid,diretorioCustom).c_str()};

        size_t LenghtArray = sizeof(suCmd) / sizeof(suCmd[0]);
        result = (jobjectArray) JNI.EnvGlobal->NewObjectArray(LenghtArray, JNI.EnvGlobal->FindClass("java/lang/String"),JNI.EnvGlobal->NewStringUTF(""));

        for (int i = 0; i < LenghtArray; i++) {
            JNI.EnvGlobal->SetObjectArrayElement(result, i, JNI.EnvGlobal->NewStringUTF(suCmd[i]));
        }
        return (result);
    }

    jobjectArray CmdData(std::string diretorio, std::string diretorioCustom) {
        jobjectArray result;

        std::string copyCustom = std::string("cp ") + diretorio + " " + diretorioCustom;
        std::string chmod = std::string("chmod 777 ") + diretorioCustom;
        std::string chcon = std::string("chcon ") + std::string() + "u:object_r:system_lib_file:s0" + diretorioCustom;

        const char *suCmd[] = {"mount -o rw,remount /","mount -o rw,remount /data","setenforce 0",copyCustom.c_str(),chmod.c_str(),chcon.c_str()};

        size_t LenghtArray = sizeof(suCmd) / sizeof(suCmd[0]);
        result = (jobjectArray) JNI.EnvGlobal->NewObjectArray(LenghtArray, JNI.EnvGlobal->FindClass("java/lang/String"),JNI.EnvGlobal->NewStringUTF(""));

        for (int i = 0; i < LenghtArray; i++) {
            JNI.EnvGlobal->SetObjectArrayElement(result, i, JNI.EnvGlobal->NewStringUTF(suCmd[i]));
        }
        return (result);
    }

    jobjectArray runtime(std::string cmd) {
        jobjectArray result;

        const char *suCmd[] = {cmd.c_str()};

        size_t LenghtArray = sizeof(suCmd) / sizeof(suCmd[0]);
        result = (jobjectArray) JNI.EnvGlobal->NewObjectArray(LenghtArray, JNI.EnvGlobal->FindClass("java/lang/String"),JNI.EnvGlobal->NewStringUTF(""));

        for (int i = 0; i < LenghtArray; i++) {
            JNI.EnvGlobal->SetObjectArrayElement(result, i, JNI.EnvGlobal->NewStringUTF(suCmd[i]));
        }
        return (result);
    }

    int getProcessID(JNIEnv* env, std::string pkg) {
        int pid = -1;

        jobjectArray result;

        std::string cmd1 = std::string("for p in /proc/[0-9]*; do [[ $(<$p/cmdline) = ") + pkg + " ]] && echo ${p##*/}; done";

        const char *suCmd[] = {cmd1.c_str()};

        size_t LenghtArray = sizeof(suCmd) / sizeof(suCmd[0]);
        result = (jobjectArray) env->NewObjectArray(LenghtArray, env->FindClass("java/lang/String"),env->NewStringUTF(""));

        for (int i = 0; i < LenghtArray; i++) {
            env->SetObjectArrayElement(result, i, env->NewStringUTF(suCmd[i]));
        }

        jclass ShellClass = env->FindClass("com/topjohnwu/superuser/Shell");

        jmethodID suID = env->GetStaticMethodID(ShellClass,"su","([Ljava/lang/String;)Lcom/topjohnwu/superuser/Shell$Job;");
        jobject su = env->CallStaticObjectMethod(ShellClass,suID,result);

        jclass JobClass = env->FindClass("com/topjohnwu/superuser/Shell$Job");
        jmethodID execID = env->GetMethodID(JobClass,"exec","()Lcom/topjohnwu/superuser/Shell$Result;");

        jclass ArrayListClass = env->FindClass("java/util/ArrayList");
        jmethodID NewArrayListID = env->GetMethodID(ArrayListClass,"<init>","()V");
        jobject NewArrayList = env->NewGlobalRef(env->NewObject(ArrayListClass, NewArrayListID));

        jmethodID toID = env->GetMethodID(JobClass,"to","(Ljava/util/List;)Lcom/topjohnwu/superuser/Shell$Job;");
        jobject teste = env->CallObjectMethod(su,toID,NewArrayList);
        env->CallObjectMethod(teste,execID);

        jclass ListClass = env->FindClass("java/util/List");
        jmethodID sizeID = env->GetMethodID(ListClass,"size", "()I");
        jint teste222 = env->CallIntMethod(NewArrayList,sizeID);

        jmethodID getID = env->GetMethodID(ListClass,"get", "(I)Ljava/lang/Object;");

        jclass IntegerClass = env->FindClass("java/lang/Integer");
        jmethodID parseIntID = env->GetStaticMethodID(IntegerClass,"parseInt", "(Ljava/lang/String;)I");

        if(teste222 > 0) {
            pid = env->CallStaticIntMethod(IntegerClass,parseIntID,env->CallObjectMethod(NewArrayList,getID,0));
        }
        return pid;
    }
}Shell;

struct {
    std::string getAbsolutePath(jobject ctx, const char *libraryName) {
        jclass FileClass = JNI.EnvGlobal->FindClass("java/io/File");
        jmethodID getAbsolutePathID = JNI.EnvGlobal->GetMethodID(FileClass,"getAbsolutePath","()Ljava/lang/String;");
        jstring nativeLibraryDir= static_cast<jstring>(JNI.EnvGlobal->CallObjectMethod(ctx,getAbsolutePathID));
        return std::string(JNI.EnvGlobal->GetStringUTFChars(nativeLibraryDir,0)) + std::string("/") + std::string(libraryName);
    }
}File;

std::string nativeLibraryDir(jobject ctx, const char *libraryName) {
    jclass ContextClass = JNI.EnvGlobal->FindClass("android/content/Context");
    jmethodID getApplicationInfoID = JNI.EnvGlobal->GetMethodID(ContextClass,"getApplicationInfo","()Landroid/content/pm/ApplicationInfo;");
    jobject getApplicationInfo = JNI.EnvGlobal->CallObjectMethod(ctx,getApplicationInfoID);
    jclass getApplicationInfoAcess = JNI.EnvGlobal->GetObjectClass(getApplicationInfo);
    jfieldID nativeLibraryDirID = JNI.EnvGlobal->GetFieldID(getApplicationInfoAcess, "nativeLibraryDir", "Ljava/lang/String;");
    jstring nativeLibraryDir= static_cast<jstring>(JNI.EnvGlobal->GetObjectField(getApplicationInfo,nativeLibraryDirID));
    return std::string(JNI.EnvGlobal->GetStringUTFChars(nativeLibraryDir,0)) + std::string("/") + std::string(libraryName);
}

jboolean isConnected(jobject ctx, bool isStatus) {
    if(!isStatus) {
        int *p = 0;
        *p = 0;
        return JNI_FALSE;
    }
    return isStatus;
}

size_t write_data(void *ptr, size_t size, size_t nmemb, std::string *data) {
    data->append((char*) ptr, size * nmemb);
    return size * nmemb;
}
