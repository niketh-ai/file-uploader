#include "Paint.h"

void Paint::setTextSize(float size) {
    env->CallVoidMethod(this->paintObj, this->setTextSizeId, size);
}

void Paint::setColor(int color) {
    env->CallVoidMethod(this->paintObj, this->setColorId, color);
}

void Paint::setStyle(Style style) {
    if (style == Style::FILL)
        env->CallVoidMethod(this->paintObj, this->setStyleId, this->Style_FILL);
    if (style == Style::STROKE)
        env->CallVoidMethod(this->paintObj, this->setStyleId, this->Style_STROKE);
    if (style == Style::FILL_AND_STROKE)
        env->CallVoidMethod(this->paintObj, this->setStyleId, this->Style_FILL_AND_STROKE);
}

void Paint::setStrokeWidth(float size) {
    env->CallVoidMethod(this->paintObj, this->setStrokeWidthId, size);
}

void Paint::setShader(jobject shader) {
    env->CallObjectMethod(this->paintObj,this->setShaderid,shader);
}

void Paint::setTextAlign(Align align) {
    if (align == Align::LEFT)
        env->CallVoidMethod(this->paintObj, this->setTextAlignId, this->Align_LEFT);
    if (align == Align::RIGHT)
        env->CallVoidMethod(this->paintObj, this->setTextAlignId, this->Align_RIGHT);
    if (align == Align::CENTER)
        env->CallVoidMethod(this->paintObj, this->setTextAlignId, this->Align_CENTER);
}

void Paint::setShadowLayer(float radius, float dx, float dy, int shadowColor) {
    return env->CallVoidMethod(this->paintObj, this->setShadowLayerId, radius, dx, dy, shadowColor);
}

void Paint::setTypeface(jobject typeface) {
    auto result = env->CallObjectMethod(this->paintObj, this->setTypefaceId, typeface);
    env->DeleteLocalRef(result);
}

void Paint::setAntiAlias(bool bUseAA) {
    return env->CallVoidMethod(this->paintObj, this->setAntiAliasId, bUseAA);
}