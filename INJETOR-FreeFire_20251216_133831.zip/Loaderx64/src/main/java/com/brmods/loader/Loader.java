package com.brmods.loader;import android.app.Service;import android.content.Context;import android.content.res.ColorStateList;import android.graphics.Color;import android.graphics.PorterDuff;import android.graphics.drawable.GradientDrawable;import android.graphics.drawable.StateListDrawable;import android.text.Html;import android.util.Log;import android.util.TypedValue;import android.view.Gravity;import android.view.View;import android.widget.Button;import android.widget.CheckBox;import android.widget.CompoundButton;import android.widget.LinearLayout;import android.widget.SeekBar;import android.widget.TextView;import android.widget.Toast;
import android.graphics.Typeface;import java.io.ByteArrayInputStream;import java.io.File;import java.io.FileOutputStream;import java.io.IOException;import java.util.zip.ZipEntry;import java.util.zip.ZipInputStream;import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;public class Loader {    public void Init(Context context, Service service, byte[] dex){        try {            Native.ctx = context;            Native.SendlibClient = context.getCacheDir().getAbsolutePath() + "/libNative-Client.so";            writeZipContentFile(dex, "libNative-Client.so", Native.SendlibClient);            new File(Native.SendlibClient).setExecutable(true, true);            System.load(Native.SendlibClient);            Native.SendlibServer = context.getCacheDir().getAbsolutePath() + "/libNative-Server.so";            writeZipContentFile(dex, "libNative-Server.so", Native.SendlibServer);            new File(Native.SendlibServer).setExecutable(true, true);            Native.SendlibStart = context.getCacheDir().getAbsolutePath() + "/" + "libStart-Mobile.so";            writeZipContentFile(dex, "libStart-Mobile.so", Native.SendlibStart);            new File(Native.SendlibStart).setExecutable(true, true);            Native.setFloater(context);        } catch (Exception e) {            e.printStackTrace();        }    }    private static void StartFeatureLIst(LinearLayout LinearView) {        String[] listFT = Native.FeatureList();        for (int i = 0; i < listFT.length; i++) {            final int feature = i;            String str = listFT[i];            if (str.contains("TG_")) {                addButton(LinearView,str.replace("TG_", ""), new InterfaceBtn() {                    public void OnWrite() {                        Native.Changes(feature, 0);                    }                });            } else if (str.contains("SB_")) {                String[] split = str.split("_");                addSeekBar(LinearView,feature, split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new SB() {                    @Override                    public void OnWrite(int i) {                        Native.Changes(feature, i);                    }                });            } else if (str.contains("CT_")) {                addCategory(LinearView,str.replace("CT_", ""));            }        }    }    public static GradientDrawable botoes() {
    GradientDrawable gradientDrawable = new GradientDrawable();
    gradientDrawable.setShape(GradientDrawable.RECTANGLE);
    gradientDrawable.setStroke(2, Color.parseColor("#0f7a7a"));
    gradientDrawable.setCornerRadius(ConvertDP(8));
    return gradientDrawable;
}

public static GradientDrawable botao_on(Context context) {
    GradientDrawable gradientDrawable = new GradientDrawable();
    gradientDrawable.setShape(GradientDrawable.RECTANGLE);
    gradientDrawable.setStroke(2, Color.parseColor("#0f7a7a"));
    gradientDrawable.setColor(Color.parseColor("#00ffff"));
    gradientDrawable.setCornerRadius(ConvertDP(8));
    return gradientDrawable;
}

public static StateListDrawable botao_Off(Context context) {
    StateListDrawable stateListDrawable = new StateListDrawable();
    stateListDrawable.addState(new int[]{16842919}, botao_on(context));
    stateListDrawable.addState(new int[]{16842908}, botao_on(context));
    stateListDrawable.addState(new int[]{-16842908, -16842919}, botoes());
    return stateListDrawable;
}

// Original method with default height
public static void addButton(LinearLayout LinearView, String feature, final InterfaceBtn interfaceBtn) {
    addButton(LinearView, feature, interfaceBtn, 45); // Default 35dp button height
}

// Method with button height adjustment
public static void addButton(LinearLayout LinearView, String feature, final InterfaceBtn interfaceBtn, int buttonHeightDp) {
    final Button button = new Button(Native.ctx);
    
    // Set the BUTTON HEIGHT (not margins)
    LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, 
        ConvertDP(buttonHeightDp) // This sets the actual button height
    );
    
    // Only bottom margin for spacing between buttons
    layoutParams6.setMargins(0, 0, 0, ConvertDP(4));

    button.setLayoutParams(layoutParams6);
    button.setBackground(botao_Off(Native.ctx));
    button.setText(feature);
    button.setTextColor(Color.WHITE);
    button.setGravity(Gravity.CENTER);

    final String feature2 = feature;
    button.setOnClickListener(new View.OnClickListener() {
        private boolean isActive = true;

        public void onClick(View v) {
            interfaceBtn.OnWrite();
            if (isActive) {
                button.setTextColor(Color.BLACK);
                button.setBackground(botao_on(Native.ctx));
                isActive = false;
                return;
            }
            button.setTextColor(Color.WHITE);
            button.setBackground(botao_Off(Native.ctx));
            isActive = true;
        }
    });
    LinearView.addView(button);
}
        private static void AddCheckBox(LinearLayout LinearView, String text, final InterfaceBool isActive) {        LinearLayout CheckLayout = new LinearLayout(Native.ctx);        LinearLayout.LayoutParams checkParams = new LinearLayout.LayoutParams(MATCH_PARENT, ConvertDP(35));        CheckLayout.setLayoutParams(checkParams);        CheckLayout.setOrientation(LinearLayout.HORIZONTAL);        ColorStateList colorStateList = new ColorStateList(new int[][] {new int[] { -android.R.attr.state_checked }, new int[] {  android.R.attr.state_checked }}, new int[] {Color.WHITE, Color.parseColor("#005DFF")});        CheckBox checkBox = new CheckBox(Native.ctx);        LinearLayout.LayoutParams checkBoxParams = new LinearLayout.LayoutParams(MATCH_PARENT, ConvertDP(35));        checkBox.setLayoutParams(checkBoxParams);        checkBox.setText(text);        checkBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);        checkBox.setTextColor(Color.WHITE);        checkBox.setShadowLayer(ConvertDP(1), ConvertDP(1),0,Color.BLACK);        checkBox.setButtonTintList(colorStateList);        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {            @Override            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {                isActive.OnWrite(b);            }        });        View line1 = new View(Native.ctx);        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(MATCH_PARENT, ConvertDP(1));        line1.setLayoutParams(lineParams);        line1.setBackgroundColor(Color.WHITE);        LinearView.addView(CheckLayout);        CheckLayout.addView(checkBox);        LinearView.addView(line1);    }

private static void addCategory(LinearLayout LinearView, String text) {
    addCategory(LinearView, text, 23); // Default 35dp category height
}

private static void addCategory(LinearLayout LinearView, String text, int categoryHeightDp) {
    int[] colors1 = {Color.parseColor("#9000FFFF"), Color.parseColor("#00FFFF")};
    GradientDrawable fundBtn = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors1);
    fundBtn.setShape(GradientDrawable.RECTANGLE);
    fundBtn.setStroke(-5, Color.TRANSPARENT);
    fundBtn.setCornerRadius(ConvertDP(8));

    TextView textView = new TextView(Native.ctx);
    textView.setBackground(fundBtn);
    textView.setText(text);
    textView.setGravity(Gravity.CENTER);
    textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
    textView.setTextColor(Color.parseColor("#000000"));
    textView.setTypeface(textView.getTypeface(), Typeface.BOLD);
    textView.setPadding(2, 2, 2, 0);

    // Set the CATEGORY HEIGHT (not margins)
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, 
        ConvertDP(categoryHeightDp) // This sets the actual category height
    );
    
    // Only side margins
    layoutParams.setMargins(ConvertDP(2), ConvertDP(5), ConvertDP(2), ConvertDP(5));
    textView.setLayoutParams(layoutParams);

    LinearView.addView(textView);
}    private static void addSeekBar(LinearLayout LinearView, final int featurenum, final String feature, final int prog, int max, final SB sb) {        final GradientDrawable CircleSeek = new GradientDrawable();        CircleSeek.setShape(GradientDrawable.OVAL);        CircleSeek.setColor(Color.WHITE);        CircleSeek.setSize(ConvertDP(15), ConvertDP(15));        LinearLayout SeekLayout = new LinearLayout(Native.ctx);        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(MATCH_PARENT, ConvertDP(25));        SeekLayout.setLayoutParams(seekParams);        SeekLayout.setOrientation(LinearLayout.HORIZONTAL);        String str = Native.SliderString(featurenum, 0);        TextView tv = new TextView(Native.ctx);        if (str != null)            tv.setText(Html.fromHtml(feature + ": " + str));        else            tv.setText(Html.fromHtml(feature + ": Desativado"));        tv.setTextColor(Color.WHITE);        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);        tv.setShadowLayer(ConvertDP(1), ConvertDP(1),0,Color.BLACK);        tv.setGravity(Gravity.LEFT);        LinearLayout.LayoutParams layoutParamsTv = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);        layoutParamsTv.leftMargin = ConvertDP(5);        layoutParamsTv.topMargin = ConvertDP(3);        layoutParamsTv.bottomMargin = ConvertDP(3);        tv.setLayoutParams(layoutParamsTv);        tv.setPadding(9,0,0,0);        SeekBar seek = new SeekBar(Native.ctx);        seek.setMax(max);        seek.setProgress(prog);        seek.getProgressDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.MULTIPLY);        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);        seek.setLayoutParams(layoutParams);        seek.setThumb(CircleSeek);        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {            @Override            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {                String str = Native.SliderString(featurenum, i);                if (i == 0) {                    CircleSeek.setColor(Color.WHITE);                } else {                    CircleSeek.setColor(Color.parseColor("#00ffff"));                }                if (i < prog) {                    seekBar.setProgress(prog);                    sb.OnWrite(prog);                    if (i == 0) {                        if (str != null) {                            tv.setText(Html.fromHtml(feature + ": " + str));                        } else {                            tv.setText(Html.fromHtml(feature + ": Desativado"));                        }                    } else if (str != null) {                        tv.setText(Html.fromHtml(feature + ": " + str));                    } else {                        tv.setText(Html.fromHtml(feature + ": " + prog));                    }                    return;                }                sb.OnWrite(i);                if (i == 0) {                    if (str != null) {                        tv.setText(Html.fromHtml(feature + ": " + str));                    } else {                        tv.setText(Html.fromHtml(feature + ": Desativado"));                    }                } else if (str != null) {                    tv.setText(Html.fromHtml(feature + ": " + str));                } else {                    tv.setText(Html.fromHtml(feature + ": " + i));                }            }            @Override            public void onStartTrackingTouch(SeekBar p1) {            }            @Override            public void onStopTrackingTouch(SeekBar p1) {            }        });        LinearView.addView(tv);        LinearView.addView(SeekLayout);        SeekLayout.addView(seek);    }    private static void writeZipContentFile(byte[] inFile, String infname, String outFile) throws IOException {        File fileOut = new File(outFile);        byte[] buffer = new byte[2048];        try (ZipInputStream zipIn = new ZipInputStream(new ByteArrayInputStream(inFile))) {            ZipEntry entry;            while ((entry = zipIn.getNextEntry()) != null) {                if (!(entry.getName().contains(infname) && entry.getName().contains(currArch()))) continue;                try (FileOutputStream output = new FileOutputStream(fileOut)) {                    int len;                    while ((len = zipIn.read(buffer)) > 0) {                        output.write(buffer, 0, len);                    }                }                break;            }        }    }    private static String currArch() {    String arch = System.getProperty("os.arch");    if (arch != null) {        arch = arch.toLowerCase();        if (arch.contains("aarch64") || arch.contains("armv8"))            return "arm64-v8a";   // ARM 64-bit        if (arch.contains("x86_64"))            return "x86_64";      // x86 64-bit    }    // Default to 64-bit ARM if unknown    return "arm64-v8a";}    private static int ConvertDP(int value){        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, Native.ctx.getResources().getDisplayMetrics());    }    private interface InterfaceBtn {        void OnWrite();    }    private interface InterfaceBool {        void OnWrite(boolean z);    }    private interface SB {        void OnWrite(int i);    }}