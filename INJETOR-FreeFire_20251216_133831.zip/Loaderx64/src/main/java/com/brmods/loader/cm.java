package com.brmods.loader;
import com.topjohnwu.superuser.Shell;

public class cm {

    private String command = null;

    public cm(String command){
        this.command = command;
    }

    public static cm execute(String command){
        return new cm(command);
    }

    public void start(){

        Shell.rootAccess();
        new Thread(new Runnable(){
            @Override
            public void run() {

                String[] Cmd = {command};

                Shell.su(Cmd).exec();
            }
        }).start();

    }
}
