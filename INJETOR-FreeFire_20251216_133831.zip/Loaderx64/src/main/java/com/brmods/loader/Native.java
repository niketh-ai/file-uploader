package com.brmods.loader;

import static android.app.PendingIntent.getActivity;

import static java.security.AccessController.getContext;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Canvas;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import eu.chainfire.libsuperuser.Shell;

public class Native {
    static Context ctx;
    static String SendlibClient, SendlibServer, SendlibStart;
    static native int Init();

    public static native void Stop();

    static native void setFloater(Context ctx);
    static native void setTounch(MotionEvent motionEvent);
    static native void setClick(Context ctx, int id);
    static native void setHandler(Runnable ctx, Handler handler);

    static native void DrawOn(DrawESP drawEsp, Canvas canvas);

    static native void Changes(int feature, int Value);
    static native String[] FeatureList();
    static native String SliderString(int feature, int value);

    private static View.OnClickListener onClickListener(final Context ctx, final int id) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setClick(ctx, id);
            }
        };
    }

    private static View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                setTounch(motionEvent);
                return false;
            }
        };
    }

    private static void onHandler() {
        Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                setHandler(this, handler);
                handler.postDelayed(this,1);
            }
        });
    }

    private static String format(String format, String cmd1, int process, String cmd2) {
        return String.format(format, cmd1,process, cmd2);
    }

    private Process process;

    public void Shell(String cmd) {
        try {
            process = Runtime.getRuntime().exec(cmd);
        } catch (IOException e) {
            e.printStackTrace();
            process = null;
        }
    }

    public static void TrySetupLib(byte[] dex, Context context, String libName) {
        String filesDir = context.getFilesDir().getAbsolutePath();
        File file = new File(filesDir  + "/" + libName);
        file.delete();
        try {
            file.createNewFile();
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(dex);
            fos.flush();
            fos.close();
        } catch (Exception e) {}
    }

    static void ComandeSu(String name){
        cm.execute(name).start();
    }

    public static class FreeFireTask extends AsyncTask<Void, Void, Boolean>
    {
        public WeakReference<Context > weakReference;
        private Shell.Pool weakActivity;

        public FreeFireTask(Context floatingViewService)
        {
            weakReference = new WeakReference<>(floatingViewService);
        }

        @Override
        public Boolean doInBackground(Void[] voidArr) {
            try {
                String DiretorioCustom = "/data/.androiding/.androiding/.androiding/.androiding/propt.so";
                cm.execute("chmod 777 " + DiretorioCustom).start();
                Thread.sleep(100);
                cm.execute(DiretorioCustom + " com.dts.freefireth").start();
                Thread.sleep(300);

                Shell.Pool.SU.run("rm -rf /data/.androiding");
                Shell.Pool.SU.run("rm /data/local/tmp/*");
                Shell.Pool.SU.run("monkey -p com.dts.freefireth 1");

                Thread.sleep(1000);

                Init();
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }

            return false;
        }

        @Override
        public void onPostExecute(Boolean bool)
        {
            String str;
            if (bool)
            {
                str = "Iniciado com sucesso";
            }
            else
            {
                str = "Falha ao iniciar";
            }
            Toast.makeText(ctx, str, Toast.LENGTH_LONG).show();
        }
    }
}