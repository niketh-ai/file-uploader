int startClient();
bool isConnected();
void stopClient();
bool initServer();
bool stopServer();

struct Funcoes {
    bool aimbotShot;
    bool aimbotAim;
    float aimFov;
};

enum Mode {
    InitMode = 1,
    HackMode = 2,
    Thread = 3,
};

enum p_Functions {
    pAtivarFuncao = 4,
    pAimLock = 5,
};

struct Request {
    int Mode;
    bool m_IsOn;
    float FloatValue;
    int IntValue;
    int ScreenWidth;
    int ScreenHeight;
    Funcoes Opcoes;
};
Request request{};

struct PlayerData {
    Vector3 LocationHead;
    Vector3 LocationChest;
    Vector3 LocationStomach;
    Vector3 LocationHip;

    Vector3 LocationLeftShoulder;
    Vector3 LocationLeftArm;
    Vector3 LocationLeftForearm;
    Vector3 LocationLeftHand;

    Vector3 LocationRightShoulder;
    Vector3 LocationRightArm;
    Vector3 LocationRightForearm;
    Vector3 LocationRightHand;

    Vector3 LocationLeftThigh;
    Vector3 LocationLeftShin;
    Vector3 LocationLeftFoot;

    Vector3 LocationRightThigh;
    Vector3 LocationRightShin;
    Vector3 LocationRightFoot;

    Vector3 LocationHeadBox;
    Vector3 LocationToeBox;

    float Distance;
    int PlayerState;
    int Life;
};

struct Response {
    bool Success;
    int PlayerCount;
    PlayerData Players[500];
};

int startClient() {
    pSOCKEt.client = SocketClient();
    if (!pSOCKEt.client.Create()) {
        return -1;
    }
    if (!pSOCKEt.client.Connect()) {
        return -1;
    }
    if (!initServer()) {
        return -1;
    }
    return 0;
}

bool isConnected(){
    return pSOCKEt.client.connected;
}

void stopClient() {
    if(pSOCKEt.client.created && isConnected()){
        stopServer();
        pSOCKEt.client.Close();
    }
}

bool initServer() {
    Request request{Mode::Thread};
    int code = pSOCKEt.client.send((void*) &request, sizeof(request));
    if(code > 0) {
        Response response{};
        size_t length = pSOCKEt.client.receive((void*) &response);
        if(length > 0){
            return response.Success;
        }
    }
    return false;
}

bool stopServer(){
    Request request{Mode::HackMode};
    int code = pSOCKEt.client.send((void*) &request, sizeof(request));
    if(code > 0) {
        Response response{};
        size_t length = pSOCKEt.client.receive((void*) &response);
        if(length > 0){
            return response.Success;
        }
    }
    return false;
}

bool SendFeatuere(int32_t Feature, bool isActivity) {
    Request request{Feature, isActivity};
    int code = pSOCKEt.client.send((void*) &request, sizeof(request));
    if (code > 0) {
        Response response{};
        size_t length = pSOCKEt.client.receive((void*) &response);
        if (length > 0) {
            return response.Success;
        }
    }
    return false;
}

bool SeekbarFloaValue(int32_t Feature, float Value) {
    Request request{Feature, false, Value};
    int code = pSOCKEt.client.send((void*) &request, sizeof(request));
    if (code > 0) {
        Response response{};
        size_t length = pSOCKEt.client.receive((void*) &response);
        if (length > 0) {
            return response.Success;
        }
    }
    return false;
}

bool SendInt(int32_t Feature, int Value) {
    Request request{Feature, false, 0.0f,Value};
    int code = pSOCKEt.client.send((void*) &request, sizeof(request));
    if (code > 0) {
        Response response{};
        size_t length = pSOCKEt.client.receive((void*) &response);
        if (length > 0) {
            return response.Success;
        }
    }
    return false;
}

Response getData(int screenWidth, int screenHeight, Funcoes Funcs){
    Request request{Mode::Thread, false,0.0f,0, screenWidth, screenHeight, Funcs};
    int code = pSOCKEt.client.send((void*) &request, sizeof(request));
    if (code > 0) {
        Response response{};
        size_t length = pSOCKEt.client.receive((void*) &response);
        if (length > 0) {
            return response;
        }
    }
    Response response{};
    return response;
}