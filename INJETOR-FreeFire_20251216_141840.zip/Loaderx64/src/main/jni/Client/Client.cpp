#include "Imports.h"

extern "C" {
JNIEXPORT jobjectArray JNICALL
Java_com_brmods_loader_Native_FeatureList(JNIEnv *env, jclass activityObject) {
    jobjectArray ret;

    const char *features[] = {
            (OBFUSCATE("CT_Aim Menu")),
            (OBFUSCATE("TG_AIM HEAD")),
            (OBFUSCATE("TG_AIMBOT")),
            (OBFUSCATE("SB_Aim Fov_0_180")),

            (OBFUSCATE("CT_Esp Menu")),
            (OBFUSCATE("TG_ESP LINE")),
            (OBFUSCATE("TG_ESP SKELETON")),
            (OBFUSCATE("TG_ESP BOX")),
            (OBFUSCATE("TG_ESP DISTANCE")),
            (OBFUSCATE("TG_ESP HEALTH")),
            
            (OBFUSCATE("CT_Esp Fix")),
            (OBFUSCATE("SB_Esp Color_0_7")),
            (OBFUSCATE("SB_Line Position_0_2")),
            (OBFUSCATE("SB_Box Type_0_3")),
            (OBFUSCATE("SB_Text Size_0_10")),
            (OBFUSCATE("SB_ScreenWidth Fix_0_150")),

    };

    int Total_Feature = (sizeof features / sizeof features[0]);

    ret = (jobjectArray) env->NewObjectArray(Total_Feature,env->FindClass(OBFUSCATE("java/lang/String")),env->NewStringUTF(OBFUSCATE("")));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
}

JNIEXPORT void JNICALL
Java_com_brmods_loader_Native_Changes(JNIEnv *env, jclass activityObject, jint feature, jint progress) {
    switch (feature) {
        case 1:
            pAIM.AimbotShot = !pAIM.AimbotShot;
            break;

        case 2:
            pAIM.AimbotAim = !pAIM.AimbotAim;
            break;

        case 3:
            pAIM.AimFov = progress;
            break;

        case 5:
            pESP.esp_line = !pESP.esp_line;
            break;

        case 6:
            pESP.esp_skeleton = !pESP.esp_skeleton;
            break;

        case 7:
            pESP.esp_box = !pESP.esp_box;
            break;

        case 8:
            pESP.esp_distance = !pESP.esp_distance;
            break;

        case 9:
            pESP.esp_health = !pESP.esp_health;
            break;

        case 10:
            if (progress == 0) {
                pESP.ESPColor = Color.CYAN;
            } else if (progress == 1) {
                pESP.ESPColor = Color.WHITE;
            } else if (progress == 2) {
                pESP.ESPColor = Color.GREEN;
            } else if (progress == 3) {
                pESP.ESPColor = Color.RED;
            } else if (progress == 4) {
                pESP.ESPColor = Color.BLUE;
            } else if (progress == 5) {
                pESP.ESPColor = Color.YELLOW;
            } else if (progress == 6) {
                pESP.ESPColor = Color.MAGENTA;
            } else if (progress == 7) {
                pESP.ESPColor = Color.GRAY;
            }else if (progress == 8) {
                pESP.ESPColor = Color.BLACK;
            }
            break;

        case 11:
            if (progress == 0) {
                pESP.esp_line_pos = pESP.PositionLine::top;
            } else if (progress == 1) {
                pESP.esp_line_pos = pESP.PositionLine::Center;
            } else if (progress == 2) {
                pESP.esp_line_pos = pESP.PositionLine::Down;
            }
            break;

        case 12:
            if (progress == 0) {
                pESP.esp_box_pos = pESP.TypeBox::Stroke;
            } else if (progress == 1) {
                pESP.esp_box_pos = pESP.TypeBox::Filled;
            } else if (progress == 2) {
                pESP.esp_box_pos = pESP.TypeBox::Corner;
            } else if (progress == 3) {
                pESP.esp_box_pos = pESP.TypeBox::Rounded;
            }
            break;

        case 13:
            pESP.distanceSize = 15.0f + progress;
            break;

        case 14:
            pESP.EspFix = + progress;
            break;

    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_brmods_loader_Native_SliderString(JNIEnv *env, jclass clazz, jint feature, jint value) {

    const char *SliderStr;

    if (feature == 10) {
        switch (value) {
            case 0:
                SliderStr = OBFUSCATE("Cyan");
                break;
            case 1:
                SliderStr = OBFUSCATE("White");
                break;
            case 2:
                SliderStr = OBFUSCATE("Green");
                break;
            case 3:
                SliderStr = OBFUSCATE("Red");
                break;
            case 4:
                SliderStr = OBFUSCATE("Blue");
                break;
            case 5:
                SliderStr = OBFUSCATE("Yellow");
                break;
            case 6:
                SliderStr = OBFUSCATE("Magenta");
                break;
            case 7:
                SliderStr = OBFUSCATE("Gray");
                break;
            case 8:
                SliderStr = OBFUSCATE("Black");
                break;
        }
        return env->NewStringUTF(SliderStr);
    }

    if (feature == 11) {
        switch (value) {
            case 0:
                SliderStr = OBFUSCATE("Top");
                break;
            case 1:
                SliderStr = OBFUSCATE("Center");
                break;
            case 2:
                SliderStr = OBFUSCATE("Down");
                break;
        }
        return env->NewStringUTF(SliderStr);
    }

    if (feature == 12) {
        switch (value) {
            case 0:
                SliderStr = OBFUSCATE("Stroke");
                break;

            case 1:
                SliderStr = OBFUSCATE("Filled");
                break;

            case 2:
                SliderStr = OBFUSCATE("Corner");
                break;

            case 3:
                SliderStr = OBFUSCATE("Rounded");
                break;
        }
        return env->NewStringUTF(SliderStr);
    }

    return env->NewStringUTF(nullptr);
}
}

void LoginCurl(JNIEnv *env, jobject ctx) {
    char params[1024];
    const char *isURL = OBFUSCATE("https://www.hgcheats.myvippanel.fun/api/Verify.php?user=%s&pass=%s&uid=%s");
    std::string Username = jstringTostring(Prefs.read(ctx,"USER",""));
    std::string Password = jstringTostring(Prefs.read(ctx,"PASS",""));
    std::string Uid = jstringTostring(Prefs.read(ctx,"UID",""));

    if(strcmp(isURL, OBFUSCATE("https://www.hgcheats.myvippanel.fun/api/Verify.php?user=%s&pass=%s&uid=%s")) != 0) {
        CustomToast(env,OBFUSCATE("não foi possível obter informações do servidor"),ctx);
        return;
    }

    snprintf(params, sizeof(params), isURL, Username.c_str(), Password.c_str(), Uid.c_str());
    snprintf(Logger.paramsSTS, sizeof(Logger.paramsSTS), Logger.isStatus, Logger.isFailed);
    std::string FindURL = (isURL);
    std::string FindParams = (params);

    if (FindURL.find(OBFUSCATE("https://www.hgcheats.myvippanel.fun")) != std::string::npos && 
        FindParams.find(OBFUSCATE("https://www.hgcheats.myvippanel.fun/api/")) != std::string::npos)
    {
        const char *Request = getRequestURL(params);
        if(Request != nullptr)
        {
            std::string request = (Request);
            if (request.find(Uid) != std::string::npos)
            {
                CustomToast(env,OBFUSCATE("Obtendo informações do servidor"),ctx);
                CustomToast(env,OBFUSCATE("Todos os Dados Foram Verificados..."),ctx);
                snprintf(Logger.paramsSTS, sizeof(Logger.paramsSTS), Logger.isStatus, Logger.isSucesso);
                FloaterCreate(env,ctx);
            } 
            else if(request.find(OBFUSCATE("Usuário e/ou senha incorreta!")) != std::string::npos)
            {
                CustomToast(env,OBFUSCATE("Usuário ou senha incorretos."),ctx);
                return;
            }
            else
            {
                CustomToast(env,request.c_str(),ctx);
                return;
            }
        } 
        else 
        {
            CustomToast(env,OBFUSCATE("não foi possível obter informações do servidor"), ctx);
            return;
        }
    }
    else
    {
        CustomToast(env,OBFUSCATE("não foi possível obter informações do servidor"),ctx);
        return;
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_brmods_loader_Native_setFloater(JNIEnv *env, jclass clazz, jobject ctx) {
    JNI.EnvGlobal = env;
    LoginCurl(env,ctx);
  // FloaterCreate(env,ctx);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_brmods_loader_Native_setTounch(JNIEnv *env, jclass clazz, jobject motion_event) {
    SetOnTounch(motion_event);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_brmods_loader_Native_setClick(JNIEnv *env, jclass clazz, jobject ctx, jint id) {
    FloaterOnClick(env,ctx,id);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_brmods_loader_Native_setHandler(JNIEnv *env, jclass clazz, jobject ctx,jobject handler) {
    StartThreadFloater(env,ctx,handler);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_brmods_loader_Native_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    static class Canvas *m_Canvas = nullptr;
    if (!m_Canvas) {
        m_Canvas = new class Canvas(env);
    }
    m_Canvas->UpdateCanvas(canvas);
    if(m_Canvas->isValid()) {
        DrawESP(m_Canvas,m_Canvas->getWidth() + pESP.EspFix,m_Canvas->getHeight());
    }
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_brmods_loader_Native_Init(JNIEnv *env, jclass clazz) {
    return startClient();
}

extern "C"
JNIEXPORT void JNICALL
Java_com_brmods_loader_Native_Stop(JNIEnv *env, jclass clazz) {
    stopClient();
}