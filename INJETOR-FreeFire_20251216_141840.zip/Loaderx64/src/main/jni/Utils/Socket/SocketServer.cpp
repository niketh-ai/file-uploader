#include "SocketServer.h"
#include <cstring> // Incluído para usar strerror()
#include <netinet/in.h> // Incluído para usar htonl e ntohl
#include <cerrno> // Incluído para usar a variável errno

SocketServer::SocketServer() {
    isCreated = false;
}

bool SocketServer::Create() {
    isCreated = (listenfd = socket(AF_UNIX, SOCK_STREAM, 0)) != -1;
    return isCreated;
}

bool SocketServer::Accept() {
    struct sockaddr_un client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    acceptfd = accept(listenfd, (struct sockaddr*)&client_addr, &client_addr_len);
    if (acceptfd == -1) {
        Close();
        return false;
    }
    return true;
}

bool SocketServer::Bind() {
    memset(socket_name, 0, sizeof(socket_name));
    memcpy(&socket_name[0], "\0", 1);
    strcpy(&socket_name[1], SOCKET_NAME);

    memset(&addr_server, 0, sizeof(addr_server));
    addr_server.sun_family = AF_UNIX;
    strncpy(addr_server.sun_path, socket_name, sizeof(addr_server.sun_path) - 1);

    unlink(socket_name); // Remove the existing socket file if it exists

    if (bind(listenfd, (struct sockaddr*)&addr_server, sizeof(addr_server)) == -1) {
        Close();
        return false;
    }

    return true;
}

bool SocketServer::Listen() {
    if (listen(listenfd, BACKLOG) == -1) {
        Close();
        return false;
    }
    return true;
}

int SocketServer::sendData(void* inData, size_t size) {
    char* buffer = (char*)inData;
    int numSent = 0;

    while (size) {
        int sent = ::send(acceptfd, buffer, size, 0);
        if (sent == -1) {
            if (errno == EINTR)
                continue;
            Close();
            return -1;
        }
        if (sent == 0)
            break;

        size -= sent;
        buffer += sent;
        numSent += sent;
    }

    return numSent;
}

bool SocketServer::send(void* inData, size_t size) {
    uint32_t length = htonl(size);
    if (sendData(&length, sizeof(uint32_t)) <= 0) {
        return false;
    }
    return sendData(inData, size) > 0;
}

int SocketServer::recvData(void* outData, size_t size) {
    char* buffer = (char*)outData;
    int numReceived = 0;

    while (size) {
        int received = recv(acceptfd, buffer, size, 0);
        if (received == -1) {
            if (errno == EINTR)
                continue;
            Close();
            return -1;
        }
        if (received == 0)
            break;

        size -= received;
        buffer += received;
        numReceived += received;
    }

    return numReceived;
}

size_t SocketServer::receive(void* outData) {
    uint32_t length = 0;
    int code = recvData(&length, sizeof(uint32_t));
    if (code > 0) {
        length = ntohl(length);
        recvData(outData, length);
    }
    return length;
}

void SocketServer::Close() {
    if (acceptfd > 0)
        close(acceptfd);
    if (listenfd > 0) {
        close(listenfd);
        unlink(socket_name); // Remove the socket file
    }
}
