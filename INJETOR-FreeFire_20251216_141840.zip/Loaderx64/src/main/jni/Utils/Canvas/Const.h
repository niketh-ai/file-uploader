#include <jni.h>
#include <string>
#include "Utils/Unity/Vector3.hpp"
#include "Utils/Unity/Vector2.hpp"
#include "Utils/Unity/Rect.hpp"

#ifndef ENGINE_CONST
#define ENGINE_CONST

enum Style {
    FILL = 0,
    STROKE = 1,
    FILL_AND_STROKE = 2
};

enum Align {
    LEFT = 0,
    RIGHT = 1,
    CENTER
};

#endif