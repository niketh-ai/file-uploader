#include "Canvas.h"

Canvas::Canvas(JNIEnv *env) {
    this->env = env;

    this->low = false;

    jclass canvasClass = env->FindClass("android/graphics/Canvas");
    drawRoundRectid = env->GetMethodID(canvasClass, "drawRoundRect", "(FFFFFFLandroid/graphics/Paint;)V");
    drawTextId = env->GetMethodID(canvasClass, "drawText", "(Ljava/lang/String;FFLandroid/graphics/Paint;)V");
    drawRectId = env->GetMethodID(canvasClass, "drawRect", "(FFFFLandroid/graphics/Paint;)V");
    drawLineId = env->GetMethodID(canvasClass, "drawLine", "(FFFFLandroid/graphics/Paint;)V");
    drawCircleId = env->GetMethodID(canvasClass, "drawCircle", "(FFFLandroid/graphics/Paint;)V");
    widthid = env->GetMethodID( canvasClass, "getWidth", "()I");
    heightid = env->GetMethodID(canvasClass, "getHeight", "()I");

    env->DeleteLocalRef(canvasClass);

    mTextPaint = new Paint(this->env);
    mTextPaint->setTextAlign(Align::CENTER);
    mTextPaint->setAntiAlias(true);

    mStrokePaint = new Paint(this->env);
    mStrokePaint->setStyle(Style::STROKE);
    mStrokePaint->setAntiAlias(true);

    mFilledPaint = new Paint(this->env);
    mFilledPaint->setStyle(Style::FILL);
    mFilledPaint->setAntiAlias(true);

    mFilledGdtPaint = new Paint(this->env);
    mFilledGdtPaint->setStyle(Style::FILL);
    mFilledGdtPaint->setAntiAlias(true);

    mCiclePaint = new Paint(this->env);
    mCiclePaint->setStyle(Style::FILL_AND_STROKE);
    mCiclePaint->setAntiAlias(true);
}

void Canvas::UpdateCanvas(jobject canvas) {
    this->m_CanvasObj = canvas;
}

bool Canvas::isValid() {
    return (env != nullptr && m_CanvasObj != nullptr);
}

jobject Canvas::MIRROR(){
    if(isValid()) {
        jclass ShaderClass = env->FindClass("android/graphics/Shader$TileMode");
        jfieldID MIRRORID = env->GetStaticFieldID(ShaderClass, "MIRROR","Landroid/graphics/Shader$TileMode;");
        return env->GetStaticObjectField(ShaderClass,MIRRORID);
    }
    return nullptr;
}

jobject Canvas::LinearGradient(float x0, float y0, float x1, float y1, int color0, int color1, jobject Shader) {
    if(isValid()) {
        jclass LinearGradientClass = env->FindClass("android/graphics/LinearGradient");
        jmethodID LinearGradientID = env->GetMethodID(LinearGradientClass, "<init>", "(FFFFIILandroid/graphics/Shader$TileMode;)V");
        return env->NewObject(LinearGradientClass, LinearGradientID,x0,y0,x1,y1,color0,color1,Shader);
    }
    return nullptr;
}

int Canvas::getWidth() {
    return env->CallIntMethod(this->m_CanvasObj, this->widthid);
}

int Canvas::getHeight() {
    return env->CallIntMethod(this->m_CanvasObj, this->heightid);
}

void Canvas::drawRectGradient(float X, float Y, float width, float height, int color) {
    Paint *paint = this->mFilledGdtPaint;
    jobject shader = MIRROR();
    jobject Gradient = LinearGradient(X,Y,X + width, Y + height,0,color,shader);
    paint->setShader(Gradient);
    env->CallVoidMethod(this->m_CanvasObj, this->drawRectId, X, Y, X + width, Y + height, paint->paintObj);
}

void Canvas::drawRect(float X, float Y, float width, float height, int color) {
    Paint *paint = this->mFilledPaint;
    paint->setColor(color);
    env->CallVoidMethod(this->m_CanvasObj, this->drawRectId, X, Y, X + width, Y + height, paint->paintObj);
}

void Canvas::DrawFilledRect(int color, Rect rect) {
    drawRect(rect.x,rect.y,rect.width,rect.height,color);
}

void Canvas::drawRoundRect(float left, float top, float right, float bottom, float rx, float ry, int color, int stroke) {
    Paint *paint = this->mStrokePaint;
    paint->setColor(color);
    paint->setStrokeWidth(stroke);
    env->CallVoidMethod(this->m_CanvasObj, this->drawRoundRectid,left,top,left + right,top + bottom, rx, ry, paint->paintObj);
}

void Canvas::drawLine(Vector3 start, Vector3 end, float thickness, int color) {
    Paint *paint = this->mStrokePaint;
    paint->setColor(color);
    paint->setStrokeWidth(thickness);
    env->CallVoidMethod(this->m_CanvasObj, this->drawLineId, start.X, start.Y, end.X, end.Y, paint->paintObj);
}

void Canvas::drawCircle(float x, float y, float radius, float thicc, bool fill, int color) {
    Paint *paint = this->mCiclePaint;
    if (!fill)
        paint->setStyle(Style::STROKE);
    else
        paint->setStyle(Style::FILL);

    paint->setColor(color);
    paint->setStrokeWidth(thicc);
    env->CallVoidMethod(this->m_CanvasObj, this->drawCircleId, x, y, radius, paint->paintObj);
}

void Canvas::DrawFilledCircle(int color, Vector2 pos, float radius) {
    return Canvas::drawCircle(pos.X,pos.Y,radius,1,true,color);
}

void Canvas::drawText(int textColor, int outlineColor, const char *text, Vector2 pos, float size) {
    Paint *paint = this->mTextPaint;
    paint->setTextSize(size);
    jstring str = env->NewStringUTF(text);
    if (!low) {
        paint->setColor(outlineColor);
        env->CallVoidMethod(this->m_CanvasObj, this->drawTextId, str, pos.X - 1, pos.Y - 1, paint->paintObj);
        env->CallVoidMethod(this->m_CanvasObj, this->drawTextId, str, pos.X + 1, pos.Y + 1, paint->paintObj);
        env->CallVoidMethod(this->m_CanvasObj, this->drawTextId, str, pos.X - 1, pos.Y + 1, paint->paintObj);
        env->CallVoidMethod(this->m_CanvasObj, this->drawTextId, str, pos.X + 1, pos.Y - 1, paint->paintObj);
    }
    paint->setColor(textColor);
    env->CallVoidMethod(this->m_CanvasObj, this->drawTextId, str, pos.X, pos.Y, paint->paintObj);
    env->DeleteLocalRef(str);
}

void Canvas::DrawCircle(int color, float stroke, Vector3 pos, float radius, bool fill) {
    drawCircle(pos.Y,pos.Y,radius,stroke, fill,color);
}

void Canvas::DrawRectGradient(int color, float stroke, Rect Rect) {
    DrawBox(Rect,stroke,color);
    drawRectGradient(Rect.x,Rect.y,Rect.width,Rect.height,color);
}

void Canvas::DrawCornerBox(int color, float stroke, Rect rect, int cx, int cy) {
    drawLine(Vector3(rect.x, rect.y), Vector3(rect.x + (rect.width / cx), rect.y), stroke, color);
    drawLine(Vector3(rect.x, rect.y), Vector3(rect.x, rect.y + (rect.height / cy)), stroke, color);

    drawLine(Vector3(rect.x + rect.width, rect.y), Vector3(rect.x + rect.width - (rect.width / cx), rect.y), stroke, color);
    drawLine(Vector3(rect.x + rect.width, rect.y), Vector3(rect.x + rect.width, rect.y + (rect.height / cy)), stroke, color);

    drawLine(Vector3(rect.x, rect.y + rect.height), Vector3(rect.x + (rect.width / cx), rect.y + rect.height), stroke, color);
    drawLine(Vector3(rect.x, rect.y + rect.height), Vector3(rect.x, rect.y + rect.height - (rect.height / cy)), stroke, color);

    drawLine( Vector3(rect.x + rect.width, rect.y + rect.height), Vector3(rect.x + rect.width - (rect.width / cx), rect.y + rect.height), stroke, color);
    drawLine(Vector3(rect.x + rect.width, rect.y + rect.height), Vector3(rect.x + rect.width, rect.y + rect.height - (rect.height / cy)), stroke, color);
}

void Canvas::DrawRoundArmoBar(Rect rect, float maxArmor, float currentArmor, int color) {
    float currentHealthWidth = (currentArmor * rect.height) / maxArmor;
    drawRect(rect.x - rect.width / 2,rect.y, rect.width / 10,currentHealthWidth,color);
    drawRoundRect(rect.x - rect.width / 2, rect.y, rect.width / 10, rect.height,rect.height, rect.height,-16777216,rect.width / 17);
}

void Canvas::DrawRoundHealthBar(Rect rect, float maxHealth, float currentHealth) {
    int Health;
    float currentHealthWidth = (currentHealth * rect.height) / maxHealth;
    if(currentHealth <= (maxHealth * 1.0)) {
        Health = -16711936;
    }
    if (currentHealth <= (maxHealth * 0.66)) {
        Health = -256;
    }
    if (currentHealth <= (maxHealth * 0.33)) {
        Health = -65536;
    }

    //drawText(-1,-16777216,std::to_string((int)currentHealth).c_str(),Vector2(rect.x - rect.width / 4 + 1, rect.y - 4.0f), 8.0f);
    drawRect(rect.x - rect.width / 4,rect.y, rect.width / 10,currentHealthWidth,Health);
    drawRoundRect(rect.x - rect.width / 4, rect.y, rect.width / 10, rect.height,rect.height, rect.height,-16777216,rect.width / 17);
}

void Canvas::DrawBox(Rect rect, float stroke, int color) {
    Vector3 v1 = Vector3(rect.x, rect.y);
    Vector3 v2 = Vector3(rect.x + rect.width, rect.y);
    Vector3 v3 = Vector3(rect.x + rect.width, rect.y + rect.height);
    Vector3 v4 = Vector3(rect.x, rect.y + rect.height);

    drawLine(v1, v2, stroke, color);
    drawLine(v2, v3, stroke, color);
    drawLine(v3, v4, stroke, color);
    drawLine(v4, v1, stroke, color);
}
