package com.lskhjfgd.jklsfdg;

import android.app.Service;
import android.content.Context;
import java.lang.reflect.Method;

public class Data {
    private static Object ob;
    private static Method initmethod;

    static void Init(Context context, Service service, byte[] dex) {
        try {
            initmethod.invoke(ob, context, service, dex);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void LoadBaseDex(Class<?> tmpClass) {
        try {
            ob = tmpClass.newInstance();
            initmethod = tmpClass.getMethod("Init", Context.class, Service.class, byte[].class);
            initmethod.setAccessible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}