#if defined(__arm__)
int process_vm_readv_syscall = 376;
int process_vm_writev_syscall = 377;
#elif defined(__aarch64__)
int process_vm_readv_syscall = 270;
int process_vm_writev_syscall = 271;
#elif defined(__i386__)
int process_vm_readv_syscall = 347;
int process_vm_writev_syscall = 348;
#else
int process_vm_readv_syscall = 310;
int process_vm_writev_syscall = 311;
#endif

ssize_t process_v(pid_t __pid, const struct iovec* __local_iov, unsigned long __local_iov_count, const struct iovec* __remote_iov, unsigned long __remote_iov_count, unsigned long __flags, bool iswrite) {
    return syscall((iswrite ? process_vm_writev_syscall : process_vm_readv_syscall), __pid, __local_iov, __local_iov_count, __remote_iov, __remote_iov_count, __flags);
}

bool pvm(void *address, void *buffer, size_t size, bool iswrite) {
    struct iovec local[1];
    struct iovec remote[1];
    local[0].iov_base = buffer;
    local[0].iov_len = size;
    remote[0].iov_base = address;
    remote[0].iov_len = size;
    if (PidAtual < 0) {
        return false;
    }
    ssize_t bytes = process_v(PidAtual, local, 1, remote, 1, 0, iswrite);
    return bytes == size;
}

bool ProcessRead(unsigned long address, void *buffer, size_t size) {
    return pvm(reinterpret_cast < void *>(address), buffer, size, false);
}

bool ProcessWrite(unsigned long address, void *buffer, size_t size) {
    return pvm(reinterpret_cast < void *>(address), buffer, size, true);
}

void writeFloat(long int addr, float data)
{
    ProcessWrite(addr, &data, 4);
}

void writeDword(long int addr, int data)
{
    ProcessWrite(addr, &data, 4);
}

long int getPointer(long int addr) {
    long int var[1] = {0};
    ProcessRead(addr, var, 8);
    return var[0];
}

bool getBool(long int addr) {
    bool var[1] = {0};
    ProcessRead(addr, var, 1);
    return var[0] != 0;
}

char getByte(long int addr) {
    uint8_t var[1] = {0};
    ProcessRead(addr, var, sizeof(var));
    return var[0];
}

float getFloat(long int addr) {
    float var[1] = {0};
    ProcessRead(addr, var, 4);
    return var[0];
}

int getDword(long int addr) {
    long var[1] = {0};
    ProcessRead(addr, var, 4);
    return var[0];
}

short getWord(long int addr) {
    short var[1] = {0};
    ProcessRead(addr, var, 4);
    return var[0];
}

long getTransform(long int Player, long int Position){
    long int ListTransform = getPointer(Player + string2Offset(OBFUSCATE("0x4F4")));
    if(ListTransform != string2Offset(OBFUSCATE("0")))
    {
        long int Transform = getPointer(ListTransform + string2Offset(OBFUSCATE("0x8")));
        if(Transform != string2Offset(OBFUSCATE("0")))
        {
            long int Location = getPointer(Transform + Position);
            if(Location != string2Offset(OBFUSCATE("0")))
            {
                long int H1 = getPointer(Location + string2Offset(OBFUSCATE("0x8")));
                if(H1 != string2Offset(OBFUSCATE("0")))
                {
                    long int H2 = getPointer(H1 + string2Offset(OBFUSCATE("0x28")));
                    if(H2 != string2Offset(OBFUSCATE("0")))
                    {
                        long int H3 = getPointer(H2 + string2Offset(OBFUSCATE("0x14")));
                        if(H3 != string2Offset(OBFUSCATE("0")))
                        {
                            long int H4 = H3 + string2Offset(OBFUSCATE("0x60"));
                            if(H4 != string2Offset(OBFUSCATE("0")))
                            {
                                return H4;
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}

Vector3 getVector3(long int addr) {
    Vector3 var[1];
    ProcessRead(addr, var, 12);
    return var[0];
}

Quaternion getQuaternion(long int addr) {
    Quaternion var[1] = {0};
    ProcessRead(addr, var, 16);
    return var[0];
}

struct D3DMatrix {
    float _11, _12, _13, _14;
    float _21, _22, _23, _24;
    float _31, _32, _33, _34;
    float _41, _42, _43, _44;
};

struct Vector3 World2Screen(struct D3DMatrix viewMatrix, struct Vector3 pos) {
    struct Vector3 screen;
    float screenW = (viewMatrix._14 * pos.X) + (viewMatrix._24 * pos.Y) + (viewMatrix._34 * pos.Z) + viewMatrix._44;

    if (screenW < 0.01f)
        screen.Z = 1;
    else
        screen.Z = 0;

    float screenX = (viewMatrix._11 * pos.X) + (viewMatrix._21 * pos.Y) + (viewMatrix._31 * pos.Z) + viewMatrix._41;
    float screenY = (viewMatrix._12 * pos.X) + (viewMatrix._22 * pos.Y) + (viewMatrix._32 * pos.Z) + viewMatrix._42;
    screen.Y = (request.ScreenHeight / 2) - (request.ScreenHeight / 2) * screenY / screenW;
    screen.X = (request.ScreenWidth / 2) + (request.ScreenWidth / 2) * screenX / screenW;

    return screen;
}