struct {
    jobject checkbox0, checkbox1, checkbox2, checkbox3, checkbox4, checkbox5, checkbox6, checkbox7, checkbox8, checkbox9, checkbox10, checkbox11, checkbox12, checkbox13, checkbox14, checkbox15, checkbox16, checkbox17, checkbox18; /**checkbox**/

    jobject RootFrame; /**FrameLayout**/
    jobject RootRelative, CollapsedRelative, TabCimaRelative, TabBaixoRelative; /**RelativeLayout**/
    jobject WindowManager; /**WindowManager**/
    jobject BaixoBackground, CimaBackground, FecharBackground, LineAbrir, AbrirBackground; /**GradientDrawable**/
    jint initialX, initialY; /**Int Pos**/
    jfloat initialTouchX, initialTouchY; /**Float Pos**/
    jobject WindowParams; /**WindowParams**/
    jobject LogoImagem; /**ImageView**/
    jobject LogoPNG; /**Bitmap**/
    jbyteArray DecodeFloater; /**Decode Base64 Image**/
    jobject MenuLayout, TabCima, TabBaixo, FuncsListLayout, AbrirMenuLayout, InfoLayout; /**LinearLayout**/
    jobject FuncsList; /**ScrollView**/
    jobject TituloText, InfoText; /**TextView**/
    jobject CloseButton, StartButton; /**Button**/
    jobject LineRainbow; /**View**/

    jobject ESPParams, ESPView;;

    jobject checkteste;
}Floater;
