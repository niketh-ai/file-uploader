void CriarLayoutLogin(JNIEnv *env, jobject ctx) {
    Login.PrincipalLayout = LinearLayout.LinearLayout(env,ctx);
    jobject principalParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
    LinearLayout.setLayoutParams(env,Login.PrincipalLayout, principalParams);
    LinearLayout.setOrientation(env,Login.PrincipalLayout, Orientation.VERTICAL);
    LinearLayout.setGravity(env,Login.PrincipalLayout, Gravity.CENTER);
    View.setBackgroundColor(env,Login.PrincipalLayout, Color.parseColor(OBFUSCATE("#4d4d4d")));
    Activity.setContentView(ctx, Login.PrincipalLayout);

    Login.LineView = View.View(env,ctx);
    jobject lineParams = LinearLayout.LayoutParams(env,ConvertDP(env,ctx,368),ConvertDP(env,ctx,3));
    View.setLayoutParams(env,Login.LineView, lineParams);
    View.setBackground(env,Login.LineView, Login.LineBackground);

    Login.TableLayout = LinearLayout.LinearLayout(env,ctx);
    jobject tableParams = LinearLayout.LayoutParams(env,ConvertDP(env,ctx,370), LayoutParams.WRAP_CONTENT);
    LinearLayout.setLayoutParams(env,Login.TableLayout, tableParams);
    LinearLayout.setOrientation(env,Login.TableLayout, Orientation.VERTICAL);
    View.setElevation(env,Login.TableLayout, ConvertDP(env,ctx,13));
    LinearLayout.setBackground(env,Login.TableLayout, Login.TableBackground);

    Login.TituloText = TextView.TextView(env,ctx);
    jobject tituloParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    TextView.setLayoutParams(env,Login.TituloText, tituloParams);
    TextView.fromHtml(env,Login.TituloText, OBFUSCATE(("<font color='#1ceded'>BR</font> <font color='#FFFFFF'>MODS EXTERNAL</font>")));
    TextView.setTypeface(env,Login.TituloText, TypeFace.BOLD);
    TextView.setTextColor(env,Login.TituloText, Color.WHITE);
    TextView.setTextSize(env,Login.TituloText, TypedValue.COMPLEX_UNIT_SP, 25.0f);
    TextView.setGravity(env,Login.TituloText, Gravity.CENTER);

    Login.AvisoText = TextView.TextView(env,ctx);
    jobject avisoParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    TextView.setLayoutParams(env,Login.AvisoText, avisoParams);
    TextView.setText(env,Login.AvisoText, OBFUSCATE("Log in to start session"));
    TextView.setTextColor(env,Login.AvisoText, Color.parseColor(OBFUSCATE("#CCCCCC")));
    TextView.setTextSize(env,Login.AvisoText, TypedValue.COMPLEX_UNIT_SP, 15.0f);
    TextView.setGravity(env,Login.AvisoText, Gravity.CENTER);

    Login.FormLayout = LinearLayout.LinearLayout(env,ctx);
    jobject formParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    ViewGroup.topMargin(formParams,ConvertDP(env,ctx,5));
    LinearLayout.setLayoutParams(env,Login.FormLayout, formParams);
    LinearLayout.setOrientation(env,Login.FormLayout, Orientation.VERTICAL);

    Login.UsuarioLayout = LinearLayout.LinearLayout(env,ctx);
    jobject usuarioLayoutParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    ViewGroup.topMargin(usuarioLayoutParams, ConvertDP(env,ctx,10));
    ViewGroup.leftMargin(usuarioLayoutParams, ConvertDP(env,ctx,10));
    ViewGroup.rightMargin(usuarioLayoutParams, ConvertDP(env,ctx,10));
    LinearLayout.setLayoutParams(env,Login.UsuarioLayout, usuarioLayoutParams);
    LinearLayout.setOrientation(env,Login.UsuarioLayout, Orientation.HORIZONTAL);

    Login.UsuarioImagem = ImageView.ImageView(ctx);
    jobject usuarioImagemParams = LinearLayout.LayoutParams(env,ConvertDP(env,ctx,35),ConvertDP(env,ctx,35));
    LinearLayout.setLayoutParams(env,Login.UsuarioImagem, usuarioImagemParams);
    ImageView.setImageBitmap(Login.UsuarioImagem, Login.UsuarioPNG);
    ImageView.setBackground(Login.UsuarioImagem, Login.LogoEditBackground);
    View.setPadding(env,Login.UsuarioImagem,ConvertDP(env,ctx,8),ConvertDP(env,ctx,8),ConvertDP(env,ctx,8),ConvertDP(env,ctx,8));

    Login.UsuarioEdit = EditText.EditText(ctx);
    jobject usuarioEditParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT,ConvertDP(env,ctx,35));
    EditText.setLayoutParams(Login.UsuarioEdit, usuarioEditParams);
    EditText.setHint(Login.UsuarioEdit, OBFUSCATE("Enter your username"));
    TextView.setText(env,Login.UsuarioEdit,Prefs.read(JNI.EnvGlobal,ctx,Login.USER, ""));
    TextView.setHintColor(env,Login.UsuarioEdit, Color.parseColor(OBFUSCATE("#363636")));
    EditText.setTextColor(Login.UsuarioEdit, Color.WHITE);
    EditText.setTextSize(Login.UsuarioEdit, TypedValue.COMPLEX_UNIT_SP, 13.0f);
    View.setBackground(env,Login.UsuarioEdit, Login.EditBackground);
    View.setPadding(env,Login.UsuarioEdit,ConvertDP(env,ctx,8), 0, 0,0);

    Login.SenhaLayout = LinearLayout.LinearLayout(env,ctx);
    jobject senhaLayoutParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    ViewGroup.topMargin(senhaLayoutParams,ConvertDP(env,ctx,10));
    ViewGroup.leftMargin(senhaLayoutParams,ConvertDP(env,ctx,10));
    ViewGroup.rightMargin(senhaLayoutParams, ConvertDP(env,ctx,10));
    LinearLayout.setLayoutParams(env,Login.SenhaLayout, senhaLayoutParams);
    LinearLayout.setOrientation(env,Login.SenhaLayout, Orientation.HORIZONTAL);

    Login.SenhaImagem = ImageView.ImageView(ctx);
    jobject senhaImagemParams = LinearLayout.LayoutParams(env,ConvertDP(env,ctx,35),ConvertDP(env,ctx,35));
    LinearLayout.setLayoutParams(env,Login.SenhaImagem, senhaImagemParams);
    ImageView.setImageBitmap(Login.SenhaImagem, Login.SenhaPNG);
    ImageView.setBackground(Login.SenhaImagem, Login.LogoEditBackground);
    View.setPadding(env,Login.SenhaImagem,ConvertDP(env,ctx,8),ConvertDP(env,ctx,8), ConvertDP(env,ctx,8), ConvertDP(env,ctx,8));

    Login.SenhaEdit = EditText.EditText(ctx);
    jobject senhaEditParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT,ConvertDP(env,ctx,35));
    EditText.setLayoutParams(Login.SenhaEdit, senhaEditParams);
    EditText.setHint(Login.SenhaEdit, OBFUSCATE("Enter your password"));
    TextView.setText(env,Login.SenhaEdit,Prefs.read(JNI.EnvGlobal,ctx,Login.PASS, ""));
    TextView.setHintColor(env,Login.SenhaEdit, Color.parseColor(OBFUSCATE("#363636")));
    EditText.setTextColor(Login.SenhaEdit, Color.WHITE);
    EditText.setTextSize(Login.SenhaEdit, TypedValue.COMPLEX_UNIT_SP, 13.0f);
    View.setBackground(env,Login.SenhaEdit, Login.EditBackground);
    View.setPadding(env,Login.SenhaEdit, ConvertDP(env,ctx,8), 0, 0,0);

    Login.EntrarLayout = LinearLayout.LinearLayout(env,ctx);
    jobject entrarLayoutParams = LinearLayout.LayoutParams(env,LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    ViewGroup.topMargin(entrarLayoutParams,ConvertDP(env,ctx,15));
    ViewGroup.bottomMargin(entrarLayoutParams,ConvertDP(env,ctx,15));
    ViewGroup.rightMargin(entrarLayoutParams, ConvertDP(env,ctx,15));
    LinearLayout.setLayoutParams(env,Login.EntrarLayout, entrarLayoutParams);
    LinearLayout.setOrientation(env,Login.EntrarLayout, Orientation.HORIZONTAL);
    LinearLayout.setGravity(env,Login.EntrarLayout, Gravity.RIGHT|Gravity.CENTER);

    Login.EntrarButton = Button.Button(ctx);
    jobject entrarButtonParams = LinearLayout.LayoutParams(env,ConvertDP(env,ctx,80), ConvertDP(env,ctx,35));
    LinearLayout.setLayoutParams(env,Login.EntrarButton, entrarButtonParams);
    TextView.setText(env,Login.EntrarButton, OBFUSCATE("Login"));
    TextView.setTextColor(env,Login.EntrarButton, Color.BLACK);
    TextView.setTextSize(env,Login.EntrarButton, TypedValue.COMPLEX_UNIT_SP, 13.0f);
    Button.setTypeface(Login.EntrarButton, TypeFace.BOLD);
    TextView.setAllCaps(env,Login.EntrarButton, false);
    View.setBackground(env,Login.EntrarButton, Login.EntrarButtonBackground);
    TextView.setPadding(env,Login.EntrarButton,ConvertDP(env,ctx,2),ConvertDP(env,ctx,2),ConvertDP(env,ctx,2),ConvertDP(env,ctx,2));
    OnClickListener.setOnClickListener(ctx, Login.EntrarButton, 0);
}

void LoginOnClick(JNIEnv *env, jobject ctx, int id) {
    if (id == 0) {
        jstring Usuario = EditText.getText(Login.UsuarioEdit);
        jstring Senha = EditText.getText(Login.SenhaEdit);
        if (!String.isEmpty(JNI.EnvGlobal,Usuario) || !String.isEmpty(JNI.EnvGlobal,Senha)) {
            Prefs.write(ctx,Login.USER,Usuario);
            Prefs.write(ctx,Login.PASS,Senha);
            Prefs.write(ctx,Login.UID, getUniqueId(JNI.EnvGlobal,ctx));
            AsyncTask.execute(JavaJNI.AsyncTaskRunner(ctx),Usuario,Senha);
        } else {
            CustomToast(env,OBFUSCATE("Preencha todos os campos."),ctx);
        }
    }
    if (id == 99) {
        Activity.finish(JNI.EnvGlobal,ctx);
    }
}

void AddObjectsLogin(jobject ctx, JNIEnv *env) {
    JNI.EnvGlobal->CallVoidMethod(Login.PrincipalLayout, ViewGroup.addView(), Login.LineView);
    JNI.EnvGlobal->CallVoidMethod(Login.PrincipalLayout, ViewGroup.addView(), Login.TableLayout);
    JNI.EnvGlobal->CallVoidMethod(Login.TableLayout, ViewGroup.addView(), Login.TituloText);
    JNI.EnvGlobal->CallVoidMethod(Login.TableLayout, ViewGroup.addView(), Login.AvisoText);
    JNI.EnvGlobal->CallVoidMethod(Login.TableLayout, ViewGroup.addView(), Login.FormLayout);
    JNI.EnvGlobal->CallVoidMethod(Login.FormLayout, ViewGroup.addView(), Login.UsuarioLayout);
    JNI.EnvGlobal->CallVoidMethod(Login.UsuarioLayout, ViewGroup.addView(), Login.UsuarioImagem);
    JNI.EnvGlobal->CallVoidMethod(Login.UsuarioLayout, ViewGroup.addView(), Login.UsuarioEdit);
    JNI.EnvGlobal->CallVoidMethod(Login.FormLayout, ViewGroup.addView(), Login.SenhaLayout);
    JNI.EnvGlobal->CallVoidMethod(Login.SenhaLayout, ViewGroup.addView(), Login.SenhaImagem);
    JNI.EnvGlobal->CallVoidMethod(Login.SenhaLayout, ViewGroup.addView(), Login.SenhaEdit);
    JNI.EnvGlobal->CallVoidMethod(Login.TableLayout, ViewGroup.addView(), Login.EntrarLayout);
    JNI.EnvGlobal->CallVoidMethod(Login.EntrarLayout, ViewGroup.addView(), Login.EntrarButton);
}

void CarregarConfigs(jobject ctx) {
    Activity.requestWindowFeature(ctx,ActivityInfo.FEATURE_NO_TITLE);
    Activity.setRequestedOrientation(ctx, ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    Activity.setActivityFlags(ctx, Flags.FLAG_FULLSCREEN, Flags.FLAG_FULLSCREEN);
    Activity.setSystemUiVisibility(ctx,View.SYSTEM_UI_FLAG_LAYOUT_STABLE |View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |View.SYSTEM_UI_FLAG_FULLSCREEN |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
}

void CriarBackgroundsLogin(JNIEnv *env, jobject ctx) {
    // Table Background - Dark gray with curved corners
    Login.TableBackground = GradientDrawable.GradientDrawable(ctx);
    GradientDrawable.setShape(Login.TableBackground, Shape.RECTANGLE);
    GradientDrawable.setColor(Login.TableBackground, Color.parseColor(OBFUSCATE("#5A5C5B")));
    GradientDrawable.setCornerRadius(Login.TableBackground, ConvertDP(env,ctx,4));

    // Line Background - BR cyan color with top curved corners
    Login.LineBackground = GradientDrawable.GradientDrawable(ctx);
    GradientDrawable.setShape(Login.LineBackground, Shape.RECTANGLE);
    GradientDrawable.setColor(Login.LineBackground, Color.parseColor(OBFUSCATE("#1ceded")));
    GradientDrawable.setCornerRadii(Login.LineBackground,ConvertDP(env,ctx,8), ConvertDP(env,ctx,8), 0, 0);

    // Logo Edit Background (icons) - Dark with BR border
    Login.LogoEditBackground = GradientDrawable.GradientDrawable(ctx);
    GradientDrawable.setShape(Login.LogoEditBackground, Shape.RECTANGLE);
    GradientDrawable.setColor(Login.LogoEditBackground, Color.parseColor(OBFUSCATE("#53a2a6")));
    GradientDrawable.setStroke(Login.LogoEditBackground, ConvertDP(env,ctx,1), Color.parseColor(OBFUSCATE("#1ceded")));
    GradientDrawable.setCornerRadii(Login.LogoEditBackground,ConvertDP(env,ctx,5), 0, 0, ConvertDP(env,ctx,5));

    // Edit Text Background - Dark with BR border
    Login.EditBackground = GradientDrawable.GradientDrawable(ctx);
    GradientDrawable.setShape(Login.EditBackground, Shape.RECTANGLE);
    GradientDrawable.setColor(Login.EditBackground, Color.parseColor(OBFUSCATE("#53a2a6")));
    GradientDrawable.setStroke(Login.EditBackground,ConvertDP(env,ctx,1), Color.parseColor(OBFUSCATE("#1ceded")));
    GradientDrawable.setCornerRadii(Login.EditBackground,0,ConvertDP(env,ctx,5),ConvertDP(env,ctx,5), 0);

    // Login Button Background - BR cyan color
    Login.EntrarButtonBackground = GradientDrawable.GradientDrawable(ctx);
    GradientDrawable.setShape(Login.EntrarButtonBackground, Shape.RECTANGLE);
    GradientDrawable.setColor(Login.EntrarButtonBackground, Color.parseColor(OBFUSCATE("#1ceded")));
    GradientDrawable.setCornerRadii(Login.EntrarButtonBackground,ConvertDP(env,ctx,8), ConvertDP(env,ctx,8),ConvertDP(env,ctx,8), ConvertDP(env,ctx,8));
}

void CriarImagemLogin() {
    const char *UsuarioBase64 = OBFUSCATE("iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABTUlEQVRIS73UISxFcRTH8Y8oSUZgYyNJxmY2KhNEGpEmkT2ZpBFpRMGobGZjksTGRmCSJLK/vWvP8+7//nE58e6c8/2f3/md2yQt5jCC0Wr6EY6xWVTeVJSAMwzk5J1jMNajCLCDqYJH7GI6LycGmMFWwoQhZRbbjXJjgJTXZz1zp4gB7tCROME9Or87wQ26EgG36P4uIOgf9pASQf+why8Rkyh4fyOlO+bzbqLIprEbyNjRWygChCYxN0VvIBSnAEJe2MUkhqvPPsFenvdrZU0FJK4ifcmt6EM/WrCP07ryIUzgGRe4xFM9otEEwTnBQfXxgqvqx140N8gJf9fgqI+oB7z+WIvPhR99awGLWC0JsIS1Whe14aGk5lmbdjxmE4zhoGTAOA4zQJnyZO98lykDVLBc8gQrqPwb4M+XHNQJV7mOnl9KdY2F6vV7A9ESNhl4JmGYAAAAAElFTkSuQmCC");
    Login.DecodeUser = Base64.Decode(JNI.EnvGlobal,UsuarioBase64);
    Login.UsuarioPNG = BitmapFactory.decodeByteArray(Login.DecodeUser);

    const char *SenhaBase64 = OBFUSCATE("iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABPElEQVRIS+3UvytFcRjH8dedbSIyKUoyshIj/wKDSSkpg9m9q0lSymTgT5DRr5VRUsIkSjYzfW/n1Llfvvc4w110n+V0nu/n+3x63s9zTk15DGMV45jM5De4wz6e25WoldRfxh56ErpPrOEwVaedwTQuyxtsKmZw9Zs2ZdCHe/RGl26z94ko/4ExvMcmKYNtbBbE52ggPEPMYit75rIdbPzV4AQLBfEUwmCLEQZ+XUiE86BriVQHTwjbE+IRI4lZnEVd9MeYUgZfEZ65hEE9Q5UfB12OsZn7fwYrGIraDi1fRIhyhIFA2KY8wqa94CBPFBEVuSeQV0o3a+cGiziqdL1cvITj3CDehvLr5YqAq941aAeq44jCXBudnEHXoPRDaEE0gNfSK9UEg3gr/ovmsYvRanV+qB+wjtNw8g374UYZWHY1jwAAAABJRU5ErkJggg==");
    Login.DecodeSenha = Base64.Decode(JNI.EnvGlobal,SenhaBase64);
    Login.SenhaPNG = BitmapFactory.decodeByteArray(Login.DecodeSenha);
}

void LoginCreate(JNIEnv *env, jobject ctx) {
    Runtime.exec(Runtime.getRuntime(),"su");
    CarregarConfigs(ctx);
    CriarBackgroundsLogin(env,ctx);
    CriarImagemLogin();
    CriarLayoutLogin(env,ctx);
    AddObjectsLogin(ctx,env);
}